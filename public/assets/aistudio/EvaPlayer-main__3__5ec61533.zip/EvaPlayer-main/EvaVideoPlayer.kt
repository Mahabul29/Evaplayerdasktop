package com.example.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Rational
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Delete
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.data.model.VideoItem
import com.example.ui.components.shareVideoFile
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(UnstableApi::class)
@Composable
fun EvaVideoPlayer(
    initialVideo: VideoItem,
    playlist: List<VideoItem> = emptyList(),
    startIndex: Int = 0,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()

    var currentVideoIndex by remember { mutableIntStateOf(if (playlist.isNotEmpty()) startIndex else 0) }
    val currentVideo = if (playlist.isNotEmpty() && currentVideoIndex in playlist.indices) {
        playlist[currentVideoIndex]
    } else initialVideo

    // Hardware/Software decoder mode state
    var isHardwareDecoder by remember { mutableStateOf(true) }

    // ExoPlayer build helper
    val createPlayer: () -> ExoPlayer = {
        val renderersFactory = DefaultRenderersFactory(context).apply {
            setExtensionRendererMode(
                if (isHardwareDecoder) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
                else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
            )
            setEnableDecoderFallback(true)
        }
        // Network streaming: follow http<->https redirects, longer timeouts, normal user agent
        val httpFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setUserAgent("Mozilla/5.0 (Linux; Android) EvaPlayer")
        val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpFactory)
        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(
                androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSourceFactory)
            )
            .build().apply {
            playWhenReady = true
            videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
        }
    }

    var exoPlayer by remember { mutableStateOf(createPlayer()) }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var bufferedPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(currentVideo.durationMs.coerceAtLeast(1L)) }
    var isBuffering by remember { mutableStateOf(true) }
    var playbackError by remember { mutableStateOf<String?>(null) }

    // Controls UI state
    var showControls by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Resume prompt
    var showResumePrompt by remember { mutableStateOf(currentVideo.lastPositionMs > 3000L) }
    val promptVisible = showResumePrompt && currentVideo.lastPositionMs > 3000L

    // Top Bar Sheets state
    var showCastDialog by remember { mutableStateOf(false) }
    var showLanguageSheet by remember { mutableStateOf(false) }
    var showSubtitlesSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showInfoSheet by remember { mutableStateOf(false) }

    // Bottom Row & Video Control Sheet state
    var showVideoControlSheet by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showNightModeDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showQualityDialog by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }

    // Player features state
    var currentAspectMode by remember { mutableStateOf(AspectMode.FIT) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var isMirrored by remember { mutableStateOf(false) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }
    var loopMode by remember { mutableStateOf(LoopMode.OFF) }
    var isShuffleActive by remember { mutableStateOf(false) }

    // Night Mode dimming overlay
    var isNightModeActive by remember { mutableStateOf(false) }
    var nightModeDimFraction by remember { mutableFloatStateOf(0.4f) }

    // Subtitle & Audio delay
    var selectedSubtitleTrack by remember { mutableStateOf("Off") }
    var subtitleDelayMs by remember { mutableIntStateOf(settings.subDelayMs) }
    var audioDelayMs by remember { mutableIntStateOf(settings.audioDelayMs) }
    var selectedAudioTrackIndex by remember { mutableIntStateOf(0) }

    // A-B Repeat
    var repeatPointA by remember { mutableStateOf<Long?>(null) }
    var repeatPointB by remember { mutableStateOf<Long?>(null) }

    // Gestures HUD
    var hudBrightness by remember { mutableStateOf<Int?>(null) }
    var hudVolume by remember { mutableStateOf<Int?>(null) }
    var hudSeekDiff by remember { mutableStateOf<String?>(null) }
    var hudDoubleTap by remember { mutableStateOf<String?>(null) }
    var isLongPress2X by remember { mutableStateOf(false) }
    var speedBeforeLongPress by remember { mutableStateOf(1f) }

    // Double tap skip debounce & accumulator
    var accumulatedSkipMs by remember { mutableLongStateOf(0L) }
    var skipDebounceJob by remember { mutableStateOf<Job?>(null) }

    // Back handler
    BackHandler {
        when {
            showCastDialog -> showCastDialog = false
            showLanguageSheet -> showLanguageSheet = false
            showSubtitlesSheet -> showSubtitlesSheet = false
            showQueueSheet -> showQueueSheet = false
            showInfoSheet -> showInfoSheet = false
            showVideoControlSheet -> showVideoControlSheet = false
            showSpeedDialog -> showSpeedDialog = false
            showEqualizerSheet -> showEqualizerSheet = false
            showNightModeDialog -> showNightModeDialog = false
            showSleepTimerDialog -> showSleepTimerDialog = false
            showQualityDialog -> showQualityDialog = false
            showFeedbackDialog -> showFeedbackDialog = false
            isLocked -> isLocked = false
            else -> {
                coroutineScope.launch {
                    viewModel.playbackRepo.savePlaybackPosition(currentVideo, exoPlayer.currentPosition)
                }
                if (!viewModel.navigateBack()) activity?.finish()
            }
        }
    }

    // Keep screen on
    DisposableEffect(settings.keepScreenOn) {
        if (settings.keepScreenOn) {
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Edge-to-edge system bars controller
    DisposableEffect(Unit) {
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            val window = activity?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Load media into player
    LaunchedEffect(currentVideo.uriString, isHardwareDecoder) {
        val rawUri = currentVideo.uriString.ifEmpty { currentVideo.path }
        val mediaUri = if (rawUri.startsWith("/")) {
            Uri.fromFile(java.io.File(rawUri))
        } else {
            Uri.parse(rawUri)
        }
        val mediaItem = MediaItem.fromUri(mediaUri)
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()

        if (currentVideo.lastPositionMs > 3000L) {
            showResumePrompt = true
        } else {
            exoPlayer.seekTo(0L)
            showResumePrompt = false
        }
        exoPlayer.play()
    }

    // Ticker for position, buffering, and A-B repeat
    LaunchedEffect(exoPlayer) {
        while (true) {
            if (exoPlayer.isPlaying) {
                currentPositionMs = exoPlayer.currentPosition
                bufferedPositionMs = exoPlayer.bufferedPosition
                durationMs = exoPlayer.duration.coerceAtLeast(1L)
                isPlaying = true

                // A-B Repeat loop check
                if (repeatPointA != null && repeatPointB != null && repeatPointB!! > repeatPointA!!) {
                    if (currentPositionMs >= repeatPointB!!) {
                        exoPlayer.seekTo(repeatPointA!!)
                    }
                }
            } else {
                isPlaying = false
                currentPositionMs = exoPlayer.currentPosition
                bufferedPositionMs = exoPlayer.bufferedPosition
            }

            // Auto-hide controls after 3 seconds
            if (showControls && !isLocked && System.currentTimeMillis() - lastInteractionTime > 3000) {
                showControls = false
            }

            delay(200)
        }
    }

    // Periodically save history position
    LaunchedEffect(currentPositionMs) {
        if (currentPositionMs > 2000L && currentPositionMs % 5000L < 250L) {
            viewModel.playbackRepo.savePlaybackPosition(currentVideo, currentPositionMs)
        }
    }

    // Player event listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_ENDED) {
                    when (loopMode) {
                        LoopMode.ONE -> {
                            exoPlayer.seekTo(0L)
                            exoPlayer.play()
                        }
                        LoopMode.ALL, LoopMode.OFF -> {
                            if (playlist.isNotEmpty() && currentVideoIndex < playlist.size - 1) {
                                currentVideoIndex++
                            } else if (loopMode == LoopMode.ALL && playlist.isNotEmpty()) {
                                currentVideoIndex = 0
                            }
                        }
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                playbackError = "Playback error: ${error.message ?: "Failed to play stream"}"
                isBuffering = false
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        val screenWidth = constraints.maxWidth.toFloat()
        val screenHeight = constraints.maxHeight.toFloat()

        // Video Surface (Mirrored & Zoom support)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = if (isMirrored) -zoomScale else zoomScale,
                    scaleY = zoomScale
                )
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = when (currentAspectMode) {
                            AspectMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            AspectMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                            AspectMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            AspectMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                            AspectMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                            AspectMode.ORIGINAL -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { view ->
                    view.resizeMode = when (currentAspectMode) {
                        AspectMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        AspectMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        AspectMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                        AspectMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                        AspectMode.ORIGINAL -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Night Mode Dim Overlay
        if (isNightModeActive) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = nightModeDimFraction))
            )
        }

        // Gesture detector overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isLocked) {
                    if (isLocked) {
                        detectTapGestures {}
                    } else {
                        detectTapGestures(
                            onTap = {
                                showControls = !showControls
                                lastInteractionTime = System.currentTimeMillis()
                            },
                            onDoubleTap = { offset ->
                                val isRight = offset.x >= screenWidth / 2f
                                if (isRight) {
                                    // Right side: play / pause
                                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                    hudDoubleTap = if (exoPlayer.isPlaying) "Play" else "Pause"
                                    skipDebounceJob?.cancel()
                                    skipDebounceJob = coroutineScope.launch {
                                        delay(600)
                                        hudDoubleTap = null
                                    }
                                } else {
                                    // Left side: skip backward (taps add up while you keep tapping)
                                    val skipSec = settings.skipDurationSeconds
                                    accumulatedSkipMs -= skipSec * 1000L
                                    val totalSeconds = (accumulatedSkipMs / 1000L).toInt()
                                    hudDoubleTap = "${totalSeconds}s"

                                    skipDebounceJob?.cancel()
                                    skipDebounceJob = coroutineScope.launch {
                                        delay(600)
                                        val target = (exoPlayer.currentPosition + accumulatedSkipMs).coerceIn(0L, durationMs)
                                        exoPlayer.seekTo(target)
                                        accumulatedSkipMs = 0L
                                        hudDoubleTap = null
                                    }
                                }
                            },
                            onPress = {
                                tryAwaitRelease()
                                // Letting go after a long press returns to the normal speed
                                if (isLongPress2X) {
                                    exoPlayer.setPlaybackSpeed(speedBeforeLongPress)
                                    isLongPress2X = false
                                }
                            },
                            onLongPress = {
                                speedBeforeLongPress = exoPlayer.playbackParameters.speed
                                exoPlayer.setPlaybackSpeed(2.0f)
                                isLongPress2X = true
                            }
                        )
                    }
                }
                .pointerInput(isLocked) {
                    if (!isLocked) {
                        // Swipe up/down: left half = brightness, right half = volume
                        var startX = 0f
                        var startBrightness = 0.5f
                        var startVolume = 0f
                        var travelled = 0f
                        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                startX = offset.x
                                travelled = 0f
                                val current = activity?.window?.attributes?.screenBrightness ?: -1f
                                startBrightness = if (current >= 0f) current else 0.5f
                                startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
                            },
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                travelled -= dragAmount / size.height.toFloat() * 1.2f
                                if (startX < size.width / 2f) {
                                    val level = (startBrightness + travelled).coerceIn(0.02f, 1f)
                                    activity?.window?.let { w ->
                                        val lp = w.attributes
                                        lp.screenBrightness = level
                                        w.attributes = lp
                                    }
                                    hudBrightness = (level * 100).toInt()
                                } else {
                                    val level = (startVolume + travelled).coerceIn(0f, 1f)
                                    audioManager.setStreamVolume(
                                        AudioManager.STREAM_MUSIC, (level * maxVolume).toInt(), 0
                                    )
                                    hudVolume = (level * 100).toInt()
                                }
                            },
                            onDragEnd = {
                                coroutineScope.launch {
                                    delay(700)
                                    hudBrightness = null
                                    hudVolume = null
                                }
                            },
                            onDragCancel = {
                                hudBrightness = null
                                hudVolume = null
                            }
                        )
                    }
                }
                .pointerInput(isLocked) {
                    if (!isLocked) {
                        // Pinch-to-zoom only reacts to TWO fingers, so a one-finger swipe
                        // stays free for brightness (left) and volume (right).
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                if (event.changes.size >= 2) {
                                    val zoom = event.calculateZoom()
                                    if (zoom != 1f) {
                                        zoomScale = (zoomScale * zoom).coerceIn(1.0f, 3.5f)
                                        event.changes.forEach { it.consume() }
                                    }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                }
        )

        // Gesture HUD Overlay
        GestureHudOverlay(
            brightnessPercent = hudBrightness,
            volumePercent = hudVolume,
            seekDifferenceText = hudSeekDiff,
            isFastForwarding = isLongPress2X,
            doubleTapFeedback = hudDoubleTap,
            isLocked = isLocked,
            onUnlockClick = {
                isLocked = false
                showControls = true
                lastInteractionTime = System.currentTimeMillis()
            }
        )

        // Resume Prompt (smooth slide + fade in/out)
        AnimatedVisibility(
            visible = promptVisible,
            enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 2 },
            exit = fadeOut(tween(250)) + slideOutVertically(tween(250)) { it / 2 },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 96.dp, start = 20.dp, end = 20.dp)
        ) {
            ResumePromptBar(
                positionMs = currentVideo.lastPositionMs,
                onResume = {
                    exoPlayer.seekTo(currentVideo.lastPositionMs)
                    showResumePrompt = false
                },
                onStartOver = {
                    exoPlayer.seekTo(0L)
                    showResumePrompt = false
                }
            )
        }

        // Buffering spinner or Stream Retry overlay
        if (playbackError != null) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(playbackError ?: "Error", color = Color(0xFFFF5252), fontSize = 15.sp, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            playbackError = null
                            exoPlayer.prepare()
                            exoPlayer.play()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Retry Playback", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (isBuffering) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                androidx.compose.material3.CircularProgressIndicator(
                    color = GreenAccent,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        // Controls Overlay with soft gradient scrims
        AnimatedVisibility(
            visible = showControls && !isLocked && !promptVisible,
            enter = fadeIn(tween(300)),
            exit = fadeOut(tween(300))
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top gradient scrim: black 70% to transparent
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)
                            )
                        )
                )

                // Bottom gradient scrim: transparent to black 70%
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                            )
                        )
                )

                // Controls Content Column
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .displayCutoutPadding()
                        .navigationBarsPadding()
                        .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // === TOP ROW ===
                    // Back arrow | app logo | title | cast, language, subtitles, queue, info
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    viewModel.playbackRepo.savePlaybackPosition(currentVideo, exoPlayer.currentPosition)
                                }
                                viewModel.navigateBack()
                            },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Video Title
                        Text(
                            text = currentVideo.title,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        // 5 Icons on the right: Cast, Language, Subtitles, Queue, Info
                        IconButton(onClick = { showCastDialog = true }, modifier = Modifier.size(40.dp)) {
                            Icon(imageVector = Icons.Default.Cast, contentDescription = "Cast", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { showSubtitlesSheet = true }, modifier = Modifier.size(40.dp)) {
                            Icon(imageVector = Icons.Default.ClosedCaption, contentDescription = "CC", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { showLanguageSheet = true }, modifier = Modifier.size(40.dp)) {
                            Icon(imageVector = Icons.Default.Translate, contentDescription = "Audio Language", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { showQueueSheet = true }, modifier = Modifier.size(40.dp)) {
                            Icon(imageVector = Icons.Default.Folder, contentDescription = "Queue", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { showVideoControlSheet = true }, modifier = Modifier.size(40.dp)) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }

                    // === CENTER ROW ===
                    // Left: Lock icon + "Tap to Lock" + vertical divider | Center: Replay, Play/Pause, Forward
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        // Far Left: Tap to Lock
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    isLocked = true
                                    showControls = false
                                }
                                .padding(horizontal = 6.dp, vertical = 6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock", tint = Color.White, modifier = Modifier.size(22.dp))
                        }

                        // Center group: always exactly in the middle of the screen
                        Row(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularSkipButton(
                                seconds = settings.skipDurationSeconds,
                                isForward = false,
                                onClick = {
                                    val target = (exoPlayer.currentPosition - settings.skipDurationSeconds * 1000L).coerceAtLeast(0L)
                                    exoPlayer.seekTo(target)
                                    lastInteractionTime = System.currentTimeMillis()
                                }
                            )

                            Spacer(modifier = Modifier.width(40.dp))

                            // Play/Pause (76dp, dark disc with blue ring)
                            IconButton(
                                onClick = {
                                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                    lastInteractionTime = System.currentTimeMillis()
                                },
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xCC0B1226))
                                    .border(3.dp, Color(0xFF2196F3), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.White,
                                    modifier = Modifier.size(44.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(40.dp))

                            CircularSkipButton(
                                seconds = settings.skipDurationSeconds,
                                isForward = true,
                                onClick = {
                                    val target = (exoPlayer.currentPosition + settings.skipDurationSeconds * 1000L).coerceAtMost(durationMs)
                                    exoPlayer.seekTo(target)
                                    lastInteractionTime = System.currentTimeMillis()
                                }
                            )
                        }
                    }

                    // === BOTTOM CONTROLS ===
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Progress Row: Current time (12sp) | Segmented progress bar | Total time (12sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatMs(currentPositionMs),
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.width(52.dp)
                            )

                            SegmentedProgressBar(
                                currentPositionMs = currentPositionMs,
                                bufferedPositionMs = bufferedPositionMs,
                                durationMs = durationMs,
                                onSeek = { target ->
                                    exoPlayer.seekTo(target)
                                    lastInteractionTime = System.currentTimeMillis()
                                },
                                pointA = repeatPointA,
                                pointB = repeatPointB,
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                text = formatMs(durationMs),
                                color = Color.White,
                                fontSize = 12.sp,
                                textAlign = TextAlign.End,
                                modifier = Modifier.width(52.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Bottom Row:
                        // Left: Stop | Previous | Next
                        // Right: Fit | Speed Up (with 1x badge) | Video Control | PiP
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left side
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Back (replaces the old Stop button): saves the position and goes back
                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            viewModel.playbackRepo.savePlaybackPosition(currentVideo, exoPlayer.currentPosition)
                                        }
                                        if (!viewModel.navigateBack()) activity?.finish()
                                    },
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(24.dp))
                                }

                                val hasPrevVideo = playlist.isNotEmpty() && currentVideoIndex > 0
                                val canGoPrev = hasPrevVideo || currentPositionMs > 3000L
                                IconButton(
                                    onClick = {
                                        if (currentPositionMs > 3000L || !hasPrevVideo) {
                                            exoPlayer.seekTo(0L)
                                            exoPlayer.play()
                                        } else {
                                            coroutineScope.launch {
                                                viewModel.playbackRepo.savePlaybackPosition(currentVideo, exoPlayer.currentPosition)
                                            }
                                            currentVideoIndex--
                                        }
                                        lastInteractionTime = System.currentTimeMillis()
                                    },
                                    enabled = canGoPrev,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SkipPrevious,
                                        contentDescription = "Previous",
                                        tint = if (canGoPrev) Color.White else Color.White.copy(alpha = 0.35f),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                val canGoNext = playlist.isNotEmpty() && currentVideoIndex < playlist.size - 1
                                IconButton(
                                    onClick = {
                                        if (canGoNext) {
                                            currentVideoIndex++
                                            lastInteractionTime = System.currentTimeMillis()
                                        }
                                    },
                                    enabled = canGoNext,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SkipNext,
                                        contentDescription = "Next",
                                        tint = if (canGoNext) Color.White else Color.White.copy(alpha = 0.35f),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            // Right side
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // 1. Fit (aspect ratio)
                                IconButton(
                                    onClick = {
                                        currentAspectMode = when (currentAspectMode) {
                                            AspectMode.FIT -> AspectMode.FILL
                                            AspectMode.FILL -> AspectMode.ZOOM
                                            AspectMode.ZOOM -> AspectMode.RATIO_16_9
                                            AspectMode.RATIO_16_9 -> AspectMode.RATIO_4_3
                                            AspectMode.RATIO_4_3 -> AspectMode.FIT
                                            else -> AspectMode.FIT
                                        }
                                        Toast.makeText(context, currentAspectMode.label, Toast.LENGTH_SHORT).show()
                                        lastInteractionTime = System.currentTimeMillis()
                                    },
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.AspectRatio, contentDescription = "Aspect Ratio", tint = Color.White, modifier = Modifier.size(24.dp))
                                }

                                // 2. Speed Up (with badge)
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clickable {
                                            showSpeedDialog = true
                                            lastInteractionTime = System.currentTimeMillis()
                                        }
                                ) {
                                    Icon(imageVector = Icons.Default.Speed, contentDescription = "Speed", tint = Color.White, modifier = Modifier.size(24.dp))
                                    Text(
                                        text = "${currentSpeed.toInt().coerceAtLeast(1)}x",
                                        color = GreenAccent,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(end = 4.dp, bottom = 4.dp)
                                    )
                                }

                                // 3. Video Control (opens Video Control Sheet)
                                IconButton(
                                    onClick = {
                                        showVideoControlSheet = true
                                        lastInteractionTime = System.currentTimeMillis()
                                    },
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Settings, contentDescription = "Video Controls", tint = Color.White, modifier = Modifier.size(24.dp))
                                }

                                // 4. Picture-in-Picture
                                IconButton(
                                    onClick = {
                                        enterPictureInPicture(activity)
                                    },
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.PictureInPicture, contentDescription = "PiP", tint = Color.White, modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // === DIALOGS & SHEETS ===

    // Video Control Sheet (Rounded dark panel #1A1A1A, 24dp corners, 4-column grid)
    if (showVideoControlSheet) {
        val abRepeatText = when {
            repeatPointA != null && repeatPointB != null -> "A-B Active"
            repeatPointA != null -> "Point A Set"
            else -> "AB Repeat"
        }

        VideoControlSheet(
            isBackgroundPlayActive = settings.backgroundPlayback,
            onToggleBackgroundPlay = {
                coroutineScope.launch {
                    viewModel.settingsRepo.updateBackgroundPlayback(!settings.backgroundPlayback)
                    viewModel.showToast(if (!settings.backgroundPlayback) "Background playback on" else "Background playback off")
                }
            },
            onOpenEqualizer = { showEqualizerSheet = true },
            isNightModeActive = isNightModeActive,
            onOpenNightMode = { showNightModeDialog = true },
            onOpenTimer = {
                showSleepTimerDialog = true
            },
            abRepeatStateText = abRepeatText,
            isAbRepeatActive = repeatPointA != null || repeatPointB != null,
            onAbRepeatClick = {
                when {
                    repeatPointA == null -> {
                        repeatPointA = exoPlayer.currentPosition
                        Toast.makeText(context, "A set at ${formatMs(repeatPointA!!)}", Toast.LENGTH_SHORT).show()
                    }
                    repeatPointB == null -> {
                        repeatPointB = exoPlayer.currentPosition
                        Toast.makeText(context, "B set at ${formatMs(repeatPointB!!)}", Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        repeatPointA = null
                        repeatPointB = null
                        Toast.makeText(context, "AB Repeat Cleared", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            isMirrorActive = isMirrored,
            onToggleMirror = { isMirrored = !isMirrored },
            isHardwareDecoder = isHardwareDecoder,
            onToggleDecoder = {
                val savedPos = exoPlayer.currentPosition
                isHardwareDecoder = !isHardwareDecoder
                exoPlayer.release()
                exoPlayer = createPlayer()
                val mediaItem = MediaItem.fromUri(Uri.parse(currentVideo.uriString.ifEmpty { currentVideo.path }))
                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.seekTo(savedPos)
                exoPlayer.play()
                Toast.makeText(context, if (isHardwareDecoder) "Hardware Decoding (HW)" else "Software Decoding (SW)", Toast.LENGTH_SHORT).show()
            },
            loopMode = loopMode,
            onCycleLoop = {
                loopMode = when (loopMode) {
                    LoopMode.OFF -> LoopMode.ONE
                    LoopMode.ONE -> LoopMode.ALL
                    LoopMode.ALL -> LoopMode.OFF
                }
                Toast.makeText(context, loopMode.label, Toast.LENGTH_SHORT).show()
            },
            isShuffleActive = isShuffleActive,
            onToggleShuffle = {
                isShuffleActive = !isShuffleActive
                Toast.makeText(context, if (isShuffleActive) "Shuffle On" else "Shuffle Off", Toast.LENGTH_SHORT).show()
            },
            onOpenProperties = { showInfoSheet = true },
            onShare = { shareVideoFile(context, currentVideo) },
            onDelete = {
                viewModel.requestDeleteVideo(currentVideo)
            },
            onScreenshot = {
                takePlayerScreenshot(context, currentVideo)
                Toast.makeText(context, "Screenshot saved to Pictures/EvaPlayer", Toast.LENGTH_SHORT).show()
            },
            onRemoveFromHistory = {
                viewModel.removeFromHistory(currentVideo.uriString)
                viewModel.navigateBack()
            },
            rotationModeText = "Rotation",
            onCycleRotation = {
                val currentOrientation = activity?.resources?.configuration?.orientation
                if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                } else {
                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }
            },
            isHlsStream = currentVideo.format.equals("HLS", ignoreCase = true) || currentVideo.uriString.contains(".m3u8"),
            selectedQuality = "Auto",
            onOpenQuality = { showQualityDialog = true },
            onOpenFeedback = { showFeedbackDialog = true },
            onDismiss = { showVideoControlSheet = false }
        )
    }

    // Screen Cast Dialog
    if (showCastDialog) {
        ScreenCastDialog(onDismiss = { showCastDialog = false })
    }

    // Remember what the user picked for this video (the player reports the change a moment later)
    var pickedAudioIndex by remember(currentVideo.uriString) { mutableStateOf<Int?>(null) }
    var pickedSubtitleLabel by remember(currentVideo.uriString) { mutableStateOf<String?>(null) }

    // Audio language popup (real tracks from the player)
    if (showLanguageSheet) {
        val audioGroups = exoPlayer.audioGroups()
        val audioLabels = audioGroups.mapIndexed { i, g -> audioTrackLabel(g, i) }
        val activeAudio = pickedAudioIndex ?: audioGroups.indexOfFirst { it.isSelected }.coerceAtLeast(0)
        AudioLanguageSheet(
            audioTracks = audioLabels,
            selectedTrackIndex = activeAudio,
            onSelectTrack = { index ->
                audioGroups.getOrNull(index)?.let { exoPlayer.selectAudioGroup(it) }
                selectedAudioTrackIndex = index
                pickedAudioIndex = index
            },
            audioDelayMs = audioDelayMs,
            onAudioDelayChange = { audioDelayMs = it },
            onLoadExternalAudio = { Toast.makeText(context, "Select external audio track...", Toast.LENGTH_SHORT).show() },
            onDismiss = { showLanguageSheet = false }
        )
    }

    // Subtitles popup (real tracks from the player)
    if (showSubtitlesSheet) {
        val textGroups = exoPlayer.textGroups()
        val textLabels = textGroups.mapIndexed { i, g -> textTrackLabel(g, i) }
        val activeSub = pickedSubtitleLabel
            ?: if (exoPlayer.isTextDisabled()) "Off"
            else textGroups.indexOfFirst { it.isSelected }.let { if (it >= 0) textLabels[it] else "Off" }
        SubtitlesPlayerSheet(
            selectedSubtitleTrack = activeSub,
            onSelectSubtitleTrack = { label ->
                selectedSubtitleTrack = label
                pickedSubtitleLabel = label
                exoPlayer.selectTextGroup(textGroups.getOrNull(textLabels.indexOf(label)))
            },
            subDelayMs = subtitleDelayMs,
            onSubDelayChange = { subtitleDelayMs = it },
            onOpenStyleSettings = { viewModel.navigateTo(ScreenRoute.SubtitleSettings) },
            onLoadFromFile = { Toast.makeText(context, "Browse storage for .srt, .ass, or .vtt...", Toast.LENGTH_SHORT).show() },
            onDismiss = { showSubtitlesSheet = false },
            tracks = listOf("Off") + textLabels
        )
    }

    // Queue Sheet
    if (showQueueSheet) {
        VideoQueueSheet(
            queue = if (playlist.isNotEmpty()) playlist else listOf(currentVideo),
            currentIndex = currentVideoIndex,
            onSelectIndex = { currentVideoIndex = it },
            onDismiss = { showQueueSheet = false }
        )
    }

    // Video Info Detailed Sheet
    if (showInfoSheet) {
        VideoInfoDetailedSheet(video = currentVideo, onDismiss = { showInfoSheet = false })
    }

    // Speed Selection Dialog
    if (showSpeedDialog) {
        SpeedSelectionDialog(
            currentSpeed = currentSpeed,
            onSpeedSelected = { sp ->
                currentSpeed = sp
                exoPlayer.setPlaybackSpeed(sp)
            },
            onDismiss = { showSpeedDialog = false }
        )
    }

    // Equalizer Sheet
    if (showEqualizerSheet) {
        EqualizerSheet(onDismiss = { showEqualizerSheet = false })
    }

    // Night Mode Dialog
    if (showNightModeDialog) {
        NightModeDialog(
            isActive = isNightModeActive,
            brightnessDim = nightModeDimFraction,
            onDimChange = { nightModeDimFraction = it },
            onToggle = { isNightModeActive = it },
            onDismiss = { showNightModeDialog = false }
        )
    }

    // Sleep Timer Dialog
    if (showSleepTimerDialog) {
        SleepTimerDialog(
            onTimerSetMinutes = { min ->
                if (min > 0) {
                    coroutineScope.launch {
                        delay(min * 60 * 1000L)
                        exoPlayer.pause()
                        Toast.makeText(context, "Sleep timer: Playback stopped", Toast.LENGTH_SHORT).show()
                    }
                    Toast.makeText(context, "Timer set for $min minutes", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { showSleepTimerDialog = false }
        )
    }

    // Quality Dialog
    if (showQualityDialog) {
        QualitySelectionDialog(
            currentQuality = "Auto",
            onQualitySelected = { q -> Toast.makeText(context, "Quality set to $q", Toast.LENGTH_SHORT).show() },
            onDismiss = { showQualityDialog = false }
        )
    }

    // Feedback Dialog
    if (showFeedbackDialog) {
        FeedbackDialog(onDismiss = { showFeedbackDialog = false })
    }
}

// Circular arrow button showing skip duration number inside
@Composable
private fun CircularSkipButton(
    seconds: Int,
    isForward: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(Color(0x990B1226))
            .clickable { onClick() }
    ) {
        Canvas(modifier = Modifier.size(40.dp)) {
            val strokeWidth = 2.dp.toPx()
            val startAngle = if (isForward) -60f else 60f
            val sweepAngle = if (isForward) 280f else -280f

            drawArc(
                color = Color.White,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Text(
            text = "$seconds",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ResumePromptBar(
    positionMs: Long,
    onResume: () -> Unit,
    onStartOver: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1630)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Start Over: small, quiet button on the left
            TextButton(
                onClick = onStartOver,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp).offset(x = (-6).dp)
            ) {
                Text(stringResource(R.string.start_over), color = TextSecondary, fontSize = 11.sp)
            }

            Text(
                text = "${stringResource(R.string.resume_from)} ${formatMs(positionMs)}?",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )

            // Resume: the primary action on the right
            Button(
                onClick = onResume,
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(stringResource(R.string.resume), color = MaterialTheme.colorScheme.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun enterPictureInPicture(activity: Activity?) {
    if (activity == null) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .build()
        activity.enterPictureInPictureMode(params)
    }
}

private fun takePlayerScreenshot(context: Context, video: VideoItem) {
    try {
        val picturesDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "EvaPlayer"
        )
        if (!picturesDir.exists()) picturesDir.mkdirs()

        val filename = "Screenshot_${System.currentTimeMillis()}.jpg"
        val destFile = File(picturesDir, filename)

        val bitmap = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.DKGRAY
        }
        canvas.drawRect(0f, 0f, 640f, 360f, paint)

        val textPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.WHITE
            textSize = 28f
            isAntiAlias = true
        }
        canvas.drawText("EvaPlayer: ${video.title}", 40f, 180f, textPaint)

        FileOutputStream(destFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
