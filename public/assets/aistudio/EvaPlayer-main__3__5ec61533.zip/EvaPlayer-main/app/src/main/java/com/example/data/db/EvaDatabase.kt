package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlaybackRecord::class,
        FavoriteEntity::class,
        PlaylistEntity::class,
        PlaylistItemEntity::class,
        HiddenItemEntity::class,
        StreamLinkEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class EvaDatabase : RoomDatabase() {
    abstract fun evaDao(): EvaDao

    companion object {
        @Volatile
        private var INSTANCE: EvaDatabase? = null

        fun getDatabase(context: Context): EvaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EvaDatabase::class.java,
                    "evaplayer_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
