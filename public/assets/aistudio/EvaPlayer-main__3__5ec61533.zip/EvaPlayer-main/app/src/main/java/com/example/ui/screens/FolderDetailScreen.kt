package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SelectionBottomBar
import com.example.ui.components.SortBottomSheet
import com.example.ui.components.VideoGridCard
import com.example.ui.components.VideoListCard
import com.example.ui.components.VideoSelectionTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute

/**
 * Folder contents. Top action bar (back, title, 3-dot) plus a sub-row with
 * list/grid toggle and the Sort-by sheet (Name / Date / Length / Size, A to Z / Z to A).
 */
@Composable
fun FolderDetailScreen(
    folderName: String,
    folderPath: String,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val displayedVideos by viewModel.displayedVideos.collectAsState()
    val selectedUris by viewModel.selectedUris.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()
    val isGrid by viewModel.isVideoGrid.collectAsState()
    val isSelecting = selectedUris.isNotEmpty()
    val folderVideos = displayedVideos.filter {
        it.folderPath == folderPath || it.folderName == folderName
    }

    var showMenu by remember { mutableStateOf(false) }
    var showSort by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        if (isSelecting) {
            VideoSelectionTopBar(viewModel = viewModel, videos = folderVideos)
        } else {
            Surface(
                color = DarkSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(56.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Text(
                        text = folderName,
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp)
                    )
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Sort by", color = TextPrimary) },
                                onClick = { showMenu = false; showSort = true }
                            )
                            DropdownMenuItem(
                                text = { Text(if (isGrid) "List view" else "Grid view", color = TextPrimary) },
                                onClick = { showMenu = false; viewModel.toggleVideoGrid() }
                            )
                            DropdownMenuItem(
                                text = { Text("Select all", color = TextPrimary) },
                                onClick = { showMenu = false; viewModel.selectAll(folderVideos) }
                            )
                            DropdownMenuItem(
                                text = { Text("Refresh", color = TextPrimary) },
                                onClick = { showMenu = false; viewModel.refreshMedia() }
                            )
                        }
                    }
                }
            }

            // Sub-row: view toggle + sort
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.toggleVideoGrid() }) {
                    Icon(
                        imageVector = if (isGrid) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                        contentDescription = "Toggle list / grid",
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                IconButton(onClick = { showSort = true }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Sort,
                        contentDescription = "Sort",
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        if (folderVideos.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp)
            ) {
                Text("No videos in this folder", color = TextSecondary, fontSize = 15.sp)
            }
        } else {
            val bottomPad = if (isSelecting) 16.dp else 80.dp
            val openVideo: (com.example.data.model.VideoItem) -> Unit = { video ->
                viewModel.navigateTo(
                    ScreenRoute.Player(
                        video = video,
                        playlist = folderVideos,
                        startIndex = folderVideos.indexOf(video)
                    )
                )
            }
            val feed = com.example.ads.withAdSlots(folderVideos, com.example.ads.AdsterraConfig.FOLDER_VIDEO_EVERY, com.example.ads.AdsterraConfig.FOLDER_VIDEO_MAX_ADS)
            if (isGrid) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = bottomPad),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(
                        feed,
                        key = { e -> when (e) {
                            is com.example.ads.FeedEntry.Item -> e.value.uriString
                            is com.example.ads.FeedEntry.AdSlot -> "folder_grid_ad_${e.index}"
                        } },
                        span = { e -> if (e is com.example.ads.FeedEntry.AdSlot) GridItemSpan(maxLineSpan) else GridItemSpan(1) }
                    ) { entry ->
                        when (entry) {
                            is com.example.ads.FeedEntry.AdSlot ->
                                com.example.ads.InFeedAd(slotKey = "folder_grid_${entry.index}", small = true)
                            is com.example.ads.FeedEntry.Item -> {
                                val video = entry.value
                        VideoGridCard(
                            video = video,
                            isSelectionMode = isSelecting,
                            isSelected = video.uriString in selectedUris,
                            onLongClick = { viewModel.toggleSelection(video) },
                            onClick = {
                                if (isSelecting) viewModel.toggleSelection(video) else openVideo(video)
                            },
                            onMenuClick = { viewModel.openActionSheet(video) }
                        )
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = bottomPad)
                ) {
                    items(
                        feed,
                        key = { e -> when (e) {
                            is com.example.ads.FeedEntry.Item -> e.value.uriString
                            is com.example.ads.FeedEntry.AdSlot -> "folder_list_ad_${e.index}"
                        } }
                    ) { entry ->
                        when (entry) {
                            is com.example.ads.FeedEntry.AdSlot ->
                                com.example.ads.InFeedAd(slotKey = "folder_list_${entry.index}", small = true)
                            is com.example.ads.FeedEntry.Item -> {
                                val video = entry.value
                        VideoListCard(
                            video = video,
                            isSelectionMode = isSelecting,
                            isSelected = video.uriString in selectedUris,
                            onLongClick = { viewModel.toggleSelection(video) },
                            onClick = {
                                if (isSelecting) viewModel.toggleSelection(video) else openVideo(video)
                            },
                            onMenuClick = { viewModel.openActionSheet(video) },
                            modifier = Modifier.padding(bottom = 10.dp)
                        )
                            }
                        }
                    }
                }
            }
        }

        if (isSelecting) {
            SelectionBottomBar(viewModel = viewModel, visibleVideos = folderVideos)
        }
    }

    if (showSort) {
        SortBottomSheet(
            current = sortMode,
            onApply = { viewModel.setSortMode(it) },
            onDismiss = { showSort = false }
        )
    }
}
