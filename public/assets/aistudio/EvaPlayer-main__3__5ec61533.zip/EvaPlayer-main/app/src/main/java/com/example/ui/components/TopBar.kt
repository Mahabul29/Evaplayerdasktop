package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.player.ScreenCastDialog
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.SortMode

/**
 * App top bar.
 *  - Home / Videos: text-only "EvaPLAYER" on the left, Cast + Search + 3-dot on the right.
 *  - The 3-dot menu holds Sort by (opens the PLAYit-style sheet), Refresh and Settings.
 *  - Sub screens: back arrow + title.
 */
/** True while a bottom sheet / drawer is open; the top bar hides itself so it never shows through. */
val LocalSheetOpen = androidx.compose.runtime.compositionLocalOf { false }

@Composable
fun EvaTopBar(
    title: String = "EvaPlayer",
    canNavigateBack: Boolean = false,
    onNavigateBack: () -> Unit = {},
    isSearchOpen: Boolean = false,
    searchQuery: String = "",
    onSearchQueryChange: (String) -> Unit = {},
    onSearchToggle: (Boolean) -> Unit = {},
    sortMode: SortMode = SortMode.NAME_ASC,
    onSortModeChange: (SortMode) -> Unit = {},
    onSettingsClick: () -> Unit = {},
    showSearchAndSort: Boolean = true,
    onRefreshClick: (() -> Unit)? = null
) {
    val focusManager = LocalFocusManager.current
    var showMenu by remember { mutableStateOf(false) }
    var showSortSheet by remember { mutableStateOf(false) }
    var showCastDialog by remember { mutableStateOf(false) }

    val sheetOpen = LocalSheetOpen.current
    Surface(
        color = DarkSurface,
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .statusBarsPadding()
            .height(56.dp)
            .alpha(if (sheetOpen) 0f else 1f)
    ) {
        if (isSearchOpen) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onSearchToggle(false) }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search", tint = TextPrimary)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    if (searchQuery.isEmpty()) {
                        Text("Search videos, folders...", style = TextStyle(color = TextSecondary, fontSize = 16.sp))
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        singleLine = true,
                        textStyle = TextStyle(color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Normal),
                        cursorBrush = SolidColor(GreenAccent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear search", tint = TextSecondary)
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(start = if (canNavigateBack) 4.dp else 18.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (canNavigateBack) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                }

                val isBrand = !canNavigateBack && title == "EvaPlayer"
                if (isBrand) {
                    // Text only, no logo: "Eva" white + "PLAYER" accent (ArcPlayer style)
                    Text(
                        text = buildAnnotatedString {
                            withStyle(SpanStyle(color = TextPrimary)) { append("Eva") }
                            withStyle(SpanStyle(color = GreenAccent)) { append("PLAYER") }
                        },
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Text(
                        text = title,
                        style = TextStyle(color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp)
                    )
                }

                if (showSearchAndSort) {
                    IconButton(onClick = { showCastDialog = true }) {
                        Icon(Icons.Default.Cast, contentDescription = "Cast", tint = TextPrimary)
                    }
                    IconButton(onClick = { onSearchToggle(true) }) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = TextPrimary)
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Sort by", color = TextPrimary) },
                                onClick = { showMenu = false; showSortSheet = true }
                            )
                            if (onRefreshClick != null) {
                                DropdownMenuItem(
                                    text = { Text("Refresh", color = TextPrimary) },
                                    onClick = { showMenu = false; onRefreshClick() }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Settings", color = TextPrimary) },
                                onClick = { showMenu = false; onSettingsClick() }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSortSheet) {
        SortBottomSheet(
            current = sortMode,
            onApply = onSortModeChange,
            onDismiss = { showSortSheet = false }
        )
    }
    if (showCastDialog) {
        ScreenCastDialog(onDismiss = { showCastDialog = false })
    }
}
