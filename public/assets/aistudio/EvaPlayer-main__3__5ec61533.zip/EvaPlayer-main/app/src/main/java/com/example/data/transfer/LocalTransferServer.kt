package com.example.data.transfer

import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class LocalTransferServer(private val context: Context) {

    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private var sharedItems: List<ShareItem> = emptyList()

    fun getLocalIpAddress(): String {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val wifiIp = wifiManager?.connectionInfo?.ipAddress ?: 0
            if (wifiIp != 0) {
                return Formatter.formatIpAddress(wifiIp)
            }
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isLoopback || !iface.isUp) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        return addr.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "192.168.1.50"
    }

    suspend fun startServer(port: Int = 8080, items: List<ShareItem>): String = withContext(Dispatchers.IO) {
        stopServer()
        sharedItems = items
        // Use the preferred port, or the next free one if it is busy
        var server: ServerSocket? = null
        var chosenPort = port
        for (candidate in port..(port + 10)) {
            try {
                server = ServerSocket(candidate)
                chosenPort = candidate
                break
            } catch (e: Exception) {
                // port busy, try next
            }
        }
        val activeServer: ServerSocket = server ?: throw java.io.IOException("No free port available")
        serverSocket = activeServer
        isRunning.set(true)

        val ip = getLocalIpAddress()
        val serverUrl = "http://$ip:$chosenPort"

        Thread {
            while (isRunning.get() && !activeServer.isClosed) {
                try {
                    val client = activeServer.accept()
                    Thread { handleClient(client) }.start()
                } catch (e: Exception) {
                    if (!isRunning.get()) break
                }
            }
        }.start()

        serverUrl
    }

    fun stopServer() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        serverSocket = null
    }

    private fun handleClient(socket: Socket) {
        try {
            socket.use { s ->
                val reader = s.getInputStream().bufferedReader()
                val line = reader.readLine() ?: return
                val parts = line.split(" ")
                if (parts.size < 2) return

                val method = parts[0]
                val path = parts[1]

                val out = BufferedOutputStream(s.getOutputStream())

                when {
                    path == "/api/files" -> {
                        // Return JSON array of shared files
                        val json = buildString {
                            append("[")
                            sharedItems.forEachIndexed { idx, v ->
                                if (idx > 0) append(",")
                                append("""{"id":$idx,"title":"${escapeJson(v.baseName)}","size":${v.sizeBytes},"format":"${escapeJson(v.extension)}"}""")
                            }
                            append("]")
                        }
                        sendHttpResponse(out, 200, "OK", "application/json", json.toByteArray())
                    }
                    path.startsWith("/download") -> {
                        val idParam = path.substringAfter("id=", "0").substringBefore("&").toIntOrNull() ?: 0
                        val item = sharedItems.getOrNull(idParam)
                        if (item != null) {
                            serveFile(out, item)
                        } else {
                            val notFound = "File not found"
                            sendHttpResponse(out, 404, "Not Found", "text/plain", notFound.toByteArray())
                        }
                    }
                    else -> {
                        // Serve Web Portal for easy browser download on any PC or phone
                        val html = buildWebPortalHtml(sharedItems)
                        sendHttpResponse(out, 200, "OK", "text/html; charset=utf-8", html.toByteArray())
                    }
                }
            }
        } catch (e: Exception) {
            // Socket or client closed
        }
    }

    private fun openStream(item: ShareItem): java.io.InputStream? {
        val file = if (item.path.isNotEmpty()) File(item.path) else null
        if (file != null && file.exists() && file.canRead()) return FileInputStream(file)
        return try {
            context.contentResolver.openInputStream(android.net.Uri.parse(item.uriString))
        } catch (e: Exception) {
            null
        }
    }

    private fun serveFile(out: OutputStream, item: ShareItem) {
        val stream = openStream(item)
        if (stream == null) {
            sendHttpResponse(out, 404, "Not Found", "text/plain", "File not available".toByteArray())
            return
        }
        val safeName = item.name.replace('"', '_')
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: ${item.mime}\r\n" +
                (if (item.sizeBytes > 0) "Content-Length: ${item.sizeBytes}\r\n" else "") +
                "Content-Disposition: attachment; filename=\"$safeName\"\r\n" +
                "Connection: close\r\n\r\n"

        out.write(header.toByteArray())
        out.flush()

        stream.use { input ->
            val buffer = ByteArray(64 * 1024)
            var bytesRead: Int
            while (input.read(buffer).also { bytesRead = it } != -1) {
                out.write(buffer, 0, bytesRead)
            }
            out.flush()
        }
    }

    private fun sendHttpResponse(out: OutputStream, code: Int, status: String, contentType: String, body: ByteArray) {
        val header = "HTTP/1.1 $code $status\r\n" +
                "Content-Type: $contentType\r\n" +
                "Content-Length: ${body.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.write(body)
        out.flush()
    }

    private fun buildWebPortalHtml(items: List<ShareItem>): String {
        return buildString {
            append("<!DOCTYPE html><html><head><meta charset='utf-8'><title>EvaPlayer Share</title>")
            append("<meta name='viewport' content='width=device-width, initial-scale=1'>")
            append("<style>body{background:#0F1117;color:#fff;font-family:sans-serif;padding:20px;}")
            append("h1{color:#4C8DFF;}ul{list-style:none;padding:0;}")
            append("li{background:#1E222D;margin:10px 0;padding:15px;border-radius:8px;display:flex;justify-content:space-between;align-items:center;}")
            append("a{background:#2F80FF;color:#fff;text-decoration:none;padding:8px 16px;border-radius:4px;font-weight:bold;}")
            append("</style></head><body>")
            append("<h1>EvaPlayer Wi-Fi Transfer</h1>")
            append("<p>Shared files (${items.size}):</p><ul>")
            items.forEachIndexed { index, item ->
                val shownName = item.name.replace('<', ' ')
                append("<li><span>$shownName (${item.sizeFormatted})</span>")
                append("<a href='/download?id=$index' download>Download</a></li>")
            }
            append("</ul></body></html>")
        }
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
    }
}
