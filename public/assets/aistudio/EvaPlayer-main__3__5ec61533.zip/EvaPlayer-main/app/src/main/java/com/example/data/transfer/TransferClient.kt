package com.example.data.transfer

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class RemoteFileItem(
    val id: Int,
    val title: String,
    val sizeBytes: Long,
    val format: String,
    var progress: Float = 0f,
    var speed: String = "",
    var isCompleted: Boolean = false,
    var isFailed: Boolean = false
)

class TransferClient(private val context: Context) {

    suspend fun fetchRemoteFiles(baseUrl: String): List<RemoteFileItem> = withContext(Dispatchers.IO) {
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl.dropLast(1) else baseUrl
        val target = "$cleanUrl/api/files"
        val url = URL(target)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 5000
        conn.readTimeout = 5000
        conn.requestMethod = "GET"

        try {
            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val jsonArray = JSONArray(response)
            val list = mutableListOf<RemoteFileItem>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    RemoteFileItem(
                        id = obj.getInt("id"),
                        title = obj.getString("title"),
                        sizeBytes = obj.optLong("size", 0L),
                        format = obj.optString("format", "mp4")
                    )
                )
            }
            list
        } finally {
            conn.disconnect()
        }
    }

    suspend fun downloadFile(
        baseUrl: String,
        fileItem: RemoteFileItem,
        onProgress: (progress: Float, speedStr: String) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl.dropLast(1) else baseUrl
        val target = "$cleanUrl/download?id=${fileItem.id}"
        val url = URL(target)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 30000

        try {
            // Prefer Movies/EvaPlayer/Received; fall back to the app's own folder if the system refuses writes
            val publicDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "EvaPlayer/Received"
            )
            val fileName = if (fileItem.format.isBlank()) fileItem.title else "${fileItem.title}.${fileItem.format.lowercase()}"
            var destinationFile = File(publicDir, fileName)
            val outputStream: FileOutputStream = try {
                publicDir.mkdirs()
                FileOutputStream(destinationFile)
            } catch (e: Exception) {
                val fallbackDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "Received")
                fallbackDir.mkdirs()
                destinationFile = File(fallbackDir, fileName)
                FileOutputStream(destinationFile)
            }
            val inputStream = BufferedInputStream(conn.inputStream)

            val totalBytes = if (conn.contentLengthLong > 0) conn.contentLengthLong else fileItem.sizeBytes
            var bytesReadTotal = 0L
            val buffer = ByteArray(64 * 1024)
            var bytes: Int
            val startTime = System.currentTimeMillis()

            while (inputStream.read(buffer).also { bytes = it } != -1) {
                outputStream.write(buffer, 0, bytes)
                bytesReadTotal += bytes

                val elapsedSec = ((System.currentTimeMillis() - startTime) / 1000.0).coerceAtLeast(0.1)
                val speedBytesPerSec = bytesReadTotal / elapsedSec
                val speedStr = String.format("%.1f MB/s", speedBytesPerSec / (1024 * 1024))
                val prog = if (totalBytes > 0) (bytesReadTotal.toFloat() / totalBytes).coerceIn(0f, 1f) else 0.5f

                onProgress(prog, speedStr)
            }

            outputStream.flush()
            outputStream.close()
            inputStream.close()

            destinationFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            conn.disconnect()
        }
    }
}
