package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EvaDao {
    // --- History ---
    @Query("SELECT * FROM playback_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<PlaybackRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateHistory(record: PlaybackRecord)

    @Query("DELETE FROM playback_history WHERE uriString = :uriString")
    suspend fun deleteHistoryByUri(uriString: String)

    @Query("DELETE FROM playback_history")
    suspend fun clearHistory()

    // --- Favorites ---
    @Query("SELECT * FROM favorites ORDER BY addedTimestamp DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE uriString = :uriString")
    suspend fun deleteFavoriteByUri(uriString: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE uriString = :uriString)")
    fun isFavorite(uriString: String): Flow<Boolean>

    // --- Playlists ---
    @Query("SELECT * FROM playlists ORDER BY createdTimestamp DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, newName: String)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun deletePlaylistItems(playlistId: Long)

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY orderIndex ASC")
    fun getPlaylistItems(playlistId: Long): Flow<List<PlaylistItemEntity>>

    @Query("SELECT COUNT(*) FROM playlist_items WHERE playlistId = :playlistId")
    fun getPlaylistItemCount(playlistId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE id = :itemId")
    suspend fun deletePlaylistItem(itemId: Long)

    @Query("DELETE FROM playlist_items WHERE uriString = :uriString")
    suspend fun removeVideoFromAllPlaylists(uriString: String)

    // --- Hidden Items ---
    @Query("SELECT * FROM hidden_items")
    fun getAllHiddenItems(): Flow<List<HiddenItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHiddenItem(item: HiddenItemEntity)

    @Query("DELETE FROM hidden_items WHERE path = :path")
    suspend fun deleteHiddenItem(path: String)

    @Query("DELETE FROM hidden_items")
    suspend fun clearAllHiddenItems()

    // --- Stream Links ---
    @Query("SELECT * FROM stream_links ORDER BY timestamp DESC")
    fun getAllStreamLinks(): Flow<List<StreamLinkEntity>>

    @Query("SELECT * FROM stream_links WHERE isSaved = 1 ORDER BY timestamp DESC")
    fun getSavedStreamLinks(): Flow<List<StreamLinkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateStreamLink(stream: StreamLinkEntity)

    @Query("DELETE FROM stream_links WHERE url = :url")
    suspend fun deleteStreamLink(url: String)
}
