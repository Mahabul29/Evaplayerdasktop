package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.fillMaxWidth
import com.example.ui.components.SelectionBottomBar
import com.example.ui.components.VideoSelectionTopBar
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoItem
import com.example.ui.components.EvaTopBar
import com.example.ui.components.VideoListCard
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute

@Composable
fun FavoritesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val displayedVideos by viewModel.displayedVideos.collectAsState()
    val favoriteVideos = displayedVideos.filter { it.isFavorite }
    val selectedUris by viewModel.selectedUris.collectAsState()
    val isSelecting = selectedUris.isNotEmpty()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        if (isSelecting) {
            VideoSelectionTopBar(viewModel = viewModel, videos = favoriteVideos)
        } else {
            EvaTopBar(
                title = "Favorites",
                canNavigateBack = true,
                onNavigateBack = { viewModel.navigateBack() },
                showSearchAndSort = false
            )
        }

        if (favoriteVideos.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp)
            ) {
                Text(
                    text = "No favorite videos yet. Tap Favorite in any video menu.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(favoriteVideos, key = { it.uriString }) { video ->
                    VideoListCard(
                        video = video,
                        isSelectionMode = isSelecting,
                        isSelected = video.uriString in selectedUris,
                        onLongClick = { viewModel.toggleSelection(video) },
                        onClick = {
                            if (isSelecting) { viewModel.toggleSelection(video); return@VideoListCard }
                            viewModel.navigateTo(
                                ScreenRoute.Player(
                                    video = video,
                                    playlist = favoriteVideos,
                                    startIndex = favoriteVideos.indexOf(video)
                                )
                            )
                        },
                        onMenuClick = { viewModel.openActionSheet(video) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }
        }

        if (isSelecting) {
            SelectionBottomBar(viewModel = viewModel, visibleVideos = favoriteVideos)
        }
    }
}
