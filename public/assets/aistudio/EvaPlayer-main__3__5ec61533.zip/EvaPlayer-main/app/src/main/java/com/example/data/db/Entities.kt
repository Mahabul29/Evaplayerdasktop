package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playback_history")
data class PlaybackRecord(
    @PrimaryKey val uriString: String,
    val path: String,
    val title: String,
    val durationMs: Long,
    val lastPositionMs: Long,
    val timestamp: Long,
    val folderPath: String = "",
    val isStream: Boolean = false
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val uriString: String,
    val title: String,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val uriString: String,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val orderIndex: Int = 0
)

@Entity(tableName = "hidden_items")
data class HiddenItemEntity(
    @PrimaryKey val path: String,
    val isFolder: Boolean,
    val hiddenTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "stream_links")
data class StreamLinkEntity(
    @PrimaryKey val url: String,
    val title: String,
    val lastPositionMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val isSaved: Boolean = false
)
