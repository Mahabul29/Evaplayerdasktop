package com.example.ui.player

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary

/** Subtitle picker, shown as a clean centred popup. [tracks] always starts with "Off". */
@Composable
fun SubtitlesPlayerSheet(
    selectedSubtitleTrack: String,
    onSelectSubtitleTrack: (String) -> Unit,
    subDelayMs: Int,
    onSubDelayChange: (Int) -> Unit,
    onOpenStyleSettings: () -> Unit,
    onLoadFromFile: () -> Unit,
    onDismiss: () -> Unit,
    tracks: List<String> = listOf("Off")
) {
    var delay by remember(subDelayMs) { mutableFloatStateOf(subDelayMs.toFloat()) }
    PlayerCenterDialog(title = "Subtitles", onDismiss = onDismiss) {
        tracks.forEach { track ->
            PlayerChoiceRow(
                label = track,
                selected = track == selectedSubtitleTrack,
                onClick = { onSelectSubtitleTrack(track) }
            )
        }
        HorizontalDivider(color = DividerDark, modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
            Text("Subtitle delay: ${delay.toInt()} ms", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Slider(
                value = delay.coerceIn(-5000f, 5000f),
                onValueChange = { delay = it },
                valueRange = -5000f..5000f,
                onValueChangeFinished = { onSubDelayChange(delay.toInt()) },
                colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
            )
            Row {
                TextButton(onClick = onLoadFromFile) { Text("Load file", color = GreenAccent) }
                TextButton(onClick = onOpenStyleSettings) { Text("Style", color = GreenAccent) }
            }
        }
    }
}
