package com.example.data.transfer

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URLEncoder
import java.util.Collections

/**
 * Helpers that make Wi-Fi sharing automatic:
 *  - the SENDER starts a local-only hotspot (no manual hotspot toggle) and puts its
 *    name, password and link into one QR code;
 *  - the RECEIVER scans that QR code and joins the hotspot by itself.
 *
 * Android does not allow apps to switch Wi-Fi on silently, so if Wi-Fi is off the UI
 * asks the user to turn it on first. On Android 10+ the receiver sees one system
 * "Connect?" confirmation; that cannot be skipped by any app.
 */
object WifiAuto {
    private const val SCHEME = "evaplayer://join"

    private val main = Handler(Looper.getMainLooper())
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    private fun wifi(ctx: Context) =
        ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private fun cm(ctx: Context) =
        ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun isWifiEnabled(ctx: Context): Boolean = try { wifi(ctx).isWifiEnabled } catch (e: Exception) { false }

    /** True when this phone is already connected to a Wi-Fi network (router or hotspot). */
    fun isOnWifi(ctx: Context): Boolean = try {
        val c = cm(ctx)
        val caps = c.getNetworkCapabilities(c.activeNetwork)
        caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    } catch (e: Exception) {
        false
    }

    // ---------------------------------------------------------------- sender

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun startHotspot(ctx: Context, onReady: (ssid: String, pass: String) -> Unit, onFail: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            onFail("Auto hotspot needs Android 8 or newer. Turn on your hotspot manually.")
            return
        }
        stopHotspot()
        try {
            wifi(ctx).startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    val (ssid, pass) = credentials(r)
                    if (ssid.isBlank()) onFail("Hotspot started but its name could not be read.")
                    else onReady(ssid, pass)
                }

                override fun onFailed(reason: Int) {
                    onFail("Could not start hotspot. Turn on Wi-Fi and Location, turn off any other hotspot, then try again.")
                }

                override fun onStopped() {
                    reservation = null
                }
            }, main)
        } catch (e: Exception) {
            onFail("Could not start hotspot: ${e.message ?: "permission missing"}")
        }
    }

    @Suppress("DEPRECATION")
    private fun credentials(r: WifiManager.LocalOnlyHotspotReservation): Pair<String, String> {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val c = r.softApConfiguration
                val ssid = if (Build.VERSION.SDK_INT >= 33) (c.wifiSsid?.toString() ?: "") else (c.ssid ?: "")
                ssid.trim('"') to (c.passphrase ?: "")
            } else {
                val c = r.wifiConfiguration
                (c?.SSID ?: "").trim('"') to (c?.preSharedKey ?: "").trim('"')
            }
        } catch (e: Exception) {
            "" to ""
        }
    }

    fun stopHotspot() {
        try { reservation?.close() } catch (e: Exception) { /* ignore */ }
        reservation = null
    }

    /** IPv4 address of this phone on the hotspot (or Wi-Fi) interface. */
    fun hotspotIp(): String? {
        try {
            for (iface in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!iface.isUp || iface.isLoopback) continue
                val n = iface.name.lowercase()
                if (!(n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan"))) continue
                for (a in Collections.list(iface.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress
                }
            }
        } catch (e: Exception) {
            // fall through
        }
        return null
    }

    fun buildPayload(ssid: String, pass: String, url: String): String {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        return "$SCHEME?s=${enc(ssid)}&p=${enc(pass)}&u=${enc(url)}"
    }

    // -------------------------------------------------------------- receiver

    class JoinInfo(val ssid: String, val pass: String, val url: String)

    fun isJoinPayload(text: String) = text.trim().startsWith(SCHEME)

    fun parsePayload(text: String): JoinInfo? = try {
        val u = Uri.parse(text.trim())
        val s = u.getQueryParameter("s")
        val p = u.getQueryParameter("p") ?: ""
        val l = u.getQueryParameter("u")
        if (s.isNullOrBlank() || l.isNullOrBlank()) null else JoinInfo(s, p, l)
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    fun connect(ctx: Context, ssid: String, pass: String, onConnected: () -> Unit, onFail: (String) -> Unit) {
        disconnect(ctx)
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val spec = WifiNetworkSpecifier.Builder()
                    .setSsid(ssid)
                    .setWpa2Passphrase(pass)
                    .build()
                val req = NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .setNetworkSpecifier(spec)
                    .build()
                val c = cm(ctx)
                val cb = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        c.bindProcessToNetwork(network)
                        main.post { onConnected() }
                    }

                    override fun onUnavailable() {
                        main.post { onFail("Could not join the sender's Wi-Fi. Please try again.") }
                    }

                    override fun onLost(network: Network) {
                        c.bindProcessToNetwork(null)
                    }
                }
                netCallback = cb
                c.requestNetwork(req, cb, 30_000)
            } catch (e: Exception) {
                onFail("Could not join Wi-Fi: ${e.message ?: "unknown error"}")
            }
        } else {
            try {
                val w = wifi(ctx)
                if (!w.isWifiEnabled) w.isWifiEnabled = true
                val conf = WifiConfiguration().apply {
                    SSID = "\"$ssid\""
                    preSharedKey = "\"$pass\""
                }
                val id = w.addNetwork(conf)
                if (id == -1) {
                    onFail("Could not add the sender's Wi-Fi.")
                    return
                }
                w.disconnect()
                w.enableNetwork(id, true)
                w.reconnect()
                main.postDelayed({ onConnected() }, 6000)
            } catch (e: Exception) {
                onFail("Could not join Wi-Fi: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun disconnect(ctx: Context) {
        try {
            netCallback?.let { cm(ctx).unregisterNetworkCallback(it) }
        } catch (e: Exception) { /* ignore */ }
        netCallback = null
        try {
            if (Build.VERSION.SDK_INT >= 23) cm(ctx).bindProcessToNetwork(null)
        } catch (e: Exception) { /* ignore */ }
    }
}
