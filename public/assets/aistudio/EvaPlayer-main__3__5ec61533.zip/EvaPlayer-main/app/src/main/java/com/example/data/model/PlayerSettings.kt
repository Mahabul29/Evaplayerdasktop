package com.example.data.model

data class PlayerSettings(
    // Appearance
    val theme: String = "Dark", // "Dark", "Light", "AMOLED"
    val accentColor: String = "Blue", // "White", "Green", "Purple", "Blue", "Red", "Orange", "Pink"
    val displayLanguage: String = "English", // "English", "Bangla", "Hindi"

    // Audio
    val defaultAudioLanguage: String = "Default",
    val audioBoostPercent: Int = 100, // 100% to 200%
    val audioDelayMs: Int = 0, // -500 to +500 ms
    val backgroundPlayback: Boolean = true,
    val pauseOnHeadphoneDisconnect: Boolean = true,
    val skipDurationSeconds: Int = 10, // 5, 10, 15, 20, 30, 60

    // Screen
    val orientation: String = "Auto", // "Auto", "Landscape", "Portrait"
    val keepScreenOn: Boolean = true,
    val pipEnabled: Boolean = true,
    val showBatteryAndTime: Boolean = true,
    val showLogoWatermark: Boolean = true,

    // Subtitles
    val defaultSubtitleLanguage: String = "Auto",
    val subTextSizeSp: Int = 18,
    val subTextColorHex: String = "#FFFFFF",
    val subBgColorHex: String = "#80000000",
    val subBold: Boolean = false,
    val subEdgeStyle: String = "Outline", // "Outline", "DropShadow", "None"
    val subPosition: String = "Bottom", // "Bottom", "Top"
    val subDelayMs: Int = 0,
    val subAutoLoadFromFolder: Boolean = true,
    val subEncoding: String = "UTF-8",

    // Privacy & Storage
    val appLockEnabled: Boolean = false,
    val appLockPin: String = "",
    val biometricEnabled: Boolean = false
)
