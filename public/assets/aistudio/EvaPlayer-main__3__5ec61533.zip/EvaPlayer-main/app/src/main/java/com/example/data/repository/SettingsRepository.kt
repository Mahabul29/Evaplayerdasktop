package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.PlayerSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "evaplayer_settings")

class SettingsRepository(private val context: Context) {

    private object PreferencesKeys {
        val THEME = stringPreferencesKey("theme")
        val ACCENT_COLOR = stringPreferencesKey("accent_color")
        val DISPLAY_LANGUAGE = stringPreferencesKey("display_language")
        val DEFAULT_AUDIO_LANG = stringPreferencesKey("default_audio_lang")
        val AUDIO_BOOST_PERCENT = intPreferencesKey("audio_boost_percent")
        val AUDIO_DELAY_MS = intPreferencesKey("audio_delay_ms")
        val BACKGROUND_PLAYBACK = booleanPreferencesKey("background_playback")
        val PAUSE_HEADPHONE_DISCONNECT = booleanPreferencesKey("pause_headphone_disconnect")
        val SKIP_DURATION_SECONDS = intPreferencesKey("skip_duration_seconds")
        val ORIENTATION = stringPreferencesKey("orientation")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val PIP_ENABLED = booleanPreferencesKey("pip_enabled")
        val SHOW_BATTERY_AND_TIME = booleanPreferencesKey("show_battery_and_time")
        val SHOW_LOGO_WATERMARK = booleanPreferencesKey("show_logo_watermark")
        val DEFAULT_SUB_LANG = stringPreferencesKey("default_sub_lang")
        val SUB_TEXT_SIZE_SP = intPreferencesKey("sub_text_size_sp")
        val SUB_TEXT_COLOR_HEX = stringPreferencesKey("sub_text_color_hex")
        val SUB_BG_COLOR_HEX = stringPreferencesKey("sub_bg_color_hex")
        val SUB_BOLD = booleanPreferencesKey("sub_bold")
        val SUB_EDGE_STYLE = stringPreferencesKey("sub_edge_style")
        val SUB_POSITION = stringPreferencesKey("sub_position")
        val SUB_DELAY_MS = intPreferencesKey("sub_delay_ms")
        val SUB_AUTO_LOAD = booleanPreferencesKey("sub_auto_load")
        val SUB_ENCODING = stringPreferencesKey("sub_encoding")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val APP_LOCK_PIN = stringPreferencesKey("app_lock_pin")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
    }

    val settingsFlow: Flow<PlayerSettings> = context.dataStore.data.map { preferences ->
        PlayerSettings(
            theme = preferences[PreferencesKeys.THEME] ?: "Dark",
            accentColor = preferences[PreferencesKeys.ACCENT_COLOR] ?: "Blue",
            displayLanguage = preferences[PreferencesKeys.DISPLAY_LANGUAGE] ?: "English",
            defaultAudioLanguage = preferences[PreferencesKeys.DEFAULT_AUDIO_LANG] ?: "Default",
            audioBoostPercent = preferences[PreferencesKeys.AUDIO_BOOST_PERCENT] ?: 100,
            audioDelayMs = preferences[PreferencesKeys.AUDIO_DELAY_MS] ?: 0,
            backgroundPlayback = preferences[PreferencesKeys.BACKGROUND_PLAYBACK] ?: true,
            pauseOnHeadphoneDisconnect = preferences[PreferencesKeys.PAUSE_HEADPHONE_DISCONNECT] ?: true,
            skipDurationSeconds = preferences[PreferencesKeys.SKIP_DURATION_SECONDS] ?: 10,
            orientation = preferences[PreferencesKeys.ORIENTATION] ?: "Auto",
            keepScreenOn = preferences[PreferencesKeys.KEEP_SCREEN_ON] ?: true,
            pipEnabled = preferences[PreferencesKeys.PIP_ENABLED] ?: true,
            showBatteryAndTime = preferences[PreferencesKeys.SHOW_BATTERY_AND_TIME] ?: true,
            showLogoWatermark = preferences[PreferencesKeys.SHOW_LOGO_WATERMARK] ?: true,
            defaultSubtitleLanguage = preferences[PreferencesKeys.DEFAULT_SUB_LANG] ?: "Auto",
            subTextSizeSp = preferences[PreferencesKeys.SUB_TEXT_SIZE_SP] ?: 18,
            subTextColorHex = preferences[PreferencesKeys.SUB_TEXT_COLOR_HEX] ?: "#FFFFFF",
            subBgColorHex = preferences[PreferencesKeys.SUB_BG_COLOR_HEX] ?: "#80000000",
            subBold = preferences[PreferencesKeys.SUB_BOLD] ?: false,
            subEdgeStyle = preferences[PreferencesKeys.SUB_EDGE_STYLE] ?: "Outline",
            subPosition = preferences[PreferencesKeys.SUB_POSITION] ?: "Bottom",
            subDelayMs = preferences[PreferencesKeys.SUB_DELAY_MS] ?: 0,
            subAutoLoadFromFolder = preferences[PreferencesKeys.SUB_AUTO_LOAD] ?: true,
            subEncoding = preferences[PreferencesKeys.SUB_ENCODING] ?: "UTF-8",
            appLockEnabled = preferences[PreferencesKeys.APP_LOCK_ENABLED] ?: false,
            appLockPin = preferences[PreferencesKeys.APP_LOCK_PIN] ?: "",
            biometricEnabled = preferences[PreferencesKeys.BIOMETRIC_ENABLED] ?: false
        )
    }

    suspend fun updateTheme(theme: String) {
        context.dataStore.edit { it[PreferencesKeys.THEME] = theme }
    }

    suspend fun updateAccentColor(color: String) {
        context.dataStore.edit { it[PreferencesKeys.ACCENT_COLOR] = color }
    }

    suspend fun updateDisplayLanguage(lang: String) {
        context.dataStore.edit { it[PreferencesKeys.DISPLAY_LANGUAGE] = lang }
    }

    suspend fun updateDefaultAudioLanguage(lang: String) {
        context.dataStore.edit { it[PreferencesKeys.DEFAULT_AUDIO_LANG] = lang }
    }

    suspend fun updateAudioBoostPercent(boost: Int) {
        context.dataStore.edit { it[PreferencesKeys.AUDIO_BOOST_PERCENT] = boost }
    }

    suspend fun updateAudioDelayMs(delay: Int) {
        context.dataStore.edit { it[PreferencesKeys.AUDIO_DELAY_MS] = delay }
    }

    suspend fun updateBackgroundPlayback(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.BACKGROUND_PLAYBACK] = enabled }
    }

    suspend fun updatePauseOnHeadphoneDisconnect(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.PAUSE_HEADPHONE_DISCONNECT] = enabled }
    }

    suspend fun updateSkipDurationSeconds(seconds: Int) {
        context.dataStore.edit { it[PreferencesKeys.SKIP_DURATION_SECONDS] = seconds }
    }

    suspend fun updateOrientation(orientation: String) {
        context.dataStore.edit { it[PreferencesKeys.ORIENTATION] = orientation }
    }

    suspend fun updateKeepScreenOn(keep: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.KEEP_SCREEN_ON] = keep }
    }

    suspend fun updatePipEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.PIP_ENABLED] = enabled }
    }

    suspend fun updateShowBatteryAndTime(show: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.SHOW_BATTERY_AND_TIME] = show }
    }

    suspend fun updateShowLogoWatermark(show: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.SHOW_LOGO_WATERMARK] = show }
    }

    suspend fun updateSubtitleSettings(
        lang: String,
        textSizeSp: Int,
        textColorHex: String,
        bgColorHex: String,
        bold: Boolean,
        edgeStyle: String,
        position: String,
        delayMs: Int,
        autoLoad: Boolean,
        encoding: String
    ) {
        context.dataStore.edit {
            it[PreferencesKeys.DEFAULT_SUB_LANG] = lang
            it[PreferencesKeys.SUB_TEXT_SIZE_SP] = textSizeSp
            it[PreferencesKeys.SUB_TEXT_COLOR_HEX] = textColorHex
            it[PreferencesKeys.SUB_BG_COLOR_HEX] = bgColorHex
            it[PreferencesKeys.SUB_BOLD] = bold
            it[PreferencesKeys.SUB_EDGE_STYLE] = edgeStyle
            it[PreferencesKeys.SUB_POSITION] = position
            it[PreferencesKeys.SUB_DELAY_MS] = delayMs
            it[PreferencesKeys.SUB_AUTO_LOAD] = autoLoad
            it[PreferencesKeys.SUB_ENCODING] = encoding
        }
    }

    suspend fun updateAppLock(enabled: Boolean, pin: String, biometric: Boolean) {
        context.dataStore.edit {
            it[PreferencesKeys.APP_LOCK_ENABLED] = enabled
            it[PreferencesKeys.APP_LOCK_PIN] = pin
            it[PreferencesKeys.BIOMETRIC_ENABLED] = biometric
        }
    }
}
