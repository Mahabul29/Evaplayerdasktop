package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Turns share links like https://host/open/evaplayer/4175 into the real video link
 * https://host/stream/4175, and reads the file name from the page title.
 */
object StreamLink {
    class Resolved(val url: String, val title: String)

    private val openPattern = Regex("^(https?://[^/]+)/open/[^/]+/([^/?#]+)")

    /** "192.168.1.5:8080/video.mp4" or "example.com/a.m3u8" -> adds http:// when no scheme is typed. */
    fun normalize(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return t
        val hasScheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://").containsMatchIn(t)
        return if (hasScheme) t else "http://$t"
    }

    fun isOpenLink(raw: String) = openPattern.containsMatchIn(raw.trim())

    suspend fun resolve(raw: String): Resolved = withContext(Dispatchers.IO) {
        val link = normalize(raw)
        val m = openPattern.find(link)
        if (m == null) {
            val title = link.substringAfterLast('/').substringBefore('?').ifEmpty { "Stream Video" }
            return@withContext Resolved(link, title)
        }
        val streamUrl = "${m.groupValues[1]}/stream/${m.groupValues[2]}"
        var title = "Stream ${m.groupValues[2]}"
        try {
            val conn = URL(link).openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            val html = conn.inputStream.bufferedReader().use { it.readText().take(20000) }
            conn.disconnect()
            Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(html)
                ?.groupValues?.get(1)?.trim()
                ?.replace("&#39;", "'")?.replace("&amp;", "&")
                ?.takeIf { it.isNotBlank() }
                ?.let { title = it }
        } catch (e: Exception) {
            // keep the fallback title
        }
        Resolved(streamUrl, title)
    }
}
