package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.db.PlaylistEntity
import com.example.data.model.VideoItem
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoActionBottomSheet(
    video: VideoItem?,
    onDismiss: () -> Unit,
    onInfoClick: (VideoItem) -> Unit,
    onFavoriteToggle: (VideoItem) -> Unit,
    onPlayInBackground: (VideoItem) -> Unit,
    onAddToPlaylist: (VideoItem) -> Unit,
    onRenameClick: (VideoItem) -> Unit,
    onShareClick: (VideoItem) -> Unit,
    onDeleteClick: (VideoItem) -> Unit,
    onHideClick: (VideoItem) -> Unit
) {
    if (video == null) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            // Header with Title and Info Icon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = video.title,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${video.durationFormatted} • ${video.sizeFormatted} • ${video.format}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(onClick = {
                    onDismiss()
                    onInfoClick(video)
                }) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Video Info",
                        tint = GreenAccent
                    )
                }
            }

            HorizontalDivider(color = DividerDark, modifier = Modifier.padding(vertical = 8.dp))

            // Action Items: Hide, Play in background, Add to playlist, Favorite, Rename, Share, Delete
            ActionSheetItem(
                icon = if (video.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                title = if (video.isFavorite) "Remove from Favorites" else "Add to Favorites",
                tint = if (video.isFavorite) GreenAccent else TextPrimary,
                onClick = {
                    onFavoriteToggle(video)
                    onDismiss()
                }
            )

            ActionSheetItem(
                icon = Icons.Default.Headphones,
                title = "Play in background",
                onClick = {
                    onPlayInBackground(video)
                    onDismiss()
                }
            )

            ActionSheetItem(
                icon = Icons.Default.PlaylistAdd,
                title = "Add to playlist",
                onClick = {
                    onAddToPlaylist(video)
                }
            )

            ActionSheetItem(
                icon = Icons.Default.VisibilityOff,
                title = "Hide video",
                onClick = {
                    onHideClick(video)
                }
            )

            ActionSheetItem(
                icon = Icons.Default.DriveFileRenameOutline,
                title = "Rename",
                onClick = {
                    onRenameClick(video)
                }
            )

            ActionSheetItem(
                icon = Icons.Default.Share,
                title = "Share",
                onClick = {
                    onShareClick(video)
                    onDismiss()
                }
            )

            ActionSheetItem(
                icon = Icons.Default.Delete,
                title = "Delete",
                tint = Color(0xFFFF5252),
                onClick = {
                    onDeleteClick(video)
                }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ActionSheetItem(
    icon: ImageVector,
    title: String,
    tint: Color = TextPrimary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = tint,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            color = tint,
            fontSize = 15.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoInfoBottomSheet(
    video: VideoItem?,
    onDismiss: () -> Unit
) {
    if (video == null) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Video Details",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            InfoRow(label = "Title", value = video.title)
            InfoRow(label = "Location", value = video.path.ifEmpty { video.uriString })
            InfoRow(label = "Size", value = video.sizeFormatted)
            InfoRow(label = "Resolution", value = video.resolution)
            InfoRow(label = "Duration", value = video.durationFormatted)
            InfoRow(label = "Format", value = video.format)
            InfoRow(label = "Codec", value = "H.264 / AAC (AVC1)")
            InfoRow(label = "Bitrate", value = "2.5 Mbps (approx)")

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(
            text = label,
            color = GreenAccent,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 14.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DeleteConfirmDialog(
    video: VideoItem?,
    onConfirm: (VideoItem) -> Unit,
    onDismiss: () -> Unit
) {
    if (video == null) return

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text("Delete Video?", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Text(
                "Are you sure you want to permanently delete \"${video.title}\" (${video.sizeFormatted})? This cannot be undone.",
                color = TextSecondary,
                fontSize = 14.sp
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(video) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
            ) {
                Text("Delete", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}

@Composable
fun RenameDialog(
    video: VideoItem?,
    onConfirm: (video: VideoItem, newName: String) -> Unit,
    onDismiss: () -> Unit
) {
    if (video == null) return
    var newName by remember { mutableStateOf(video.title) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text("Rename Video", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("Name") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = GreenAccent,
                    unfocusedBorderColor = DividerDark,
                    focusedLabelColor = GreenAccent,
                    unfocusedLabelColor = TextSecondary
                ),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { if (newName.isNotBlank()) onConfirm(video, newName.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
            ) {
                Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}

@Composable
fun AddToPlaylistDialog(
    video: VideoItem?,
    playlists: List<PlaylistEntity>,
    onSelectPlaylist: (playlistId: Long, video: VideoItem) -> Unit,
    onCreateNewPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    if (video == null) return

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text("Add to Playlist", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (playlists.isEmpty()) {
                    Text(
                        "No playlists found. Create one now!",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(playlists) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectPlaylist(pl.id, video) }
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlaylistAdd,
                                    contentDescription = null,
                                    tint = GreenAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = pl.name,
                                    color = TextPrimary,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onCreateNewPlaylist,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = GreenAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Create New Playlist", color = GreenAccent)
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TextPrimary)
            }
        }
    )
}

@Composable
fun CreatePlaylistDialog(
    onConfirm: (name: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text("New Playlist", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Playlist Name") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = GreenAccent,
                    unfocusedBorderColor = DividerDark,
                    focusedLabelColor = GreenAccent,
                    unfocusedLabelColor = TextSecondary
                ),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
            ) {
                Text("Create", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}

fun shareVideoFile(context: Context, video: VideoItem) {
    try {
        val source = video.uriString.ifBlank { video.path }
        val uri = Uri.parse(source)
        val intent = if (source.startsWith("http://", true) || source.startsWith("https://", true)) {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, source)
            }
        } else {
            val shareUri = if (uri.scheme == "content") {
                uri
            } else {
                val file = File(video.path)
                if (!file.exists() || !file.isFile) {
                    android.widget.Toast.makeText(context, "File is not available to share", android.widget.Toast.LENGTH_SHORT).show()
                    return
                }
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }
            Intent(Intent.ACTION_SEND).apply {
                type = when {
                    video.format.equals("MP3", true) || video.format.equals("M4A", true) -> "audio/*"
                    else -> "video/*"
                }
                putExtra(Intent.EXTRA_STREAM, shareUri)
                clipData = android.content.ClipData.newUri(context.contentResolver, video.title, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share ${video.title}"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Unable to share this file: ${e.localizedMessage ?: "unknown error"}", android.widget.Toast.LENGTH_LONG).show()
    }
}
