package com.example.data.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checks the newest GitHub Release, downloads its APK and opens Android's installer.
 *
 * The release tag is "v<build number>" (set by the build workflow) and the app's versionCode
 * is the same build number, so "newer" simply means a bigger number.
 */
object AppUpdater {
    // Change these two if your releases live in a different repository.
    private const val OWNER = "Mahabul29"
    private const val REPO = "EvaPlayer"

    class UpdateInfo(
        val versionName: String,
        val versionCode: Long,
        val apkUrl: String,
        val notes: String
    )

    enum class InstallResult { STARTED, NEEDS_PERMISSION, FAILED }

    /** Returns the newer release, or null when up to date / offline / anything goes wrong. */
    suspend fun check(context: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val conn = URL("https://api.github.com/repos/$OWNER/$REPO/releases/latest")
                .openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            if (conn.responseCode != 200) {
                conn.disconnect()
                return@withContext null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val json = JSONObject(body)
            val tag = json.optString("tag_name")
            val latest = tag.filter { it.isDigit() }.toLongOrNull() ?: return@withContext null

            val pkg = context.packageManager.getPackageInfo(context.packageName, 0)
            val current = PackageInfoCompat.getLongVersionCode(pkg)
            if (latest <= current) return@withContext null

            val assets = json.optJSONArray("assets") ?: return@withContext null
            var apkUrl: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    apkUrl = a.optString("browser_download_url")
                    break
                }
            }
            if (apkUrl.isNullOrBlank()) return@withContext null

            UpdateInfo(
                versionName = json.optString("name").ifBlank { tag },
                versionCode = latest,
                apkUrl = apkUrl,
                notes = json.optString("body").trim()
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Downloads the APK into the app's cache. [onProgress] gets 0f..1f (or -1f if size unknown). */
    suspend fun download(context: Context, info: UpdateInfo, onProgress: (Float) -> Unit): File? =
        withContext(Dispatchers.IO) {
            try {
                val dir = File(context.cacheDir, "updates").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val file = File(dir, "EvaPlayer-update.apk")

                val conn = URL(info.apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                if (conn.responseCode != 200) {
                    conn.disconnect()
                    return@withContext null
                }
                val total = conn.contentLengthLong
                var done = 0L
                conn.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var lastPct = -1
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    onProgress(done.toFloat() / total)
                                }
                            } else onProgress(-1f)
                        }
                    }
                }
                conn.disconnect()
                if (file.length() > 0) file else null
            } catch (e: Exception) {
                null
            }
        }

    /**
     * Opens Android's installer for the downloaded APK. Android never allows a silent install:
     * the user must tap "Install", and on first use allow "Install unknown apps" for EvaPlayer.
     */
    fun install(context: Context, apk: File): InstallResult {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()
            ) {
                context.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${context.packageName}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return InstallResult.NEEDS_PERMISSION
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
            context.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            InstallResult.STARTED
        } catch (e: Exception) {
            InstallResult.FAILED
        }
    }
}
