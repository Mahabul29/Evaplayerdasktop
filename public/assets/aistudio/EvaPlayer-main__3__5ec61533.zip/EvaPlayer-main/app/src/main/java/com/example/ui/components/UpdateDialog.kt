package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.update.AppUpdater
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/** Checks for a newer release when the app opens and offers to download and install it. */
@Composable
fun UpdatePrompt() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf<AppUpdater.UpdateInfo?>(null) }
    var dismissed by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Float?>(null) } // null = not downloading
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { info = AppUpdater.check(context) }

    val update = info
    if (update == null || dismissed) return

    AlertDialog(
        onDismissRequest = { if (progress == null) dismissed = true },
        containerColor = DarkSurface,
        title = { Text("Update available", color = TextPrimary) },
        text = {
            Column {
                Text("${update.versionName} is ready to install.", color = TextPrimary)
                if (update.notes.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(update.notes.take(400), color = TextSecondary)
                }
                val p = progress
                if (p != null) {
                    Spacer(Modifier.height(12.dp))
                    if (p in 0f..1f) {
                        LinearProgressIndicator(progress = { p }, color = GreenAccent, modifier = Modifier.fillMaxWidth())
                    } else {
                        LinearProgressIndicator(color = GreenAccent, modifier = Modifier.fillMaxWidth())
                    }
                }
                message?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = TextSecondary)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = progress == null,
                onClick = {
                    message = null
                    progress = 0f
                    scope.launch {
                        val apk = AppUpdater.download(context, update) { progress = it }
                        if (apk == null) {
                            progress = null
                            message = "Download failed. Check your internet and try again."
                        } else {
                            when (AppUpdater.install(context, apk)) {
                                AppUpdater.InstallResult.STARTED -> dismissed = true
                                AppUpdater.InstallResult.NEEDS_PERMISSION -> {
                                    progress = null
                                    message = "Allow \"Install unknown apps\" for EvaPlayer, come back and tap Update again."
                                }
                                AppUpdater.InstallResult.FAILED -> {
                                    progress = null
                                    message = "Could not open the installer."
                                }
                            }
                        }
                    }
                }
            ) { Text(if (progress == null) "Update" else "Downloading…", color = GreenAccent) }
        },
        dismissButton = {
            TextButton(enabled = progress == null, onClick = { dismissed = true }) {
                Text("Later", color = TextSecondary)
            }
        }
    )
}
