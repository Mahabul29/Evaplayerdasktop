package com.example.ui.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class LoopMode(val label: String) {
    OFF("Off"),
    ONE("Loop One"),
    ALL("Loop All")
}

data class GridActionItem(
    val title: String,
    val icon: ImageVector,
    val isActive: Boolean = false,
    val onClick: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoControlSheet(
    isBackgroundPlayActive: Boolean,
    onToggleBackgroundPlay: () -> Unit,
    onOpenEqualizer: () -> Unit,
    isNightModeActive: Boolean,
    onOpenNightMode: () -> Unit,
    onOpenTimer: () -> Unit,
    abRepeatStateText: String, // "AB Repeat", "A Set", "A-B Active"
    isAbRepeatActive: Boolean,
    onAbRepeatClick: () -> Unit,
    isMirrorActive: Boolean,
    onToggleMirror: () -> Unit,
    isHardwareDecoder: Boolean,
    onToggleDecoder: () -> Unit,
    loopMode: LoopMode,
    onCycleLoop: () -> Unit,
    isShuffleActive: Boolean,
    onToggleShuffle: () -> Unit,
    onOpenProperties: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onScreenshot: () -> Unit,
    onRemoveFromHistory: () -> Unit,
    rotationModeText: String,
    onCycleRotation: () -> Unit,
    isHlsStream: Boolean,
    selectedQuality: String,
    onOpenQuality: () -> Unit,
    onOpenFeedback: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val gridItems = mutableListOf<GridActionItem>()

    // Row 1: Background Play | Equalizer | Night Mode | Timer
    gridItems.add(
        GridActionItem(
            title = "Background",
            icon = Icons.Default.Headphones,
            isActive = isBackgroundPlayActive,
            onClick = onToggleBackgroundPlay
        )
    )
    gridItems.add(
        GridActionItem(
            title = "Equalizer",
            icon = Icons.Default.Equalizer,
            isActive = false,
            onClick = onOpenEqualizer
        )
    )
    gridItems.add(
        GridActionItem(
            title = "Night Mode",
            icon = Icons.Default.Bedtime,
            isActive = isNightModeActive,
            onClick = onOpenNightMode
        )
    )
    gridItems.add(
        GridActionItem(
            title = "Timer",
            icon = Icons.Default.Timer,
            isActive = false,
            onClick = onOpenTimer
        )
    )

    // Row 2: AB Repeat | Mirror | Decoder (HW/SW) | Loop
    gridItems.add(
        GridActionItem(
            title = abRepeatStateText,
            icon = Icons.Default.Repeat,
            isActive = isAbRepeatActive,
            onClick = onAbRepeatClick
        )
    )
    gridItems.add(
        GridActionItem(
            title = "Mirror",
            icon = Icons.Default.Flip,
            isActive = isMirrorActive,
            onClick = onToggleMirror
        )
    )
    gridItems.add(
        GridActionItem(
            title = if (isHardwareDecoder) "Decoder (HW)" else "Decoder (SW)",
            icon = Icons.Default.Memory,
            isActive = isHardwareDecoder,
            onClick = onToggleDecoder
        )
    )
    gridItems.add(
        GridActionItem(
            title = loopMode.label,
            icon = if (loopMode == LoopMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
            isActive = loopMode != LoopMode.OFF,
            onClick = onCycleLoop
        )
    )

    // Row 3: Shuffle | Properties | Share | Delete
    gridItems.add(
        GridActionItem(
            title = "Shuffle",
            icon = Icons.Default.Shuffle,
            isActive = isShuffleActive,
            onClick = onToggleShuffle
        )
    )
    gridItems.add(
        GridActionItem(
            title = "Properties",
            icon = Icons.Default.Info,
            isActive = false,
            onClick = onOpenProperties
        )
    )
    // Share and Delete were removed from the player on purpose.

    // Row 4: Take Screenshot | Remove from History | Rotation | Quality
    gridItems.add(
        GridActionItem(
            title = "Screenshot",
            icon = Icons.Default.CameraAlt,
            isActive = false,
            onClick = onScreenshot
        )
    )
    gridItems.add(
        GridActionItem(
            title = "Remove History",
            icon = Icons.Default.History,
            isActive = false,
            onClick = onRemoveFromHistory
        )
    )
    gridItems.add(
        GridActionItem(
            title = rotationModeText,
            icon = Icons.Default.ScreenRotation,
            isActive = false,
            onClick = onCycleRotation
        )
    )
    if (isHlsStream) {
        gridItems.add(
            GridActionItem(
                title = "Quality ($selectedQuality)",
                icon = Icons.Default.Speed,
                isActive = false,
                onClick = onOpenQuality
            )
        )
    } else {
        // Fallback slot if not HLS
        gridItems.add(
            GridActionItem(
                title = "Quality (Auto)",
                icon = Icons.Default.Speed,
                isActive = false,
                onClick = onOpenQuality
            )
        )
    }

    // Row 5: Feedback
    gridItems.add(
        GridActionItem(
            title = "Feedback",
            icon = Icons.Default.Email,
            isActive = false,
            onClick = onOpenFeedback
        )
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF1A1A1A),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = "Video Controls",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 6.dp, end = 6.dp, bottom = 6.dp)
            )

            HorizontalDivider(color = DividerDark, modifier = Modifier.padding(bottom = 8.dp))

            // 4-Column Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(gridItems.size) { index ->
                    val item = gridItems[index]
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onDismiss()
                                item.onClick()
                            }
                            .padding(vertical = 4.dp, horizontal = 4.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (item.isActive) GreenAccent.copy(alpha = 0.2f) else Color(0xFF262626))
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = if (item.isActive) GreenAccent else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = item.title,
                            color = if (item.isActive) GreenAccent else TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = if (item.isActive) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

// === Sub-dialogs for Video Control Sheet ===

@Composable
fun EqualizerSheet(
    onDismiss: () -> Unit
) {
    var bassBoostVal by remember { mutableFloatStateOf(50f) }
    var audioBoostVal by remember { mutableFloatStateOf(100f) }
    var selectedPreset by remember { mutableStateOf("Normal") }
    val presets = listOf("Normal", "Bass", "Treble", "Vocal", "Rock", "Pop")

    var band60 by remember { mutableFloatStateOf(0f) }
    var band230 by remember { mutableFloatStateOf(0f) }
    var band910 by remember { mutableFloatStateOf(0f) }
    var band3600 by remember { mutableFloatStateOf(0f) }
    var band14k by remember { mutableFloatStateOf(0f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        title = { Text("Audio Equalizer & Boost", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Presets row
                Text("PRESETS", color = GreenAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(presets) { p ->
                        val isSel = p == selectedPreset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSel) GreenAccent else Color(0xFF2A2A2A))
                                .clickable {
                                    selectedPreset = p
                                    when (p) {
                                        "Bass" -> { band60 = 5f; band230 = 3f; band910 = 0f; band3600 = 0f; band14k = -1f; bassBoostVal = 80f }
                                        "Treble" -> { band60 = -2f; band230 = 0f; band910 = 1f; band3600 = 4f; band14k = 6f }
                                        "Vocal" -> { band60 = -1f; band230 = 2f; band910 = 5f; band3600 = 3f; band14k = 0f }
                                        "Rock" -> { band60 = 4f; band230 = 2f; band910 = -1f; band3600 = 3f; band14k = 5f }
                                        "Pop" -> { band60 = 2f; band230 = 3f; band910 = 4f; band3600 = 2f; band14k = 1f }
                                        else -> { band60 = 0f; band230 = 0f; band910 = 0f; band3600 = 0f; band14k = 0f; bassBoostVal = 50f }
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(text = p, color = if (isSel) Color.Black else Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 5-band Equalizer
                Text("5-BAND EQUALIZER", color = GreenAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BandControl("60Hz", band60) { band60 = it }
                    BandControl("230Hz", band230) { band230 = it }
                    BandControl("910Hz", band910) { band910 = it }
                    BandControl("3.6kHz", band3600) { band3600 = it }
                    BandControl("14kHz", band14k) { band14k = it }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bass Boost
                Text("BASS BOOST (${bassBoostVal.toInt()}%)", color = GreenAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Slider(
                    value = bassBoostVal,
                    onValueChange = { bassBoostVal = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
                )

                // Audio Boost up to 200%
                Text("AUDIO BOOST (${audioBoostVal.toInt()}%)", color = GreenAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Slider(
                    value = audioBoostVal,
                    onValueChange = { audioBoostVal = it },
                    valueRange = 100f..200f,
                    colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
            ) {
                Text("Apply", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TextPrimary)
            }
        }
    )
}

@Composable
private fun BandControl(freq: String, gain: Float, onGainChange: (Float) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(52.dp)) {
        Text(text = "${gain.toInt()}dB", color = Color.White, fontSize = 10.sp)
        Slider(
            value = gain,
            onValueChange = onGainChange,
            valueRange = -10f..10f,
            colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent),
            modifier = Modifier.height(100.dp)
        )
        Text(text = freq, color = TextSecondary, fontSize = 10.sp)
    }
}

@Composable
fun NightModeDialog(
    isActive: Boolean,
    brightnessDim: Float,
    onDimChange: (Float) -> Unit,
    onToggle: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        title = { Text("Night Mode", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Night Mode", color = TextPrimary, fontSize = 15.sp)
                    Switch(
                        checked = isActive,
                        onCheckedChange = onToggle,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = GreenAccent)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Night Screen Dimming", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Slider(
                    value = brightnessDim,
                    onValueChange = onDimChange,
                    valueRange = 0.1f..0.8f,
                    colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
                )
                Text(
                    "Dims display overlay and softens sound dynamics for comfortable late-night viewing.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done", color = GreenAccent, fontWeight = FontWeight.Bold) }
        }
    )
}

@Composable
fun QualitySelectionDialog(
    currentQuality: String,
    onQualitySelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val qualities = listOf("Auto", "1080p", "720p", "480p", "360p")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        title = { Text("Stream Video Quality", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                qualities.forEach { q ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onQualitySelected(q)
                                onDismiss()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = q == currentQuality,
                            onClick = {
                                onQualitySelected(q)
                                onDismiss()
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = GreenAccent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = q, color = TextPrimary, fontSize = 15.sp)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextPrimary) }
        }
    )
}

@Composable
fun FeedbackDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var feedbackText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        title = { Text("Send Feedback", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Tell us your suggestions or report issues with EvaPlayer:", color = TextSecondary, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = feedbackText,
                    onValueChange = { feedbackText = it },
                    placeholder = { Text("Describe your feedback...", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = GreenAccent,
                        unfocusedBorderColor = DividerDark
                    ),
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:")
                        putExtra(Intent.EXTRA_EMAIL, arrayOf("feedback@evaplayer.app"))
                        putExtra(Intent.EXTRA_SUBJECT, "EvaPlayer User Feedback")
                        putExtra(Intent.EXTRA_TEXT, feedbackText)
                    }
                    try {
                        context.startActivity(Intent.createChooser(intent, "Send Feedback"))
                    } catch (e: Exception) {
                        // ignore
                    }
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
            ) {
                Text("Send", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextPrimary) }
        }
    )
}
