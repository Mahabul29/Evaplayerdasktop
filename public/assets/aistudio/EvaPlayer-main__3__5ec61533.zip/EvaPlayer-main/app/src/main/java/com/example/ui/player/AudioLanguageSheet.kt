package com.example.ui.player

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/** Audio language picker, shown as a clean centred popup (same call signature as before). */
@Composable
fun AudioLanguageSheet(
    audioTracks: List<String>,
    selectedTrackIndex: Int,
    onSelectTrack: (Int) -> Unit,
    audioDelayMs: Int,
    onAudioDelayChange: (Int) -> Unit,
    onLoadExternalAudio: () -> Unit,
    onDismiss: () -> Unit
) {
    var delay by remember(audioDelayMs) { mutableFloatStateOf(audioDelayMs.toFloat()) }
    PlayerCenterDialog(title = "Audio language", onDismiss = onDismiss) {
        if (audioTracks.isEmpty()) {
            Text("No audio tracks found", color = TextSecondary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp))
        }
        audioTracks.forEachIndexed { index, track ->
            PlayerChoiceRow(
                label = track,
                selected = index == selectedTrackIndex,
                onClick = { onSelectTrack(index) }
            )
        }
        HorizontalDivider(color = DividerDark, modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
            Text("Audio delay: ${delay.toInt()} ms", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Slider(
                value = delay.coerceIn(-500f, 500f),
                onValueChange = { delay = it },
                valueRange = -500f..500f,
                onValueChangeFinished = { onAudioDelayChange(delay.toInt()) },
                colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
            )
            Row {
                TextButton(onClick = onLoadExternalAudio) { Text("Load external audio", color = GreenAccent) }
            }
            Spacer(Modifier.height(2.dp))
        }
    }
}
