package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StreamItem
import com.example.data.model.VideoItem
import com.example.ui.components.EvaTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute
import kotlinx.coroutines.launch

private fun startUrlDownload(
    context: Context,
    viewModel: MainViewModel,
    rawUrl: String,
    rawTitle: String
) {
    val err = com.example.data.UrlDownloads.start(context, rawUrl, rawTitle)
    viewModel.showToast(err ?: "Download started")
}

private fun formatMb(bytes: Long): String = String.format("%.1f MB", bytes / (1024.0 * 1024.0))

@Composable
private fun DownloadsSection() {
    val context = LocalContext.current
    val downloads by com.example.data.UrlDownloads.items.collectAsState()
    if (downloads.isEmpty()) return
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(
                "Downloads (${downloads.size})",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            if (downloads.any { !it.isActive }) {
                TextButton(onClick = { com.example.data.UrlDownloads.clearFinished() }) {
                    Text("Clear finished", color = GreenAccent, fontSize = 12.sp)
                }
            }
        }
        downloads.take(3).forEach { d ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            d.name,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { com.example.data.UrlDownloads.cancel(context, d.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Cancel", tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    if (d.isFailed) {
                        Text("Failed", color = Color(0xFFFF5252), fontSize = 12.sp)
                    } else {
                        androidx.compose.material3.LinearProgressIndicator(
                            progress = { d.progress },
                            color = GreenAccent,
                            trackColor = DividerDark,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            when {
                                d.isDone -> "Completed • Movies/EvaPlayer/Downloads"
                                d.totalBytes > 0 -> "${(d.progress * 100).toInt()}%  •  ${formatMb(d.downloadedBytes)} / ${formatMb(d.totalBytes)}"
                                d.status == android.app.DownloadManager.STATUS_PAUSED -> "Paused, waiting for network"
                                else -> "Starting..."
                            },
                            color = if (d.isDone) GreenAccent else TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun UrlStreamScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var urlInput by remember { mutableStateOf("") }
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: History, 1: Saved Links, 2: Batch Add

    val streamHistory by viewModel.streamHistory.collectAsState()
    var showSaveLinkDialog by remember { mutableStateOf<StreamItem?>(null) }
    var batchInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        EvaTopBar(
            title = "URL Stream",
            canNavigateBack = true,
            onNavigateBack = { viewModel.navigateBack() },
            showSearchAndSort = false
        )

        // URL input card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Play from URL",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Supports HTTP, HTTPS, HLS (.m3u8), MP4, MKV, WebM",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )

                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    placeholder = { Text("https://example.com/video.mp4  or  192.168.1.5:8080/video", color = TextSecondary, fontSize = 13.sp) },
                    trailingIcon = {
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            val clip = clipboard?.primaryClip?.getItemAt(0)?.text?.toString()
                            if (!clip.isNullOrBlank()) {
                                urlInput = clip
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Paste",
                                tint = GreenAccent
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = GreenAccent,
                        unfocusedBorderColor = DividerDark
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = {
                            if (urlInput.isNotBlank()) {
                                val raw = urlInput.trim()
                                coroutineScope.launch {
                                    val r = com.example.data.StreamLink.resolve(raw)
                                    startUrlDownload(context, viewModel, r.url, r.title)
                                }
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = GreenAccent)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download", color = GreenAccent, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            if (urlInput.isNotBlank()) {
                                val raw = urlInput.trim()
                                coroutineScope.launch {
                                    // Supports normal video links and "…/open/evaplayer/<id>" share links
                                    val r = com.example.data.StreamLink.resolve(raw)
                                    val url = r.url
                                    val title = r.title
                                    val ext = title.substringAfterLast('.', "").uppercase()
                                    val video = VideoItem(
                                        id = url,
                                        title = title,
                                        path = url,
                                        uriString = url,
                                        durationMs = 0L,
                                        sizeBytes = 0L,
                                        dateModified = System.currentTimeMillis() / 1000,
                                        folderName = "Network Stream",
                                        folderPath = "stream",
                                        format = if (url.contains(".m3u8")) "HLS" else if (ext.length in 2..4) ext else "MP4",
                                        isStream = true
                                    )
                                    viewModel.playbackRepo.saveStreamRecord(url = url, title = title)
                                    viewModel.navigateTo(ScreenRoute.Player(video = video))
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Play", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        DownloadsSection()

        // Tabs: Stream History | Saved Links | Batch Add
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = DarkSurface,
            contentColor = GreenAccent,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = GreenAccent,
                    height = 2.dp
                )
            }
        ) {
            listOf("History", "Saved Links", "Batch Add").forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == index) GreenAccent else TextSecondary
                        )
                    }
                )
            }
        }

        // Tab Content
        // Tab content takes the remaining space so the ad stays pinned below it
        Box(modifier = Modifier.weight(1f)) {
        when (selectedTabIndex) {
            0 -> {
                // Stream History
                if (streamHistory.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 80.dp)
                    ) {
                        Text("No stream history yet", color = TextSecondary, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        items(streamHistory, key = { it.url }) { item ->
                            StreamItemCard(
                                item = item,
                                onClick = {
                                    val video = VideoItem(
                                        id = item.url,
                                        title = item.title,
                                        path = item.url,
                                        uriString = item.url,
                                        durationMs = 0L,
                                        sizeBytes = 0L,
                                        dateModified = item.timestamp / 1000,
                                        folderName = "Network Stream",
                                        folderPath = "stream",
                                        format = if (item.url.contains(".m3u8")) "HLS" else "MP4",
                                        lastPositionMs = item.lastPositionMs,
                                        isStream = true
                                    )
                                    viewModel.navigateTo(ScreenRoute.Player(video = video))
                                },
                                onDownload = { startUrlDownload(context, viewModel, item.url, item.title) },
                                onSaveToggle = {
                                    coroutineScope.launch {
                                        viewModel.playbackRepo.saveStreamRecord(
                                            url = item.url,
                                            title = item.title,
                                            positionMs = item.lastPositionMs,
                                            isSaved = !item.isSaved
                                        )
                                    }
                                },
                                onDelete = {
                                    coroutineScope.launch {
                                        viewModel.playbackRepo.deleteStreamRecord(item.url)
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
            1 -> {
                // Saved Links
                val saved = streamHistory.filter { it.isSaved }
                if (saved.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 80.dp)
                    ) {
                        Text("No saved stream links", color = TextSecondary, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        items(saved, key = { it.url }) { item ->
                            StreamItemCard(
                                item = item,
                                onClick = {
                                    val video = VideoItem(
                                        id = item.url,
                                        title = item.title,
                                        path = item.url,
                                        uriString = item.url,
                                        durationMs = 0L,
                                        sizeBytes = 0L,
                                        dateModified = item.timestamp / 1000,
                                        folderName = "Network Stream",
                                        folderPath = "stream",
                                        format = if (item.url.contains(".m3u8")) "HLS" else "MP4",
                                        isStream = true
                                    )
                                    viewModel.navigateTo(ScreenRoute.Player(video = video))
                                },
                                onDownload = { startUrlDownload(context, viewModel, item.url, item.title) },
                                onSaveToggle = {
                                    coroutineScope.launch {
                                        viewModel.playbackRepo.saveStreamRecord(
                                            url = item.url,
                                            title = item.title,
                                            positionMs = item.lastPositionMs,
                                            isSaved = false
                                        )
                                    }
                                },
                                onDelete = {
                                    coroutineScope.launch {
                                        viewModel.playbackRepo.deleteStreamRecord(item.url)
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
            2 -> {
                // Batch Add
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Batch Add Links (one per line)",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = batchInput,
                        onValueChange = { batchInput = it },
                        placeholder = { Text("https://example.com/ch1.m3u8\nhttps://example.com/ch2.mp4", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = GreenAccent,
                            unfocusedBorderColor = DividerDark
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val lines = batchInput.lines().map { it.trim() }.filter { it.isNotBlank() }
                            if (lines.isNotEmpty()) {
                                coroutineScope.launch {
                                    lines.forEach { line ->
                                        val title = line.substringAfterLast('/').substringBefore('?').ifEmpty { "Stream" }
                                        viewModel.playbackRepo.saveStreamRecord(url = line, title = title, isSaved = true)
                                    }
                                    viewModel.showToast("Added ${lines.size} links")
                                    batchInput = ""
                                    selectedTabIndex = 1
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add to Saved Playlist", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        } // end tab content

        // Ad at the bottom of the URL Stream screen
        com.example.ads.AdsterraBanner(
            format = com.example.ads.AdsterraFormat.BANNER_320x50,
            slotKey = "fixed_urlstream",
            modifier = Modifier.padding(vertical = 4.dp)
        )
    }
}

@Composable
private fun StreamItemCard(
    item: StreamItem,
    onClick: () -> Unit,
    onDownload: () -> Unit,
    onSaveToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Link,
                contentDescription = null,
                tint = GreenAccent,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.url,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onDownload) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Download",
                    tint = GreenAccent
                )
            }

            IconButton(onClick = onSaveToggle) {
                Icon(
                    imageVector = if (item.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Save",
                    tint = if (item.isSaved) GreenAccent else TextSecondary
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextSecondary
                )
            }
        }
    }
}
