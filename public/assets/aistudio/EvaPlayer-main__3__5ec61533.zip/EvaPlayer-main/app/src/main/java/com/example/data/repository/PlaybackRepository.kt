package com.example.data.repository

import com.example.data.db.EvaDao
import com.example.data.db.FavoriteEntity
import com.example.data.db.HiddenItemEntity
import com.example.data.db.PlaybackRecord
import com.example.data.db.PlaylistEntity
import com.example.data.db.PlaylistItemEntity
import com.example.data.db.StreamLinkEntity
import com.example.data.model.PlaylistInfo
import com.example.data.model.StreamItem
import com.example.data.model.VideoItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class PlaybackRepository(private val evaDao: EvaDao) {

    // --- History ---
    val historyFlow: Flow<List<PlaybackRecord>> = evaDao.getAllHistory()

    suspend fun savePlaybackPosition(
        video: VideoItem,
        positionMs: Long
    ) {
        val record = PlaybackRecord(
            uriString = video.uriString,
            path = video.path,
            title = video.title,
            durationMs = video.durationMs,
            lastPositionMs = positionMs,
            timestamp = System.currentTimeMillis(),
            folderPath = video.folderPath,
            isStream = video.isStream
        )
        evaDao.insertOrUpdateHistory(record)
    }

    suspend fun removeFromHistory(uriString: String) {
        evaDao.deleteHistoryByUri(uriString)
    }

    suspend fun clearHistory() {
        evaDao.clearHistory()
    }

    // --- Favorites ---
    val favoritesFlow: Flow<List<FavoriteEntity>> = evaDao.getAllFavorites()

    fun isFavorite(uriString: String): Flow<Boolean> = evaDao.isFavorite(uriString)

    suspend fun toggleFavorite(video: VideoItem, isFav: Boolean) {
        if (isFav) {
            val entity = FavoriteEntity(
                uriString = video.uriString,
                title = video.title,
                path = video.path,
                durationMs = video.durationMs,
                sizeBytes = video.sizeBytes,
                addedTimestamp = System.currentTimeMillis()
            )
            evaDao.insertFavorite(entity)
        } else {
            evaDao.deleteFavoriteByUri(video.uriString)
        }
    }

    // --- Playlists ---
    val playlistsFlow: Flow<List<PlaylistEntity>> = evaDao.getAllPlaylists()

    suspend fun createPlaylist(name: String): Long {
        return evaDao.insertPlaylist(PlaylistEntity(name = name))
    }

    suspend fun renamePlaylist(id: Long, newName: String) {
        evaDao.renamePlaylist(id, newName)
    }

    suspend fun deletePlaylist(id: Long) {
        evaDao.deletePlaylistItems(id)
        evaDao.deletePlaylist(id)
    }

    fun getPlaylistItems(playlistId: Long): Flow<List<PlaylistItemEntity>> {
        return evaDao.getPlaylistItems(playlistId)
    }

    suspend fun addVideoToPlaylist(playlistId: Long, video: VideoItem) {
        val item = PlaylistItemEntity(
            playlistId = playlistId,
            uriString = video.uriString,
            title = video.title,
            durationMs = video.durationMs,
            sizeBytes = video.sizeBytes
        )
        evaDao.insertPlaylistItem(item)
    }

    suspend fun removePlaylistItem(itemId: Long) {
        evaDao.deletePlaylistItem(itemId)
    }

    // --- Hidden Items ---
    val hiddenItemsFlow: Flow<List<HiddenItemEntity>> = evaDao.getAllHiddenItems()

    suspend fun hideItem(path: String, isFolder: Boolean) {
        evaDao.insertHiddenItem(HiddenItemEntity(path = path, isFolder = isFolder))
    }

    suspend fun unhideItem(path: String) {
        evaDao.deleteHiddenItem(path)
    }

    suspend fun unhideAll() {
        evaDao.clearAllHiddenItems()
    }

    // --- Stream Links ---
    val streamHistoryFlow: Flow<List<StreamItem>> = evaDao.getAllStreamLinks().map { list ->
        list.map { StreamItem(it.url, it.title, it.lastPositionMs, it.timestamp, it.isSaved) }
    }

    val savedStreamsFlow: Flow<List<StreamItem>> = evaDao.getSavedStreamLinks().map { list ->
        list.map { StreamItem(it.url, it.title, it.lastPositionMs, it.timestamp, it.isSaved) }
    }

    suspend fun saveStreamRecord(
        url: String,
        title: String,
        positionMs: Long = 0L,
        isSaved: Boolean = false
    ) {
        evaDao.insertOrUpdateStreamLink(
            StreamLinkEntity(
                url = url,
                title = title,
                lastPositionMs = positionMs,
                timestamp = System.currentTimeMillis(),
                isSaved = isSaved
            )
        )
    }

    suspend fun deleteStreamRecord(url: String) {
        evaDao.deleteStreamLink(url)
    }
}
