package com.example.ui.screens

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoItem
import com.example.ui.components.EvaTopBar
import com.example.ui.components.VideoListCard
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private data class StorageInfo(val name: String, val usedBytes: Long, val totalBytes: Long)

private fun readStorage(path: String, name: String): StorageInfo? {
    return try {
        val stat = StatFs(path)
        val total = stat.blockSizeLong * stat.blockCountLong
        val free = stat.blockSizeLong * stat.availableBlocksLong
        if (total <= 0L) null else StorageInfo(name, total - free, total)
    } catch (e: Exception) {
        null
    }
}

private fun loadStorages(context: Context): List<StorageInfo> {
    val list = mutableListOf<StorageInfo>()
    readStorage(Environment.getExternalStorageDirectory().absolutePath, "Phone memory")?.let { list.add(it) }
    // Removable SD card: the second app-specific external dir, trimmed back to the volume root
    try {
        val dirs: Array<File?> = context.getExternalFilesDirs(null)
        if (dirs.size > 1) {
            val sd = dirs[1]
            if (sd != null) {
                val root = sd.absolutePath.substringBefore("/Android/data")
                if (root.isNotBlank() && root != Environment.getExternalStorageDirectory().absolutePath) {
                    readStorage(root, "SD card")?.let { list.add(it) }
                }
            }
        }
    } catch (e: Exception) {
        // ignore: SD card not available
    }
    return list
}

private fun sumMediaSize(context: Context, uri: android.net.Uri): Long {
    var total = 0L
    try {
        context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { c ->
            val idx = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
            if (idx >= 0) {
                while (c.moveToNext()) total += c.getLong(idx)
            }
        }
    } catch (e: Exception) {
        // permission not granted yet
    }
    return total
}

private fun formatBytes(bytes: Long): String {
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.2f GB", gb)
        mb >= 1.0 -> String.format("%.1f MB", mb)
        else -> String.format("%.0f KB", kb)
    }
}

@Composable
fun StorageScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val displayedVideos by viewModel.displayedVideos.collectAsState()
    val history by viewModel.displayedHistoryVideos.collectAsState()

    var storages by remember { mutableStateOf<List<StorageInfo>>(emptyList()) }
    var videoBytes by remember { mutableStateOf(0L) }
    var audioBytes by remember { mutableStateOf(0L) }
    var imageBytes by remember { mutableStateOf(0L) }
    var section by remember { mutableStateOf("Large Files") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            storages = loadStorages(context)
            videoBytes = sumMediaSize(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            audioBytes = sumMediaSize(context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
            imageBytes = sumMediaSize(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        }
    }

    val playedIds = remember(history) { history.map { it.uriString }.toSet() }
    val sectionVideos: List<VideoItem> = when (section) {
        "Recently Played" -> history
        "Recently Added" -> displayedVideos.sortedByDescending { it.dateModified }.take(40)
        "Haven't Played" -> displayedVideos.filter { it.uriString !in playedIds }
        else -> displayedVideos.filter { it.sizeBytes >= 100L * 1024 * 1024 }.sortedByDescending { it.sizeBytes }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        EvaTopBar(
            title = "Storage",
            canNavigateBack = true,
            onNavigateBack = { viewModel.navigateBack() },
            showSearchAndSort = false
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp)
        ) {
            // Phone memory + SD card usage
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurface)
                        .padding(16.dp)
                ) {
                    if (storages.isEmpty()) {
                        Text("Reading storage...", color = TextSecondary, fontSize = 13.sp)
                    }
                    storages.forEachIndexed { index, st ->
                        if (index > 0) Spacer(modifier = Modifier.height(14.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(st.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "Used ${formatBytes(st.usedBytes)} / ${formatBytes(st.totalBytes)}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { (st.usedBytes.toFloat() / st.totalBytes.toFloat()).coerceIn(0f, 1f) },
                            color = com.example.ui.theme.TextPrimary,
                            trackColor = com.example.ui.theme.ProgressTrackDark,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        CategoryStat("Video", formatBytes(videoBytes), Modifier.weight(1f))
                        CategoryStat("Music", formatBytes(audioBytes), Modifier.weight(1f))
                        CategoryStat("Image", formatBytes(imageBytes), Modifier.weight(1f))
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Section chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Recently Played", "Large Files", "Recently Added", "Haven't Played").forEach { name ->
                        val selected = section == name
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Color.White else DarkSurface)
                                .clickable { section = name }
                                .padding(horizontal = 4.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = name,
                                color = if (selected) Color.Black else TextPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 2
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "$section (${sectionVideos.size})",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            if (sectionVideos.isEmpty()) {
                item {
                    Text(
                        text = "Nothing here yet.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }
            } else {
                items(sectionVideos, key = { it.uriString }) { video ->
                    VideoListCard(
                        video = video,
                        onClick = {
                            viewModel.navigateTo(
                                ScreenRoute.Player(
                                    video = video,
                                    playlist = sectionVideos,
                                    startIndex = sectionVideos.indexOf(video)
                                )
                            )
                        },
                        onMenuClick = { viewModel.openActionSheet(video) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(label, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(value, color = TextSecondary, fontSize = 12.sp)
    }
}
