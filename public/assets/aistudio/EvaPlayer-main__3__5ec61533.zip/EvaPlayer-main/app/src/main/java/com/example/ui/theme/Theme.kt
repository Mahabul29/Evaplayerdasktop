package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

@Composable
fun EvaPlayerTheme(
    themeMode: String = "Dark", // "Dark", "Light", "AMOLED"
    accentColorName: String = "Blue",
    content: @Composable () -> Unit
) {
    val accent = getAccentColor(accentColorName)
    // Publish the chosen accent so every screen that uses GreenAccent picks it up.
    // Set during composition (not in a SideEffect) so the first frame is already correct.
    AccentState.color = accent
    AccentState.colorDark = accent.copy(
        red = accent.red * 0.7f, green = accent.green * 0.7f, blue = accent.blue * 0.7f
    )
    // Publish the theme so DarkBackground / TextPrimary / etc. switch with it.
    ThemeState.mode = themeMode
    val isAmoled = themeMode.equals("AMOLED", ignoreCase = true)
    val isLight = themeMode.equals("Light", ignoreCase = true)

    // Dark status/navigation bar icons on the light theme so the clock and battery stay readable.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            var c = view.context
            while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
            (c as? Activity)?.window?.let { w ->
                val controller = WindowCompat.getInsetsController(w, view)
                controller.isAppearanceLightStatusBars = isLight
                controller.isAppearanceLightNavigationBars = isLight
            }
        }
    }

    val colorScheme = when {
        isLight -> lightColorScheme(
            primary = accent,
            onPrimary = if (accent.luminance() > 0.6f) Color.Black else Color.White,
            primaryContainer = accent.copy(alpha = 0.2f),
            onPrimaryContainer = Color.Black,
            background = DarkBackground,
            onBackground = TextPrimary,
            surface = DarkSurface,
            onSurface = TextPrimary,
            surfaceVariant = DarkSurfaceContainer,
            onSurfaceVariant = TextSecondary,
            outline = DividerDark
        )
        isAmoled -> darkColorScheme(
            primary = accent,
            onPrimary = if (accent.luminance() > 0.6f) Color.Black else Color.White,
            primaryContainer = accent.copy(alpha = 0.2f),
            onPrimaryContainer = TextPrimary,
            background = AmoledBackground,
            onBackground = TextPrimary,
            surface = AmoledSurface,
            onSurface = TextPrimary,
            surfaceVariant = Color(0xFF181818),
            onSurfaceVariant = TextSecondary,
            outline = DividerDark
        )
        else -> darkColorScheme(
            primary = accent,
            onPrimary = if (accent.luminance() > 0.6f) Color.Black else Color.White,
            primaryContainer = accent.copy(alpha = 0.2f),
            onPrimaryContainer = TextPrimary,
            background = DarkBackground,
            onBackground = TextPrimary,
            surface = DarkSurface,
            onSurface = TextPrimary,
            surfaceVariant = DarkSurfaceContainer,
            onSurfaceVariant = TextSecondary,
            outline = DividerDark
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
