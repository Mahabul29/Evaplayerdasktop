package com.example.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.AdsterraBanner
import com.example.ads.AdsterraFormat
import com.example.ui.theme.GreenAccent

/**
 * Shown on top of the player when the user pauses a video:
 * a friendly "hydration break" reminder with an ad.
 */
@Composable
fun HydrationBreakOverlay(
    landscape: Boolean,
    onResume: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.88f))
            // swallow taps so the video gestures underneath don't fire
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        if (landscape) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.padding(horizontal = 24.dp)
            ) {
                AdsterraBanner(
                    format = AdsterraFormat.RECT_300x250,
                    scale = 0.8f,
                    fillWidth = false
                )
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(230.dp)
                ) {
                    HydrationMessage()
                    Spacer(Modifier.height(16.dp))
                    HydrationButtons(onResume, onClose)
                }
            }
        } else {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 24.dp)
            ) {
                HydrationMessage()
                Spacer(Modifier.height(16.dp))
                AdsterraBanner(
                    format = AdsterraFormat.RECT_300x250,
                    scale = 0.9f,
                    fillWidth = false
                )
                Spacer(Modifier.height(16.dp))
                HydrationButtons(onResume, onClose)
            }
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
private fun HydrationMessage() {
    Text(
        text = "\uD83D\uDCA7 Hydration break",
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
    )
    Spacer(Modifier.height(6.dp))
    Text(
        text = "Your video is paused. Take a sip of water and rest your eyes.",
        color = Color(0xFFB0B8C4),
        fontSize = 13.sp,
        textAlign = TextAlign.Center
    )
}

@Composable
private fun HydrationButtons(onResume: () -> Unit, onClose: () -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = onResume,
            colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.Black,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text("Resume", color = Color.Black, fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = onClose) {
            Text("Close", color = Color.White)
        }
    }
}
