package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudioItem
import com.example.data.model.BrowserFileItem
import com.example.data.model.VideoItem
import com.example.ui.components.EvaTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.BrowserFilter
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute
import java.io.File

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BrowserScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentPath by viewModel.browserCurrentPath.collectAsState()
    val allFiles by viewModel.browserFiles.collectAsState()
    val filter by viewModel.browserFilter.collectAsState()
    val selectedFiles by viewModel.selectedBrowserFiles.collectAsState()
    val isSearchOpen by viewModel.isSearchOpen.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()

    // Back goes to parent folder
    BackHandler(enabled = true) {
        if (!viewModel.navigateBrowserUp()) {
            viewModel.selectTab(MainTab.FOLDERS)
        }
    }

    // Filter files
    val displayedFiles = remember(allFiles, filter, searchQuery) {
        var list = when (filter) {
            BrowserFilter.ALL -> allFiles
            BrowserFilter.VIDEO -> allFiles.filter { it.isDirectory || it.isVideo }
            BrowserFilter.AUDIO -> allFiles.filter { it.isDirectory || it.isAudio }
            BrowserFilter.SUBTITLES -> allFiles.filter { it.isDirectory || it.isSubtitle }
        }
        if (searchQuery.isNotBlank()) {
            list = list.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }
        list
    }

    val isMultiSelectMode = selectedFiles.isNotEmpty()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        if (isMultiSelectMode) {
            // Multi-select top bar (Share, Delete, Hide, Cancel)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.clearBrowserSelection() }) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextPrimary)
                }

                Text(
                    text = "${selectedFiles.size} selected",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                IconButton(onClick = {
                    // Multi-select share
                    val uris = selectedFiles.map { Uri.fromFile(File(it)) }
                    val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                        type = "*/*"
                        putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Share Files"))
                    viewModel.clearBrowserSelection()
                }) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = TextPrimary)
                }

                IconButton(onClick = {
                    // Multi-select hide
                    selectedFiles.forEach { path ->
                        val file = File(path)
                        viewModel.hideFolder(path)
                    }
                    viewModel.showToast("${selectedFiles.size} items hidden")
                    viewModel.clearBrowserSelection()
                    viewModel.loadBrowserFiles(currentPath)
                }) {
                    Icon(imageVector = Icons.Default.VisibilityOff, contentDescription = "Hide", tint = TextPrimary)
                }

                IconButton(onClick = {
                    // Multi-select delete
                    var count = 0
                    selectedFiles.forEach { path ->
                        val file = File(path)
                        if (file.delete()) count++
                    }
                    viewModel.showToast("Deleted $count items")
                    viewModel.clearBrowserSelection()
                    viewModel.loadBrowserFiles(currentPath)
                }) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252))
                }
            }
        } else {
            // Standard Top Bar
            EvaTopBar(
                title = "Browser",
                isSearchOpen = isSearchOpen,
                searchQuery = searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onSearchToggle = { viewModel.setSearchOpen(it) },
                sortMode = sortMode,
                onSortModeChange = { viewModel.setSortMode(it) },
                onSettingsClick = { viewModel.selectTab(MainTab.SETTINGS) }
            )
        }

        // Breadcrumb Path Bar
        BreadcrumbBar(
            currentPath = currentPath,
            onSegmentClick = { targetPath -> viewModel.loadBrowserFiles(targetPath) },
            onUpClick = { viewModel.navigateBrowserUp() }
        )

        // Filter chips: All / Video / Audio / Subtitles
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filterOptions = listOf(
                Pair("All", BrowserFilter.ALL),
                Pair("Video", BrowserFilter.VIDEO),
                Pair("Audio", BrowserFilter.AUDIO),
                Pair("Subtitles", BrowserFilter.SUBTITLES)
            )
            items(filterOptions) { (name, bFilter) ->
                val isSelected = filter == bFilter
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .height(30.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(if (isSelected) GreenAccent else DarkSurface)
                        .clickable { viewModel.setBrowserFilter(bFilter) }
                        .padding(horizontal = 14.dp)
                ) {
                    Text(
                        text = name,
                        color = if (isSelected) Color.White else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }

        // File List
        if (displayedFiles.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp)
            ) {
                Text(
                    text = if (searchQuery.isNotEmpty()) "No results found" else "Folder is empty",
                    color = TextSecondary,
                    fontSize = 15.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    top = 4.dp,
                    start = 16.dp,
                    end = 16.dp,
                    bottom = 80.dp
                )
            ) {
                items(displayedFiles, key = { it.path }) { fileItem ->
                    val isSelected = fileItem.path in selectedFiles

                    BrowserItemCard(
                        item = fileItem,
                        isSelected = isSelected,
                        isMultiSelectMode = isMultiSelectMode,
                        onClick = {
                            if (isMultiSelectMode) {
                                viewModel.toggleBrowserFileSelection(fileItem.path)
                            } else {
                                if (fileItem.isDirectory) {
                                    viewModel.loadBrowserFiles(fileItem.path)
                                } else if (fileItem.isVideo) {
                                    // Play video
                                    val folderVideos = displayedFiles.filter { it.isVideo }.map { f ->
                                        VideoItem(
                                            id = f.path,
                                            title = f.name.substringBeforeLast('.'),
                                            path = f.path,
                                            uriString = f.path,
                                            durationMs = 0L,
                                            sizeBytes = f.sizeBytes,
                                            dateModified = f.dateModified / 1000,
                                            folderName = File(f.path).parentFile?.name ?: "Folder",
                                            folderPath = File(f.path).parent ?: "",
                                            format = f.name.substringAfterLast('.').uppercase()
                                        )
                                    }
                                    val video = folderVideos.find { it.id == fileItem.path } ?: VideoItem(
                                        id = fileItem.path,
                                        title = fileItem.name.substringBeforeLast('.'),
                                        path = fileItem.path,
                                        uriString = fileItem.path,
                                        durationMs = 0L,
                                        sizeBytes = fileItem.sizeBytes,
                                        dateModified = fileItem.dateModified / 1000,
                                        folderName = File(fileItem.path).parentFile?.name ?: "Folder",
                                        folderPath = File(fileItem.path).parent ?: "",
                                        format = fileItem.name.substringAfterLast('.').uppercase()
                                    )
                                    val startIndex = folderVideos.indexOfFirst { it.id == video.id }.coerceAtLeast(0)
                                    viewModel.navigateTo(ScreenRoute.Player(video = video, playlist = folderVideos, startIndex = startIndex))
                                } else if (fileItem.isAudio) {
                                    // Play audio
                                    val audio = AudioItem(
                                        id = fileItem.path,
                                        title = fileItem.name.substringBeforeLast('.'),
                                        artist = "Local Audio",
                                        album = File(fileItem.path).parentFile?.name ?: "Music",
                                        uriString = fileItem.path,
                                        path = fileItem.path,
                                        durationMs = 0L,
                                        sizeBytes = fileItem.sizeBytes
                                    )
                                    viewModel.playAudio(audio)
                                    viewModel.navigateTo(ScreenRoute.Music)
                                } else {
                                    viewModel.showToast("Cannot preview ${fileItem.name}")
                                }
                            }
                        },
                        onLongClick = {
                            viewModel.toggleBrowserFileSelection(fileItem.path)
                        },
                        onAction = { action ->
                            handleBrowserAction(action, fileItem, viewModel, context)
                        }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun BreadcrumbBar(
    currentPath: String,
    onSegmentClick: (String) -> Unit,
    onUpClick: () -> Unit
) {
    val scrollState = rememberScrollState()
    val segments = currentPath.split("/").filter { it.isNotEmpty() }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface.copy(alpha = 0.6f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onUpClick,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Up",
                tint = GreenAccent,
                modifier = Modifier.size(18.dp)
            )
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(scrollState),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Home",
                color = GreenAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clickable { onSegmentClick(android.os.Environment.getExternalStorageDirectory().absolutePath) }
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            )

            var accumulated = ""
            segments.forEach { seg ->
                accumulated += "/$seg"
                val target = accumulated

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(14.dp)
                )

                Text(
                    text = seg,
                    color = if (target == currentPath) TextPrimary else TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier
                        .clickable { onSegmentClick(target) }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BrowserItemCard(
    item: BrowserFileItem,
    isSelected: Boolean,
    isMultiSelectMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onAction: (String) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    val icon: ImageVector = when {
        item.isDirectory -> Icons.Default.Folder
        item.isVideo -> Icons.Default.Movie
        item.isAudio -> Icons.Default.Audiotrack
        item.isSubtitle -> Icons.Default.Subtitles
        else -> Icons.Default.InsertDriveFile
    }

    val iconColor: Color = when {
        item.isDirectory -> Color(0xFFE0E0E0)
        item.isVideo -> GreenAccent
        item.isAudio -> Color(0xFF448AFF)
        item.isSubtitle -> Color(0xFFB388FF)
        else -> TextSecondary
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) GreenAccent.copy(alpha = 0.15f) else DarkSurface
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isMultiSelectMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) GreenAccent else TextSecondary,
                    modifier = Modifier
                        .size(22.dp)
                        .padding(end = 6.dp)
                )
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(iconColor.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = if (item.isDirectory) "Folder" else "${item.sizeFormatted} • ${item.name.substringAfterLast('.', "").uppercase()}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }

            // Three-dot menu: Play, Rename, Share, Delete, Hide, Properties
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(DarkSurface)
                ) {
                    if (item.isVideo || item.isAudio) {
                        DropdownMenuItem(
                            text = { Text("Play", color = TextPrimary) },
                            onClick = {
                                showMenu = false
                                onAction("Play")
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Rename", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onAction("Rename")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onAction("Share")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Hide", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onAction("Hide")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Properties", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onAction("Properties")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = Color(0xFFFF5252)) },
                        onClick = {
                            showMenu = false
                            onAction("Delete")
                        }
                    )
                }
            }
        }
    }
}

private fun handleBrowserAction(
    action: String,
    item: BrowserFileItem,
    viewModel: MainViewModel,
    context: android.content.Context
) {
    when (action) {
        "Play" -> {
            if (item.isVideo) {
                val video = VideoItem(
                    id = item.path,
                    title = item.name.substringBeforeLast('.'),
                    path = item.path,
                    uriString = item.path,
                    durationMs = 0L,
                    sizeBytes = item.sizeBytes,
                    dateModified = item.dateModified / 1000,
                    folderName = File(item.path).parentFile?.name ?: "Folder",
                    folderPath = File(item.path).parent ?: "",
                    format = item.name.substringAfterLast('.').uppercase()
                )
                viewModel.navigateTo(ScreenRoute.Player(video = video))
            } else if (item.isAudio) {
                val audio = AudioItem(
                    id = item.path,
                    title = item.name.substringBeforeLast('.'),
                    artist = "Local Audio",
                    album = File(item.path).parentFile?.name ?: "Music",
                    uriString = item.path,
                    path = item.path,
                    durationMs = 0L,
                    sizeBytes = item.sizeBytes
                )
                viewModel.playAudio(audio)
                viewModel.navigateTo(ScreenRoute.Music)
            }
        }
        "Share" -> {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = item.mimeType ?: "*/*"
                    putExtra(Intent.EXTRA_STREAM, Uri.fromFile(File(item.path)))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share ${item.name}"))
            } catch (e: Exception) {
                viewModel.showToast("Could not share file")
            }
        }
        "Delete" -> {
            val file = File(item.path)
            if (file.delete()) {
                viewModel.showToast("Deleted ${item.name}")
                viewModel.loadBrowserFiles(viewModel.browserCurrentPath.value)
            } else {
                viewModel.showToast("Could not delete file")
            }
        }
        "Hide" -> {
            viewModel.hideFolder(item.path)
            viewModel.showToast("Hidden ${item.name}")
            viewModel.loadBrowserFiles(viewModel.browserCurrentPath.value)
        }
        "Properties" -> {
            val f = File(item.path)
            viewModel.showToast("${item.name}\nSize: ${item.sizeFormatted}\nPath: ${f.absolutePath}")
        }
    }
}
