package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.filled.Storage
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.ProgressTrackDark
import com.example.ui.theme.TextPrimary

data class QuickActionItem(
    val title: String,
    val icon: ImageVector,
    val onClick: () -> Unit,
    val color: Color = Color(0xFF2F80FF)
)

@Composable
fun QuickActionRow(
    onMusicClick: () -> Unit,
    onUrlStreamClick: () -> Unit,
    onFileTransferClick: () -> Unit,
    onPlaylistsClick: () -> Unit,
    onFavoritesClick: () -> Unit,
    onHideVideosClick: () -> Unit,
    onPrivacyClick: () -> Unit,
    onStorageClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val actions = listOf(
        QuickActionItem("Music", Icons.Default.MusicNote, onMusicClick, Color(0xFFE91E63)),
        QuickActionItem("URL Stream", Icons.Default.Link, onUrlStreamClick, Color(0xFF7C4DFF)),
        QuickActionItem("File Transfer", Icons.Default.Wifi, onFileTransferClick, Color(0xFF1EA7FF)),
        QuickActionItem("Playlists", Icons.Default.PlaylistPlay, onPlaylistsClick, Color(0xFF00C853)),
        QuickActionItem("Favorites", Icons.Default.Favorite, onFavoritesClick, Color(0xFFFF3D57)),
        QuickActionItem("Hide Videos", Icons.Default.VisibilityOff, onHideVideosClick, Color(0xFF5C6BC0)),
        QuickActionItem("Privacy", Icons.Default.Security, onPrivacyClick, Color(0xFF2979FF)),
        QuickActionItem("Storage", Icons.Default.Storage, onStorageClick, Color(0xFFFF9800))
    )

    // Compact single row that scrolls left <-> right
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(start = 0.dp, end = 10.dp, top = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Top
    ) {
        actions.forEach { action ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(62.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { action.onClick() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .width(40.dp)
                        .height(28.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceContainer)
                ) {
                    Icon(
                        imageVector = action.icon,
                        contentDescription = action.title,
                        tint = action.color,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = action.title,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Normal,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
