package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.components.VideoSelectionTopBar
import com.example.ui.components.SortBottomSheet
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ui.theme.DarkSurfaceContainer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EvaTopBar
import com.example.ui.components.VideoGridCard
import com.example.ui.components.VideoListCard
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute

@Composable
fun VideosScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val displayedVideos by viewModel.displayedVideos.collectAsState()
    val selectedUris by viewModel.selectedUris.collectAsState()
    val isSelecting = selectedUris.isNotEmpty()
    val isSearchOpen by viewModel.isSearchOpen.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()
    val isGrid by viewModel.isVideoGrid.collectAsState()
    val activeChip by viewModel.videoFilterChip.collectAsState()

    val chips = listOf("All", "Recent", "Favorites")
    var showSortSheet by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top Bar (swapped for the selection bar while videos are selected)
        if (isSelecting) {
            VideoSelectionTopBar(viewModel = viewModel, videos = displayedVideos)
        } else {
            EvaTopBar(
                title = "EvaPlayer",
                isSearchOpen = isSearchOpen,
                searchQuery = searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onSearchToggle = { viewModel.setSearchOpen(it) },
                sortMode = sortMode,
                onSortModeChange = { viewModel.setSortMode(it) },
                onSettingsClick = { viewModel.selectTab(MainTab.SETTINGS) },
                onRefreshClick = { viewModel.refreshMedia() }
            )
        }

        // Filter chips row with List/Grid toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LazyRow(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chips) { chip ->
                    val isSelected = activeChip == chip
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) GreenAccent else DarkSurfaceContainer)
                            .clickable { viewModel.setVideoFilterChip(chip) }
                            .padding(horizontal = 14.dp)
                    ) {
                        Text(
                            text = chip,
                            color = if (isSelected) Color.White else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
            }

            IconButton(
                onClick = { showSortSheet = true },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Sort,
                    contentDescription = "Sort",
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }

            IconButton(
                onClick = { viewModel.toggleVideoGrid() },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isGrid) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                    contentDescription = "Toggle Grid/List",
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (displayedVideos.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp)
            ) {
                Text(
                    text = if (searchQuery.isNotEmpty()) "No results found" else "No videos found",
                    color = TextSecondary,
                    fontSize = 15.sp
                )
            }
        } else {
            val feed = com.example.ads.withAdSlots(displayedVideos, com.example.ads.AdsterraConfig.VIDEO_EVERY)
            if (isGrid) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        top = 8.dp,
                        start = 16.dp,
                        end = 16.dp,
                        bottom = 80.dp
                    ),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(
                        feed,
                        key = { e -> when (e) {
                            is com.example.ads.FeedEntry.Item -> e.value.uriString
                            is com.example.ads.FeedEntry.AdSlot -> "videos_grid_ad_${e.index}"
                        } },
                        span = { e -> if (e is com.example.ads.FeedEntry.AdSlot) GridItemSpan(maxLineSpan) else GridItemSpan(1) }
                    ) { entry ->
                        when (entry) {
                            is com.example.ads.FeedEntry.AdSlot ->
                                com.example.ads.InFeedAd(slotKey = "videos_grid_${entry.index}")
                            is com.example.ads.FeedEntry.Item -> {
                                val video = entry.value
                        VideoGridCard(
                            video = video,
                            isSelectionMode = isSelecting,
                            isSelected = video.uriString in selectedUris,
                            onLongClick = { viewModel.toggleSelection(video) },
                            onClick = {
                                if (isSelecting) { viewModel.toggleSelection(video); return@VideoGridCard }
                                viewModel.navigateTo(
                                    ScreenRoute.Player(
                                        video = video,
                                        playlist = displayedVideos,
                                        startIndex = displayedVideos.indexOf(video)
                                    )
                                )
                            },
                            onMenuClick = { viewModel.openActionSheet(video) }
                        )
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        top = 8.dp,
                        start = 16.dp,
                        end = 16.dp,
                        bottom = 80.dp
                    )
                ) {
                    items(
                        feed,
                        key = { e -> when (e) {
                            is com.example.ads.FeedEntry.Item -> e.value.uriString
                            is com.example.ads.FeedEntry.AdSlot -> "videos_list_ad_${e.index}"
                        } }
                    ) { entry ->
                        when (entry) {
                            is com.example.ads.FeedEntry.AdSlot ->
                                com.example.ads.InFeedAd(slotKey = "videos_list_${entry.index}")
                            is com.example.ads.FeedEntry.Item -> {
                                val video = entry.value
                        VideoListCard(
                            video = video,
                            isSelectionMode = isSelecting,
                            isSelected = video.uriString in selectedUris,
                            onLongClick = { viewModel.toggleSelection(video) },
                            onClick = {
                                if (isSelecting) { viewModel.toggleSelection(video); return@VideoListCard }
                                viewModel.navigateTo(
                                    ScreenRoute.Player(
                                        video = video,
                                        playlist = displayedVideos,
                                        startIndex = displayedVideos.indexOf(video)
                                    )
                                )
                            },
                            onMenuClick = { viewModel.openActionSheet(video) },
                            modifier = Modifier.padding(bottom = 10.dp)
                        )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortSheet) {
        SortBottomSheet(
            current = sortMode,
            onApply = { viewModel.setSortMode(it) },
            onDismiss = { showSortSheet = false }
        )
    }
}
