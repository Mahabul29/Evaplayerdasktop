package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FolderItem
import com.example.data.model.VideoItem
import com.example.ui.components.EvaTopBar
import com.example.ui.components.FolderCard
import com.example.ui.components.HistoryRowSection
import com.example.ui.components.QuickActionRow
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute

@Composable
fun FoldersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val displayedFolders by viewModel.displayedFolders.collectAsState()
    val historyVideos by viewModel.displayedHistoryVideos.collectAsState()
    val isSearchOpen by viewModel.isSearchOpen.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()

    val showHistory = historyVideos.isNotEmpty() && searchQuery.isEmpty()
    val isEmpty = displayedFolders.isEmpty() && historyVideos.isEmpty()

    // Header stays pinned at the top; only the content below it scrolls.
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
    EvaTopBar(
        title = "EvaPlayer",
        isSearchOpen = isSearchOpen,
        searchQuery = searchQuery,
        onSearchQueryChange = { viewModel.setSearchQuery(it) },
        onSearchToggle = { viewModel.setSearchOpen(it) },
        sortMode = sortMode,
        onSortModeChange = { viewModel.setSortMode(it) },
        onSettingsClick = { viewModel.selectTab(MainTab.SETTINGS) },
        onRefreshClick = { viewModel.refreshMedia() }
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
        contentPadding = PaddingValues(bottom = 80.dp) // nav height (64dp) + 16dp
    ) {
        // Quick-action grid directly under the title
        item(key = "quick_actions") {
            QuickActionRow(
                onMusicClick = { viewModel.navigateTo(ScreenRoute.Music) },
                onUrlStreamClick = { viewModel.navigateTo(ScreenRoute.UrlStream) },
                onFileTransferClick = { viewModel.navigateTo(ScreenRoute.FileTransfer) },
                onPlaylistsClick = { viewModel.navigateTo(ScreenRoute.Playlists) },
                onFavoritesClick = { viewModel.navigateTo(ScreenRoute.Favorites) },
                onHideVideosClick = { viewModel.navigateTo(ScreenRoute.HiddenVideos) },
                onPrivacyClick = { viewModel.navigateTo(ScreenRoute.PrivacySettings) },
                onStorageClick = { viewModel.navigateTo(ScreenRoute.Storage) }
            )
            Spacer(modifier = Modifier.height(2.dp))
        }

        item(key = "ad_rect") {
            com.example.ads.AdsterraBanner(
                format = com.example.ads.AdsterraFormat.RECT_300x250,
                scale = 0.8f,
                slotKey = "fixed_home_top",
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        if (isEmpty) {
            item(key = "empty") {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillParentMaxWidth()
                        .padding(vertical = 80.dp)
                ) {
                    Text(
                        text = if (searchQuery.isNotEmpty()) "No results found" else "No video folders found",
                        color = TextSecondary,
                        fontSize = 15.sp
                    )
                }
            }
        } else {
            // History Row
            if (showHistory) {
                item(key = "history") {
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        HistoryRowSection(
                            historyVideos = historyVideos,
                            onVideoClick = { video ->
                                viewModel.navigateTo(ScreenRoute.Player(video = video, playlist = historyVideos))
                            },
                            onClearHistory = { viewModel.clearPlaybackHistory() },
                            onRemoveFromHistory = { video -> viewModel.removeFromHistory(video.uriString) },
                            onPlayFromStart = { video ->
                                viewModel.navigateTo(ScreenRoute.Player(video = video.copy(lastPositionMs = 0L), playlist = historyVideos))
                            }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }

            // Section title
            item(key = "folders_title") {
                Text(
                    text = "Folders (${displayedFolders.size})",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                )
            }

            // Folder cards with an ad slipped in after every few folders
            val folderFeed = com.example.ads.withAdSlots(displayedFolders, com.example.ads.AdsterraConfig.FOLDER_EVERY)
            items(
                folderFeed,
                key = { e ->
                    when (e) {
                        is com.example.ads.FeedEntry.Item -> e.value.path
                        is com.example.ads.FeedEntry.AdSlot -> "folder_ad_${e.index}"
                    }
                }
            ) { entry ->
                when (entry) {
                    is com.example.ads.FeedEntry.Item -> {
                        val folder = entry.value
                        FolderCard(
                            folder = folder,
                            onClick = {
                                viewModel.navigateTo(ScreenRoute.FolderDetail(folder.name, folder.path))
                            },
                            onLongClick = { viewModel.openFolderSheet(folder) },
                            onMenuClick = { viewModel.openFolderSheet(folder) },
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
                        )
                    }
                    is com.example.ads.FeedEntry.AdSlot ->
                        com.example.ads.InFeedAd(slotKey = "folders_${entry.index}")
                }
            }
        }
    }
    }
}
