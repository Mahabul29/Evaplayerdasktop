package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.SurroundSound
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.R
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EvaTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()

    var showDialogType by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        EvaTopBar(
            title = "Settings",
            showSearchAndSort = false
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 8.dp, start = 16.dp, end = 16.dp, bottom = 80.dp)
        ) {
            item(key = "ad_rect") {
                com.example.ads.AdsterraBanner(
                    format = com.example.ads.AdsterraFormat.RECT_300x250,
                    slotKey = "fixed_settings_top",
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            // === APPEARANCE ===
            item { SectionHeader(stringResource(R.string.section_appearance)) }
            item {
                SettingsCard(
                    icon = Icons.Default.Palette,
                    title = stringResource(R.string.theme),
                    subtitle = stringResource(R.string.theme_sub),
                    value = settings.theme,
                    onClick = { showDialogType = "THEME" }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.ColorLens,
                    title = stringResource(R.string.accent_color),
                    subtitle = stringResource(R.string.accent_color_sub),
                    value = settings.accentColor,
                    onClick = { showDialogType = "ACCENT" }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.Language,
                    title = stringResource(R.string.display_language),
                    subtitle = stringResource(R.string.display_language_sub),
                    value = settings.displayLanguage,
                    onClick = { showDialogType = "LANGUAGE" }
                )
            }

            // === AUDIO ===
            item { SectionHeader(stringResource(R.string.section_audio)) }
            item {
                SettingsCard(
                    icon = Icons.Default.VolumeUp,
                    title = stringResource(R.string.audio_boost),
                    subtitle = stringResource(R.string.audio_boost_sub),
                    value = "${settings.audioBoostPercent}%",
                    onClick = { showDialogType = "AUDIO_BOOST" }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.Timer,
                    title = stringResource(R.string.audio_delay),
                    subtitle = stringResource(R.string.audio_delay_sub),
                    value = "${settings.audioDelayMs} ms",
                    onClick = { showDialogType = "AUDIO_DELAY" }
                )
            }
            item {
                SettingsToggleCard(
                    icon = Icons.Default.Headphones,
                    title = "Background Playback",
                    subtitle = "Continue playing audio when screen is off or in background",
                    checked = settings.backgroundPlayback,
                    onCheckedChange = { coroutineScope.launch { viewModel.settingsRepo.updateBackgroundPlayback(it) } }
                )
            }
            item {
                SettingsToggleCard(
                    icon = Icons.Default.Headphones,
                    title = "Pause When Disconnected",
                    subtitle = "Pause playback when headphones or Bluetooth disconnect",
                    checked = settings.pauseOnHeadphoneDisconnect,
                    onCheckedChange = { coroutineScope.launch { viewModel.settingsRepo.updatePauseOnHeadphoneDisconnect(it) } }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.Timer,
                    title = "Skip Duration",
                    subtitle = "Double-tap seek interval",
                    value = "${settings.skipDurationSeconds}s",
                    onClick = { showDialogType = "SKIP_DURATION" }
                )
            }

            // === SCREEN ===
            item { SectionHeader(stringResource(R.string.section_screen)) }
            item {
                SettingsCard(
                    icon = Icons.Default.ScreenRotation,
                    title = "Orientation",
                    subtitle = "Playback screen orientation",
                    value = settings.orientation,
                    onClick = { showDialogType = "ORIENTATION" }
                )
            }
            item {
                SettingsToggleCard(
                    icon = Icons.Default.ScreenRotation,
                    title = "Keep Screen On",
                    subtitle = "Prevent screen from sleeping during playback",
                    checked = settings.keepScreenOn,
                    onCheckedChange = { coroutineScope.launch { viewModel.settingsRepo.updateKeepScreenOn(it) } }
                )
            }
            item {
                SettingsToggleCard(
                    icon = Icons.Default.PictureInPicture,
                    title = "Picture-in-Picture",
                    subtitle = "Floating player when exiting to home",
                    checked = settings.pipEnabled,
                    onCheckedChange = { coroutineScope.launch { viewModel.settingsRepo.updatePipEnabled(it) } }
                )
            }
            item {
                SettingsToggleCard(
                    icon = Icons.Default.Info,
                    title = "Show Battery & Time",
                    subtitle = "Display status in player overlay",
                    checked = settings.showBatteryAndTime,
                    onCheckedChange = { coroutineScope.launch { viewModel.settingsRepo.updateShowBatteryAndTime(it) } }
                )
            }
            // === MORE ===
            item { SectionHeader("MORE") }
            item {
                SettingsCard(
                    icon = Icons.Default.Subtitles,
                    title = "Subtitles",
                    subtitle = "Text size, color, background & position",
                    value = "Custom",
                    onClick = { viewModel.navigateTo(ScreenRoute.SubtitleSettings) }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.Security,
                    title = "Privacy & Storage",
                    subtitle = "App lock PIN, history & hidden items",
                    value = if (settings.appLockEnabled) "Locked" else "Unlocked",
                    onClick = { viewModel.navigateTo(ScreenRoute.PrivacySettings) }
                )
            }

            // === ABOUT ===
            item { SectionHeader("ABOUT") }
            item {
                SettingsCard(
                    icon = Icons.Default.Info,
                    title = "EvaPlayer Version",
                    subtitle = "Native Media3 Android Engine",
                    value = "v1.0.0",
                    onClick = { viewModel.showToast("EvaPlayer v1.0.0 - Up to date") }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.Star,
                    title = "Rate App",
                    subtitle = "Support EvaPlayer development",
                    value = "5.0 ★",
                    onClick = { viewModel.showToast("Thank you for your rating!") }
                )
            }
            item {
                SettingsCard(
                    icon = Icons.Default.Share,
                    title = "Share App",
                    subtitle = "Tell your friends about EvaPlayer",
                    value = "",
                    onClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "Check out EvaPlayer - The ultimate native Android media player!")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share EvaPlayer"))
                    }
                )
            }
        }
    }

    // Dialogs for quick single-choice settings
    when (showDialogType) {
        "THEME" -> {
            SingleChoiceDialog(
                title = "Choose Theme",
                options = listOf("Dark", "Light", "AMOLED"),
                selected = settings.theme,
                onSelect = {
                    coroutineScope.launch { viewModel.settingsRepo.updateTheme(it) }
                    showDialogType = null
                },
                onDismiss = { showDialogType = null }
            )
        }
        "ACCENT" -> {
            SingleChoiceDialog(
                title = "Choose Accent Color",
                options = listOf("White", "Green", "Purple", "Blue", "Red", "Orange", "Pink"),
                selected = settings.accentColor,
                onSelect = {
                    coroutineScope.launch { viewModel.settingsRepo.updateAccentColor(it) }
                    showDialogType = null
                },
                onDismiss = { showDialogType = null }
            )
        }
        "LANGUAGE" -> {
            SingleChoiceDialog(
                title = "Display Language",
                options = listOf("English", "Bangla", "Hindi"),
                selected = settings.displayLanguage,
                onSelect = {
                    coroutineScope.launch { viewModel.settingsRepo.updateDisplayLanguage(it) }
                    // MainActivity notices the change, saves the locale and rebuilds the screen
                    showDialogType = null
                },
                onDismiss = { showDialogType = null }
            )
        }
        "SKIP_DURATION" -> {
            SingleChoiceDialog(
                title = "Skip Duration",
                options = listOf("5", "10", "15", "20", "30", "60"),
                selected = settings.skipDurationSeconds.toString(),
                onSelect = {
                    coroutineScope.launch { viewModel.settingsRepo.updateSkipDurationSeconds(it.toInt()) }
                    showDialogType = null
                },
                onDismiss = { showDialogType = null }
            )
        }
        "ORIENTATION" -> {
            SingleChoiceDialog(
                title = "Screen Orientation",
                options = listOf("Auto", "Landscape", "Portrait"),
                selected = settings.orientation,
                onSelect = {
                    coroutineScope.launch { viewModel.settingsRepo.updateOrientation(it) }
                    showDialogType = null
                },
                onDismiss = { showDialogType = null }
            )
        }
        "AUDIO_BOOST" -> {
            var boostVal by remember { mutableStateOf(settings.audioBoostPercent.toFloat()) }
            AlertDialog(
                onDismissRequest = { showDialogType = null },
                containerColor = DarkSurface,
                title = { Text("Audio Boost (up to 200%)", color = TextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("${boostVal.toInt()}%", color = GreenAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = boostVal,
                            onValueChange = { boostVal = it },
                            valueRange = 100f..200f,
                            steps = 19,
                            colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        coroutineScope.launch { viewModel.settingsRepo.updateAudioBoostPercent(boostVal.toInt()) }
                        showDialogType = null
                    }) {
                        Text("Save", color = GreenAccent, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialogType = null }) {
                        Text("Cancel", color = TextPrimary)
                    }
                }
            )
        }
        "AUDIO_DELAY" -> {
            var delayVal by remember { mutableStateOf(settings.audioDelayMs.toFloat()) }
            AlertDialog(
                onDismissRequest = { showDialogType = null },
                containerColor = DarkSurface,
                title = { Text("Audio Delay", color = TextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("${delayVal.toInt()} ms", color = GreenAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = delayVal,
                            onValueChange = { delayVal = it },
                            valueRange = -500f..500f,
                            steps = 20,
                            colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        coroutineScope.launch { viewModel.settingsRepo.updateAudioDelayMs(delayVal.toInt()) }
                        showDialogType = null
                    }) {
                        Text("Save", color = GreenAccent, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialogType = null }) {
                        Text("Cancel", color = TextPrimary)
                    }
                }
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        color = GreenAccent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp, start = 4.dp)
    )
}

@Composable
private fun SettingsCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    value: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(GreenAccent.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GreenAccent,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(text = subtitle, color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            if (value.isNotEmpty()) {
                Text(
                    text = value,
                    color = GreenAccent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun SettingsToggleCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(GreenAccent.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GreenAccent,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(text = subtitle, color = TextSecondary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = GreenAccent,
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = DarkSurfaceContainer
                )
            )
        }
    }
}

@Composable
private fun SingleChoiceDialog(
    title: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = { Text(title, color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                options.forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(opt) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = opt.equals(selected, ignoreCase = true),
                            onClick = { onSelect(opt) },
                            colors = RadioButtonDefaults.colors(selectedColor = GreenAccent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = opt, color = TextPrimary, fontSize = 15.sp)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}
