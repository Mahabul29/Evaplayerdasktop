package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.SortMode

enum class SortField(val label: String) {
    NAME("Name"), DATE("Date"), LENGTH("Length"), SIZE("Size")
}

fun SortMode.sortField(): SortField = when (this) {
    SortMode.NAME_ASC, SortMode.NAME_DESC -> SortField.NAME
    SortMode.DATE_ASC, SortMode.DATE_DESC -> SortField.DATE
    SortMode.DURATION_ASC, SortMode.DURATION_DESC -> SortField.LENGTH
    SortMode.SIZE_ASC, SortMode.SIZE_DESC -> SortField.SIZE
}

fun SortMode.isAscending(): Boolean = when (this) {
    SortMode.NAME_ASC, SortMode.DATE_ASC, SortMode.DURATION_ASC, SortMode.SIZE_ASC -> true
    else -> false
}

fun sortModeOf(field: SortField, ascending: Boolean): SortMode = when (field) {
    SortField.NAME -> if (ascending) SortMode.NAME_ASC else SortMode.NAME_DESC
    SortField.DATE -> if (ascending) SortMode.DATE_ASC else SortMode.DATE_DESC
    SortField.LENGTH -> if (ascending) SortMode.DURATION_ASC else SortMode.DURATION_DESC
    SortField.SIZE -> if (ascending) SortMode.SIZE_ASC else SortMode.SIZE_DESC
}

/** PLAYit-style "Sort by" sheet: Name / Date / Length / Size, then A to Z / Z to A, then Done. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SortBottomSheet(
    current: SortMode,
    onApply: (SortMode) -> Unit,
    onDismiss: () -> Unit,
    fields: List<SortField> = SortField.values().toList()
) {
    var field by remember { mutableStateOf(current.sortField().takeIf { it in fields } ?: fields.first()) }
    var ascending by remember { mutableStateOf(current.isAscending()) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Text("Sort by", color = TextSecondary, fontSize = 20.sp, modifier = Modifier.padding(bottom = 8.dp))

            fields.forEach { f ->
                SortRadioRow(f.label, selected = field == f) { field = f }
            }

            HorizontalDivider(color = DividerDark, modifier = Modifier.padding(vertical = 6.dp))

            SortRadioRow("A to Z", selected = ascending) { ascending = true }
            SortRadioRow("Z to A", selected = !ascending) { ascending = false }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = {
                        onApply(sortModeOf(field, ascending))
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenAccent, contentColor = Color.White)
                ) {
                    Text("Done", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun SortRadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(
                selectedColor = GreenAccent,
                unselectedColor = TextSecondary
            )
        )
        Spacer(Modifier.width(14.dp))
        Text(label, color = TextPrimary, fontSize = 17.sp)
    }
}
