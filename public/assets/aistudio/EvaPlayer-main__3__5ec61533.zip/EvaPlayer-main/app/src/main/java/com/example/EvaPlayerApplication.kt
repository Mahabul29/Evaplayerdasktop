package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.example.data.db.EvaDatabase
import com.example.data.repository.MediaRepository
import com.example.data.repository.PlaybackRepository
import com.example.data.repository.SettingsRepository

class EvaPlayerApplication : Application(), ImageLoaderFactory {

    lateinit var database: EvaDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var mediaRepository: MediaRepository
        private set

    lateinit var playbackRepository: PlaybackRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = EvaDatabase.getDatabase(this)
        settingsRepository = SettingsRepository(this)
        mediaRepository = MediaRepository(this)
        playbackRepository = PlaybackRepository(database.evaDao())

        createNotificationChannels()
    }

    /** Lets Coil draw real thumbnails for video files (otherwise list tiles stay grey). */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                PLAYBACK_CHANNEL_ID,
                "EvaPlayer Media Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows media controls for background video and music playback"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val PLAYBACK_CHANNEL_ID = "evaplayer_media_channel"
    }
}
