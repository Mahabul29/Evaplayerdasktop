package com.example.ads

import android.annotation.SuppressLint
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.MutableContextWrapper
import android.net.ConnectivityManager
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayInputStream
import java.util.WeakHashMap
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp

/** Adsterra iframe ad formats (key, width, height). */
enum class AdsterraFormat(val key: String, val w: Int, val h: Int) {
    BANNER_320x50("40157a0453352e4b3e8aa0979909fe7a", 320, 50),
    RECT_300x250("e7cd884636db86161514ff1d742cfea0", 300, 250),
    SKY_160x300("639cef3d5f00fd992b658bb2f7438a61", 160, 300),
    SKY_160x600("9b95ebea07f2561bd7c74705119458b9", 160, 600)
}

object AdsterraConfig {
    const val ENABLED = true
    // Base URL used as the page origin for the ad script (any https URL works).
    const val BASE_URL = "https://www.highrevenueformat.com/"

    /** In-feed ads: one ad after every N items, and never more than MAX per list (saves data). */
    const val FOLDER_EVERY = 0 // 0 = no in-feed ads in the folders list (only the big top ad)
    const val VIDEO_EVERY = 8
    const val MAX_FEED_ADS = 5

    // ---- Data savers ----
    /** true = ads load ONLY on unmetered Wi-Fi; on mobile data no ad is requested at all (0 data). */
    const val ADS_ONLY_ON_WIFI = false
    /** An ad stops all network use this long after it loaded (kills auto-refresh / ad videos). */
    const val FREEZE_AFTER_MS = 10_000L
    /** Max different in-feed ads loaded per app session (each is downloaded only once). */
    const val MAX_FEED_LOADS = 6

    /** Ads appear this long after their screen opens, so the app starts without ad traffic. */
    const val AD_DELAY_MS = 4_000L

    /** Ads load one after another, this far apart (never all at once). */
    const val AD_GAP_MS = 3_000L

    /** Inside a folder: 4 videos, small ad, 4 videos, small ad ... */
    const val FOLDER_VIDEO_EVERY = 4
    const val FOLDER_VIDEO_MAX_ADS = 20
}

/** A list row: either a real item or an in-feed ad slot. */
sealed class FeedEntry<out T> {
    data class Item<T>(val value: T) : FeedEntry<T>()
    data class AdSlot(val index: Int) : FeedEntry<Nothing>()
}

/** Inserts an ad slot after every [every] items (max [AdsterraConfig.MAX_FEED_ADS]). */
fun <T> withAdSlots(items: List<T>, every: Int, maxAds: Int = AdsterraConfig.MAX_FEED_ADS): List<FeedEntry<T>> {
    if (!AdsterraConfig.ENABLED || every <= 0) return items.map { FeedEntry.Item(it) }
    val out = ArrayList<FeedEntry<T>>(items.size + maxAds)
    var ads = 0
    items.forEachIndexed { i, item ->
        out.add(FeedEntry.Item(item))
        // Skip an ad right after the very last item so the list doesn't end on one.
        if ((i + 1) % every == 0 && i != items.lastIndex && ads < maxAds) {
            out.add(FeedEntry.AdSlot(ads++))
        }
    }
    return out
}

/** True when ads may use the current connection (always true if ADS_ONLY_ON_WIFI is off). */
private fun adsAllowedOnNetwork(ctx: Context): Boolean {
    return try {
        val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        if (!caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        if (AdsterraConfig.ADS_ONLY_ON_WIFI) !cm.isActiveNetworkMetered else true
    } catch (_: Exception) {
        false
    }
}

private val BLOCKED_MEDIA = listOf(
    ".mp4", ".webm", ".m3u8", ".mpd", ".mov", ".avi", ".mkv", ".flv", ".m4s", ".mp3", ".ogg", ".wav", ".m4a"
)

/** Hands out load times so ads start one by one instead of all together. */
private object AdScheduler {
    private val appStart = android.os.SystemClock.elapsedRealtime()
    private var nextFree = 0L

    @Synchronized
    fun reserveDelay(): Long {
        val now = android.os.SystemClock.elapsedRealtime()
        val start = maxOf(now, appStart + AdsterraConfig.AD_DELAY_MS, nextFree)
        nextFree = start + AdsterraConfig.AD_GAP_MS
        return start - now
    }
}

private val lifecycleObservers = WeakHashMap<WebView, LifecycleEventObserver>()

/** Called when an ad fails to load (offline, DNS, timeout) so its slot can collapse. */
private val failCallbacks = WeakHashMap<WebView, () -> Unit>()
private val failedViews = WeakHashMap<WebView, Boolean>()

private fun isNetworkFailure(code: Int) = code in listOf(
    WebViewClient.ERROR_HOST_LOOKUP, WebViewClient.ERROR_CONNECT,
    WebViewClient.ERROR_TIMEOUT, WebViewClient.ERROR_IO,
    WebViewClient.ERROR_UNKNOWN, WebViewClient.ERROR_FAILED_SSL_HANDSHAKE
)

private fun Context.findLifecycleOwner(): LifecycleOwner? {
    var c: Context? = this
    while (c != null) {
        if (c is LifecycleOwner) return c
        c = (c as? ContextWrapper)?.baseContext
    }
    return null
}

/** Stops every network request from this ad (the ad that is already drawn stays visible). */
private fun freezeAd(view: WebView) {
    view.tag = "frozen"
    view.settings.blockNetworkLoads = true
    view.stopLoading()
    // Kill the ad script's refresh timers.
    view.evaluateJavascript(
        "(function(){var i=setTimeout(function(){},0);while(i--){clearTimeout(i);clearInterval(i);}})();",
        null
    )
}

/** No ad traffic while the app is in the background (music playing etc.). */
private fun attachLifecycle(ctx: Context, view: WebView) {
    val owner = ctx.findLifecycleOwner() ?: return
    val observer = LifecycleEventObserver { _, event ->
        when (event) {
            Lifecycle.Event.ON_STOP -> view.settings.blockNetworkLoads = true
            Lifecycle.Event.ON_START -> if (view.tag != "frozen") view.settings.blockNetworkLoads = false
            else -> {}
        }
    }
    lifecycleObservers.put(view, observer)?.let { owner.lifecycle.removeObserver(it) }
    owner.lifecycle.addObserver(observer)
}

private fun detachLifecycle(ctx: Context, view: WebView) {
    val observer = lifecycleObservers.remove(view) ?: return
    ctx.findLifecycleOwner()?.lifecycle?.removeObserver(observer)
}

@SuppressLint("SetJavaScriptEnabled")
private fun createAdWebView(ctx: Context, html: String): WebView {
    return WebView(MutableContextWrapper(ctx)).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        setBackgroundColor(0)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.setSupportMultipleWindows(false)
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        // Reuse downloaded ad scripts/images from earlier launches instead of fetching again.
        settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        webViewClient = object : WebViewClient() {
            // Never show Chrome's "Webpage not available" page: hide the ad slot instead.
            override fun onReceivedError(
                view: WebView, request: WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (isNetworkFailure(error.errorCode)) {
                    failedViews[view] = true
                    view.stopLoading()
                    view.loadUrl("about:blank")
                    failCallbacks[view]?.invoke()
                }
            }

            // Never download video/audio streams inside an ad.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val path = request.url.path?.lowercase() ?: return null
                if (BLOCKED_MEDIA.any { path.endsWith(it) }) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            // Tap on the ad -> open it in the real browser; block automatic redirects.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                if (request.hasGesture()) {
                    try {
                        view.context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(request.url.toString()))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) { }
                }
                return true
            }
        }
        loadDataWithBaseURL(AdsterraConfig.BASE_URL, html, "text/html", "utf-8", null)
        postDelayed({ freezeAd(this) }, AdsterraConfig.FREEZE_AFTER_MS)
    }
}

/**
 * Keeps ad WebViews alive so scrolling an ad out of view and back does NOT download it
 * again. Views are detached (not destroyed) on release. Total loads are capped per session.
 */
private object AdWebViewPool {
    private val cache = LinkedHashMap<String, WebView>()
    private val loadedKeys = HashSet<String>()

    // Fixed ads (top of Folders, Settings, File Transfer) are always allowed and cached too,
    // so leaving and re-opening a screen never downloads them again.
    fun canShow(key: String): Boolean =
        key.startsWith("fixed_") || key in loadedKeys || loadedKeys.size < AdsterraConfig.MAX_FEED_LOADS

    /** True when this ad was already loaded earlier (shown instantly, no new download). */
    fun isCached(key: String): Boolean = key in cache

    fun obtain(ctx: Context, key: String, html: String): WebView {
        val view = cache.remove(key)?.also { cached ->
            (cached.context as? MutableContextWrapper)?.baseContext = ctx
            cached.onResume()
        } ?: createAdWebView(ctx, html).also { loadedKeys.add(key) }
        attachLifecycle(ctx, view)
        return view
    }

    fun release(key: String, view: WebView) {
        detachLifecycle(view.context, view)
        failCallbacks.remove(view)
        (view.parent as? ViewGroup)?.removeView(view)
        if (failedViews.remove(view) == true) {
            loadedKeys.remove(key)
            view.destroy()
            return
        }
        view.onPause()
        // Drop the Activity reference so a cached view can't leak it.
        (view.context as? MutableContextWrapper)?.baseContext = view.context.applicationContext
        cache[key] = view
        // Cache is big enough for every allowed ad, so nothing is evicted (= nothing re-downloaded).
        while (cache.size > AdsterraConfig.MAX_FEED_LOADS + 3) {
            val eldest = cache.keys.first()
            cache.remove(eldest)?.destroy()
        }
    }
}

/** In-feed ad shown between list items. Only composed when scrolled into view. */
@Composable
fun InFeedAd(slotKey: String, modifier: Modifier = Modifier, small: Boolean = false) {
    AdsterraBanner(
        format = if (small) AdsterraFormat.BANNER_320x50 else AdsterraFormat.RECT_300x250,
        scale = if (small) 1f else 0.8f,
        slotKey = slotKey,
        modifier = modifier.padding(vertical = 6.dp)
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdsterraBanner(
    format: AdsterraFormat,
    modifier: Modifier = Modifier,
    scale: Float = 1f,
    fillWidth: Boolean = true,
    slotKey: String? = null
) {
    if (!AdsterraConfig.ENABLED) return
    val appCtx = androidx.compose.ui.platform.LocalContext.current
    if (!remember(slotKey, format) { adsAllowedOnNetwork(appCtx) }) return
    if (slotKey != null && !remember(slotKey) { AdWebViewPool.canShow(slotKey) }) return

    // Slow pop-up: wait AD_DELAY_MS before the ad is created, unless it is already cached.
    var ready by androidx.compose.runtime.remember(slotKey, format) {
        androidx.compose.runtime.mutableStateOf(slotKey != null && AdWebViewPool.isCached(slotKey))
    }
    androidx.compose.runtime.LaunchedEffect(slotKey, format) {
        if (!ready) {
            kotlinx.coroutines.delay(AdScheduler.reserveDelay())
            ready = true
        }
    }
    if (!ready) return

    var failed by androidx.compose.runtime.remember(slotKey, format) {
        androidx.compose.runtime.mutableStateOf(false)
    }
    if (failed) return

    val html = remember(format) {
        """
        <!DOCTYPE html><html><head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>html,body{margin:0;padding:0;background:transparent;overflow:hidden;}
        body{display:flex;justify-content:center;align-items:flex-start;}</style>
        </head><body>
        <script>
          atOptions = {
            'key' : '${format.key}',
            'format' : 'iframe',
            'height' : ${format.h},
            'width' : ${format.w},
            'params' : {}
          };
        </script>
        <script src="https://www.highrevenueformat.com/${format.key}/invoke.js"></script>
        </body></html>
        """.trimIndent()
    }

    // Fade in slowly instead of popping in.
    var visible by androidx.compose.runtime.remember(slotKey, format) {
        androidx.compose.runtime.mutableStateOf(false)
    }
    androidx.compose.runtime.LaunchedEffect(slotKey, format) { visible = true }
    val fade by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(1200),
        label = "adFade"
    )

    Box(
        modifier = modifier
            .then(if (fillWidth) Modifier.fillMaxWidth() else Modifier)
            .graphicsLayer { alpha = fade },
        contentAlignment = Alignment.Center
    ) {
        // Outer box has the (scaled) size the layout sees; the WebView keeps the real
        // ad size and is scaled down visually so the ad itself is not cropped.
        Box(
            modifier = Modifier
                .width((format.w * scale).dp)
                .height((format.h * scale).dp),
            contentAlignment = Alignment.Center
        ) {
        AndroidView(
            modifier = Modifier
                .requiredSize(format.w.dp, format.h.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
            factory = { ctx ->
                val v = if (slotKey != null) {
                    AdWebViewPool.obtain(ctx, slotKey, html)
                } else {
                    createAdWebView(ctx, html).also { attachLifecycle(ctx, it) }
                }
                failCallbacks[v] = { failed = true }
                v
            },
            onRelease = {
                if (slotKey != null) AdWebViewPool.release(slotKey, it)
                else { detachLifecycle(it.context, it); failCallbacks.remove(it); it.destroy() }
            }
        )
        }
    }
}
