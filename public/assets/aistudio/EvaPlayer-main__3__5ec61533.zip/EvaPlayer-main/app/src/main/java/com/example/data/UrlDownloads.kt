package com.example.data

import android.app.DownloadManager
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * Downloads for the URL player only. Uses Android's DownloadManager (background, notification,
 * resumable) and exposes live progress so the UI can show it.
 */
object UrlDownloads {

    data class Item(
        val id: Long,
        val url: String,
        val name: String,
        val path: String,
        val progress: Float = 0f,
        val status: Int = DownloadManager.STATUS_PENDING,
        val downloadedBytes: Long = 0L,
        val totalBytes: Long = -1L
    ) {
        val isActive: Boolean
            get() = status == DownloadManager.STATUS_PENDING ||
                status == DownloadManager.STATUS_RUNNING ||
                status == DownloadManager.STATUS_PAUSED
        val isDone: Boolean get() = status == DownloadManager.STATUS_SUCCESSFUL
        val isFailed: Boolean get() = status == DownloadManager.STATUS_FAILED
    }

    private val _items = MutableStateFlow<List<Item>>(emptyList())
    val items: StateFlow<List<Item>> = _items

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollJob: Job? = null

    /** Returns an error message, or null when the download was queued. */
    fun start(context: Context, rawUrl: String, rawTitle: String): String? {
        val app = context.applicationContext
        val url = rawUrl.trim()
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            return "Enter a valid http/https link to download"
        }
        if (url.contains(".m3u8", ignoreCase = true)) return "Live / HLS streams can't be downloaded"
        if (_items.value.any { it.url == url && it.isActive }) return "This video is already downloading"

        var name = rawTitle.substringBefore('?').replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        if (name.isBlank()) name = "video_${System.currentTimeMillis()}"
        if (!name.substringAfterLast('.', "").let { it.length in 2..4 }) name += ".mp4"

        return try {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "EvaPlayer/Downloads"
            )
            dir.mkdirs()
            val dest = File(dir, name)
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setDescription("EvaPlayer download")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setDestinationUri(Uri.fromFile(dest))
            val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = dm.enqueue(request)
            _items.value = listOf(Item(id = id, url = url, name = name, path = dest.absolutePath)) +
                _items.value.filter { it.id != id }
            ensurePolling(app, dm)
            null
        } catch (e: Exception) {
            "Could not start download"
        }
    }

    fun cancel(context: Context, id: Long) {
        try {
            (context.applicationContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)
        } catch (_: Exception) { }
        _items.value = _items.value.filter { it.id != id }
    }

    fun clearFinished() {
        _items.value = _items.value.filter { it.isActive }
    }

    private fun ensurePolling(app: Context, dm: DownloadManager) {
        if (pollJob?.isActive == true) return
        pollJob = scope.launch {
            while (_items.value.any { it.isActive }) {
                refresh(app, dm)
                delay(700)
            }
            refresh(app, dm)
        }
    }

    private fun refresh(app: Context, dm: DownloadManager) {
        val current = _items.value
        if (current.isEmpty()) return
        val updated = current.toMutableList()
        val query = DownloadManager.Query().setFilterById(*current.map { it.id }.toLongArray())
        try {
            dm.query(query)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                val stCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val doneCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val totCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val idx = updated.indexOfFirst { it.id == id }
                    if (idx == -1) continue
                    val old = updated[idx]
                    val status = c.getInt(stCol)
                    val done = c.getLong(doneCol)
                    val total = c.getLong(totCol)
                    val prog = when {
                        status == DownloadManager.STATUS_SUCCESSFUL -> 1f
                        total > 0 -> (done.toFloat() / total).coerceIn(0f, 1f)
                        else -> 0f
                    }
                    if (status == DownloadManager.STATUS_SUCCESSFUL && !old.isDone) {
                        MediaScannerConnection.scanFile(app, arrayOf(old.path), null, null)
                    }
                    updated[idx] = old.copy(status = status, downloadedBytes = done, totalBytes = total, progress = prog)
                }
            }
        } catch (_: Exception) { }
        _items.value = updated
    }
}
