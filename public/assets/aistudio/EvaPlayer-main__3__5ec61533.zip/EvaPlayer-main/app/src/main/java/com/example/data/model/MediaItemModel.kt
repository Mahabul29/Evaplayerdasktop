package com.example.data.model

data class VideoItem(
    val id: String,
    val title: String,
    val path: String,
    val uriString: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateModified: Long,
    val folderName: String,
    val folderPath: String,
    val resolution: String = "1080p",
    val format: String = "MP4",
    val lastPositionMs: Long = 0L,
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val isStream: Boolean = false
) {
    val durationFormatted: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) {
                String.format("%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }

    val timeLeftFormatted: String
        get() {
            val leftMs = (durationMs - lastPositionMs).coerceAtLeast(0)
            val totalSeconds = leftMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format("%d min left", (minutes + 1).coerceAtLeast(1))
        }

    val sizeFormatted: String
        get() {
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }

    val progressFraction: Float
        get() {
            if (durationMs <= 0) return 0f
            return (lastPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        }
}

data class FolderItem(
    val path: String,
    val name: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val isHidden: Boolean = false,
    val isReceived: Boolean = false,
    val receivedCount: Int = 0,
    val latestModified: Long = 0L,
    val totalDurationMs: Long = 0L
) {
    val sizeFormatted: String
        get() {
            val kb = totalSizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }
}

data class AudioItem(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val uriString: String,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val isFavorite: Boolean = false
) {
    val durationFormatted: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format("%02d:%02d", minutes, seconds)
        }
}

data class BrowserFileItem(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val dateModified: Long,
    val mimeType: String? = null,
    val isVideo: Boolean = false,
    val isAudio: Boolean = false,
    val isSubtitle: Boolean = false,
    val isHidden: Boolean = false
) {
    val sizeFormatted: String
        get() {
            if (isDirectory) return ""
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }
}

data class PlaylistInfo(
    val id: Long,
    val name: String,
    val videoCount: Int,
    val createdTimestamp: Long
)

data class StreamItem(
    val url: String,
    val title: String,
    val lastPositionMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val isSaved: Boolean = false
)

data class SubtitleTrackInfo(
    val id: String,
    val language: String,
    val label: String,
    val uriString: String? = null
)
