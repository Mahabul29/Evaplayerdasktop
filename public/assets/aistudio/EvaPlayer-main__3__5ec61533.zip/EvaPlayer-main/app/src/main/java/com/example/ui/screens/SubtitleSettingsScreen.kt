package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EvaTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun SubtitleSettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        EvaTopBar(
            title = "Subtitles",
            canNavigateBack = true,
            onNavigateBack = { viewModel.navigateBack() },
            showSearchAndSort = false
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Live Preview Box
            item {
                Text("LIVE PREVIEW", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF18221E))
                        .padding(16.dp)
                ) {
                    val subColor = try { Color(android.graphics.Color.parseColor(settings.subTextColorHex)) } catch (e: Exception) { Color.White }
                    val subBg = try { Color(android.graphics.Color.parseColor(settings.subBgColorHex)) } catch (e: Exception) { Color.Black.copy(alpha = 0.6f) }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(subBg)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "EvaPlayer • Sample Subtitle Track",
                            color = subColor,
                            fontSize = settings.subTextSizeSp.sp,
                            fontWeight = if (settings.subBold) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // Text Size Slider
            item {
                Text("TEXT SIZE (${settings.subTextSizeSp}sp)", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Slider(
                    value = settings.subTextSizeSp.toFloat(),
                    onValueChange = { size ->
                        coroutineScope.launch {
                            viewModel.settingsRepo.updateSubtitleSettings(
                                lang = settings.defaultSubtitleLanguage,
                                textSizeSp = size.toInt(),
                                textColorHex = settings.subTextColorHex,
                                bgColorHex = settings.subBgColorHex,
                                bold = settings.subBold,
                                edgeStyle = settings.subEdgeStyle,
                                position = settings.subPosition,
                                delayMs = settings.subDelayMs,
                                autoLoad = settings.subAutoLoadFromFolder,
                                encoding = settings.subEncoding
                            )
                        }
                    },
                    valueRange = 12f..32f,
                    steps = 19,
                    colors = SliderDefaults.colors(thumbColor = GreenAccent, activeTrackColor = GreenAccent)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Text Color Options
            item {
                Text("TEXT COLOR", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    val colors = listOf("#FFFFFF", "#FFFF00", "#00E676", "#448AFF")
                    colors.forEach { hex ->
                        val parsed = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = settings.subTextColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(parsed)
                                .border(width = if (isSelected) 3.dp else 1.dp, color = if (isSelected) GreenAccent else Color.Gray, shape = CircleShape)
                                .clickable {
                                    coroutineScope.launch {
                                        viewModel.settingsRepo.updateSubtitleSettings(
                                            lang = settings.defaultSubtitleLanguage,
                                            textSizeSp = settings.subTextSizeSp,
                                            textColorHex = hex,
                                            bgColorHex = settings.subBgColorHex,
                                            bold = settings.subBold,
                                            edgeStyle = settings.subEdgeStyle,
                                            position = settings.subPosition,
                                            delayMs = settings.subDelayMs,
                                            autoLoad = settings.subAutoLoadFromFolder,
                                            encoding = settings.subEncoding
                                        )
                                    }
                                }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // Bold Toggle
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Bold Text", color = TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Switch(
                            checked = settings.subBold,
                            onCheckedChange = { bold ->
                                coroutineScope.launch {
                                    viewModel.settingsRepo.updateSubtitleSettings(
                                        lang = settings.defaultSubtitleLanguage,
                                        textSizeSp = settings.subTextSizeSp,
                                        textColorHex = settings.subTextColorHex,
                                        bgColorHex = settings.subBgColorHex,
                                        bold = bold,
                                        edgeStyle = settings.subEdgeStyle,
                                        position = settings.subPosition,
                                        delayMs = settings.subDelayMs,
                                        autoLoad = settings.subAutoLoadFromFolder,
                                        encoding = settings.subEncoding
                                    )
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = GreenAccent)
                        )
                    }
                }
            }

            // Auto-load from folder
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-load Subtitles", color = TextPrimary, fontSize = 15.sp)
                            Text("Automatically load .srt / .vtt from same directory", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = settings.subAutoLoadFromFolder,
                            onCheckedChange = { autoLoad ->
                                coroutineScope.launch {
                                    viewModel.settingsRepo.updateSubtitleSettings(
                                        lang = settings.defaultSubtitleLanguage,
                                        textSizeSp = settings.subTextSizeSp,
                                        textColorHex = settings.subTextColorHex,
                                        bgColorHex = settings.subBgColorHex,
                                        bold = settings.subBold,
                                        edgeStyle = settings.subEdgeStyle,
                                        position = settings.subPosition,
                                        delayMs = settings.subDelayMs,
                                        autoLoad = autoLoad,
                                        encoding = settings.subEncoding
                                    )
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = GreenAccent)
                        )
                    }
                }
            }
        }
    }
}
