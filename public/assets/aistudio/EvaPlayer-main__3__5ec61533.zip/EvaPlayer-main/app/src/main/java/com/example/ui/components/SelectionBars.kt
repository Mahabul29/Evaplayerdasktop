package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.viewmodel.ScreenRoute
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.VideoItem
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import java.io.File

/** Replaces the normal top bar while videos are selected. */
@Composable
fun SelectionTopBar(
    selectedCount: Int,
    totalCount: Int,
    onClose: () -> Unit,
    onSelectAll: () -> Unit
) {
    Surface(
        color = DarkSurface,
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .statusBarsPadding()
            .height(56.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Cancel selection", tint = TextPrimary)
            }
            Text(
                text = "$selectedCount selected",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onSelectAll) {
                Icon(
                    Icons.Default.SelectAll,
                    contentDescription = "Select all",
                    tint = if (selectedCount == totalCount && totalCount > 0) GreenAccent else TextPrimary
                )
            }
        }
    }
}

/**
 * MX-style selection bar: "1 / 9 Selected", Play, Info (single item) and a 3-dot menu.
 * [videos] is the list currently visible on screen (used for "Select all").
 */
@Composable
fun VideoSelectionTopBar(
    viewModel: MainViewModel,
    videos: List<VideoItem>
) {
    val context = LocalContext.current
    val selectedUris by viewModel.selectedUris.collectAsState()
    val selected = remember(selectedUris, videos) { videos.filter { it.uriString in selectedUris } }
    var menuOpen by remember { mutableStateOf(false) }

    Surface(
        color = DarkSurface,
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .statusBarsPadding()
            .height(56.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.clearSelection() }) {
                Icon(Icons.Default.Close, contentDescription = "Cancel selection", tint = TextPrimary)
            }
            Text(
                text = "${selectedUris.size} / ${videos.size} Selected",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = {
                    val list = selected
                    if (list.isNotEmpty()) {
                        viewModel.navigateTo(ScreenRoute.Player(video = list.first(), playlist = list, startIndex = 0))
                    }
                }
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = TextPrimary)
            }
            if (selected.size == 1) {
                IconButton(onClick = { viewModel.openInfoSheet(selected.first()) }) {
                    Icon(Icons.Default.Info, contentDescription = "Info", tint = TextPrimary)
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
                }
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    modifier = Modifier.background(DarkSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text(if (selectedUris.size == videos.size) "Deselect all" else "Select all", color = TextPrimary) },
                        onClick = { menuOpen = false; viewModel.selectAll(videos) }
                    )
                    DropdownMenuItem(
                        text = { Text("Share", color = TextPrimary) },
                        onClick = { menuOpen = false; shareVideos(context, selected) }
                    )
                    if (selected.size == 1) {
                        DropdownMenuItem(
                            text = { Text("Rename", color = TextPrimary) },
                            onClick = {
                                menuOpen = false
                                val v = selected.first()
                                viewModel.clearSelection()
                                viewModel.requestRenameVideo(v)
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Delete", color = Color(0xFFFF5252)) },
                        onClick = { menuOpen = false; viewModel.requestBulkDelete() }
                    )
                }
            }
        }
    }
}

/** Share / Delete bar shown at the bottom while videos are selected. */
@Composable
fun SelectionBottomBar(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier,
    visibleVideos: List<VideoItem> = emptyList()
) {
    val context = LocalContext.current
    val selectedUris by viewModel.selectedUris.collectAsState()
    Surface(
        color = DarkSurface,
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .navigationBarsPadding()
            .height(64.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (visibleVideos.isNotEmpty()) {
                SelectionAction(Icons.Default.SelectAll, "Select all", TextPrimary, Modifier.weight(1f)) {
                    viewModel.selectAll(visibleVideos)
                }
            }
            SelectionAction(Icons.Default.Share, "Share", TextPrimary, Modifier.weight(1f)) {
                shareVideos(context, viewModel.selectedVideos())
            }
            if (selectedUris.size == 1) {
                SelectionAction(Icons.Default.Edit, "Rename", TextPrimary, Modifier.weight(1f)) {
                    viewModel.selectedVideos().firstOrNull()?.let {
                        viewModel.clearSelection()
                        viewModel.requestRenameVideo(it)
                    }
                }
            }
            SelectionAction(Icons.Default.Delete, "Delete", Color(0xFFFF5252), Modifier.weight(1f)) {
                viewModel.requestBulkDelete()
            }
        }
    }
}

@Composable
private fun SelectionAction(
    icon: ImageVector,
    label: String,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clickable { onClick() }
            .padding(vertical = 8.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
        Text(text = label, color = tint, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BulkDeleteConfirmDialog(
    count: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                if (count == 1) "Delete 1 video?" else "Delete $count videos?",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                "The selected videos will be permanently deleted. This cannot be undone.",
                color = TextSecondary,
                fontSize = 14.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
            ) {
                Text("Delete", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}

/** Shares several videos at once (stream links are sent as text). */
fun shareVideos(context: Context, videos: List<VideoItem>) {
    if (videos.isEmpty()) return
    if (videos.size == 1) {
        shareVideoFile(context, videos.first())
        return
    }
    try {
        val local = videos.filter { !it.path.startsWith("http") }
        val streams = videos.filter { it.path.startsWith("http") }
        val uris = ArrayList<android.net.Uri>()
        for (v in local) {
            val file = File(v.path)
            val uri = if (file.exists()) {
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            } else {
                android.net.Uri.parse(v.uriString)
            }
            uris.add(uri)
        }
        val intent = if (uris.isNotEmpty()) {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "video/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                if (streams.isNotEmpty()) {
                    putExtra(Intent.EXTRA_TEXT, streams.joinToString("\n") { "${it.title}: ${it.uriString}" })
                }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, streams.joinToString("\n") { "${it.title}: ${it.uriString}" })
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share ${videos.size} videos"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
