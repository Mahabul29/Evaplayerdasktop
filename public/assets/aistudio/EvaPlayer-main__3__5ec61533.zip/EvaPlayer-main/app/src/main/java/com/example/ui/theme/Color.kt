package com.example.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * Live accent colour. EvaPlayerTheme updates it whenever the user picks a new accent in Settings.
 * Because it is Compose snapshot state, every composable that reads [GreenAccent] recomposes
 * automatically, so the old hard-coded blue is replaced everywhere without touching call sites.
 */
object AccentState {
    var color: Color by mutableStateOf(Color(0xFF2F80FF))
    var colorDark: Color by mutableStateOf(Color(0xFF1B5FD1))
}

// Default EvaPlayer Theme Colors
/** Name kept for compatibility; this now returns the accent the user chose (see [AccentState]). */
val GreenAccent: Color get() = AccentState.color
val GreenAccentDark: Color get() = AccentState.colorDark
/**
 * Live theme mode ("Dark", "Light", "AMOLED"). EvaPlayerTheme updates it; because it is Compose
 * snapshot state, every composable reading the colours below recomposes when the theme changes,
 * so no call site needs to change. (Names keep the old "Dark…" prefix for compatibility.)
 */
object ThemeState {
    var mode: String by mutableStateOf("Dark")
    val isLight: Boolean get() = mode.equals("Light", ignoreCase = true)
    val isAmoled: Boolean get() = mode.equals("AMOLED", ignoreCase = true)
}

private fun themed(dark: Long, amoled: Long, light: Long): Color = Color(
    when {
        ThemeState.isLight -> light
        ThemeState.isAmoled -> amoled
        else -> dark
    }
)

// Backgrounds / surfaces
val DarkBackground: Color get() = themed(0xFF0F1117, 0xFF000000, 0xFFF4F6FA)
val DarkSurface: Color get() = themed(0xFF161922, 0xFF0B0C10, 0xFFFFFFFF)
val DarkSurfaceContainer: Color get() = themed(0xFF1E222D, 0xFF15171C, 0xFFE8ECF3)
val DarkSurfaceElevated: Color get() = themed(0xFF282D3A, 0xFF1E2026, 0xFFDDE2EB)
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF0B0C10)

// Text Colors
val TextPrimary: Color get() = themed(0xFFFFFFFF, 0xFFFFFFFF, 0xFF14171F)
val TextSecondary: Color get() = themed(0xFF9BA3B4, 0xFF9BA3B4, 0xFF566074)
val TextTertiary: Color get() = themed(0xFF757575, 0xFF757575, 0xFF8A91A0)

// Divider / Border
val DividerDark: Color get() = themed(0xFF2B3040, 0xFF24272F, 0xFFD3D9E4)
val ProgressTrackDark: Color get() = themed(0xFF343B4D, 0xFF2A2E38, 0xFFCDD3DF)

// Accent Palette Options for Settings
val AccentWhite = Color(0xFFFFFFFF)
val AccentGreen = Color(0xFF00E676)
val AccentPurple = Color(0xFFB388FF)
val AccentBlue = Color(0xFF2F80FF)
val AccentRed = Color(0xFFFF5252)
val AccentOrange = Color(0xFFFF9100)
val AccentPink = Color(0xFFFF4081)

fun getAccentColor(name: String): Color {
    return when (name.lowercase()) {
        "white" -> AccentWhite
        "green" -> AccentGreen
        "purple" -> AccentPurple
        "blue" -> AccentBlue
        "red" -> AccentRed
        "orange" -> AccentOrange
        "pink" -> AccentPink
        else -> AccentBlue
    }
}

