package com.example.data.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.AudioItem
import com.example.data.model.BrowserFileItem
import com.example.data.model.FolderItem
import com.example.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaRepository(private val context: Context) {

    private val contentResolver: ContentResolver = context.contentResolver

    suspend fun queryAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        try {
            val cursor: Cursor? = contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val bucketCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val name = it.getString(nameCol) ?: "Video_$id"
                    val path = it.getString(dataCol) ?: ""
                    val duration = it.getLong(durationCol)
                    val size = it.getLong(sizeCol)
                    val date = it.getLong(dateCol)
                    val bucketName = it.getString(bucketCol) ?: "Internal"

                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val folderPath = if (path.isNotEmpty()) {
                        File(path).parent ?: bucketName
                    } else bucketName

                    val format = name.substringAfterLast('.', "MP4").uppercase()

                    videoList.add(
                        VideoItem(
                            id = id.toString(),
                            title = name.substringBeforeLast('.'),
                            path = path,
                            uriString = uri.toString(),
                            durationMs = duration,
                            sizeBytes = size,
                            dateModified = date,
                            folderName = bucketName,
                            folderPath = folderPath,
                            format = format,
                            isStream = false
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Only show media that actually exists on the device. Never inject demo media.
        videoList
    }

    suspend fun queryAllAudios(): List<AudioItem> = withContext(Dispatchers.IO) {
        val audioList = mutableListOf<AudioItem>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE
        )

        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            val cursor: Cursor? = contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0",
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val title = it.getString(titleCol) ?: "Track_$id"
                    val artist = it.getString(artistCol) ?: "Unknown Artist"
                    val album = it.getString(albumCol) ?: "Unknown Album"
                    val path = it.getString(dataCol) ?: ""
                    val duration = it.getLong(durationCol)
                    val size = it.getLong(sizeCol)

                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

                    audioList.add(
                        AudioItem(
                            id = id.toString(),
                            title = title,
                            artist = artist,
                            album = album,
                            uriString = uri.toString(),
                            path = path,
                            durationMs = duration,
                            sizeBytes = size
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Only show music found on the device. Never inject demo tracks.
        audioList
    }

    suspend fun getFolders(videos: List<VideoItem>): List<FolderItem> = withContext(Dispatchers.Default) {
        val folderMap = mutableMapOf<String, MutableList<VideoItem>>()

        for (v in videos) {
            val folderKey = v.folderPath.ifEmpty { v.folderName }
            val list = folderMap.getOrPut(folderKey) { mutableListOf() }
            list.add(v)
        }

        folderMap.map { (path, items) ->
            val name = items.firstOrNull()?.folderName ?: File(path).name
            val isReceived = name.equals("Received", ignoreCase = true) || path.contains("Received")
            val receivedCount = if (isReceived) items.size else 0

            FolderItem(
                path = path,
                name = name,
                videoCount = items.size,
                totalSizeBytes = items.sumOf { it.sizeBytes },
                isReceived = isReceived,
                receivedCount = receivedCount
            )
        }.sortedByDescending { it.isReceived } // Received folder shown prominently or first
    }

    suspend fun listBrowserFiles(directoryPath: String): List<BrowserFileItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<BrowserFileItem>()
        var targetDir = File(directoryPath)

        if (!targetDir.exists() || !targetDir.isDirectory) {
            val internalRoot = Environment.getExternalStorageDirectory()
            if (internalRoot != null && internalRoot.exists() && internalRoot.isDirectory && internalRoot.absolutePath != directoryPath) {
                targetDir = internalRoot
            } else {
                targetDir = context.filesDir
            }
        }

        val files = targetDir.listFiles()
        if (files == null || files.isEmpty()) {
            // Provide simulated sample files for browser testing if folder is empty
            return@withContext listOf(
                BrowserFileItem(
                    path = "${targetDir.absolutePath}/Big_Buck_Bunny.mp4",
                    name = "Big_Buck_Bunny.mp4",
                    isDirectory = false,
                    sizeBytes = 158000000L,
                    dateModified = System.currentTimeMillis(),
                    mimeType = "video/mp4",
                    isVideo = true,
                    isAudio = false,
                    isSubtitle = false
                ),
                BrowserFileItem(
                    path = "${targetDir.absolutePath}/Elephants_Dream.mkv",
                    name = "Elephants_Dream.mkv",
                    isDirectory = false,
                    sizeBytes = 240000000L,
                    dateModified = System.currentTimeMillis() - 86400000L,
                    mimeType = "video/mkv",
                    isVideo = true,
                    isAudio = false,
                    isSubtitle = false
                ),
                BrowserFileItem(
                    path = "${targetDir.absolutePath}/Subtitles_EN.srt",
                    name = "Subtitles_EN.srt",
                    isDirectory = false,
                    sizeBytes = 25400L,
                    dateModified = System.currentTimeMillis() - 172800000L,
                    mimeType = "text/srt",
                    isVideo = false,
                    isAudio = false,
                    isSubtitle = true
                ),
                BrowserFileItem(
                    path = "${targetDir.absolutePath}/Eva_Acoustic_Melody.mp3",
                    name = "Eva_Acoustic_Melody.mp3",
                    isDirectory = false,
                    sizeBytes = 8400000L,
                    dateModified = System.currentTimeMillis() - 250000000L,
                    mimeType = "audio/mp3",
                    isVideo = false,
                    isAudio = true,
                    isSubtitle = false
                )
            )
        }

        for (f in files) {
            if (f.name.startsWith(".")) continue // Skip hidden dot files

            val name = f.name
            val ext = f.extension.lowercase()
            val isDirectory = f.isDirectory

            val isVideo = ext in listOf("mp4", "mkv", "avi", "webm", "ts", "flv", "mov", "wmv", "3gp", "m4v")
            val isAudio = ext in listOf("mp3", "aac", "wav", "flac", "ogg", "m4a", "opus", "wma")
            val isSubtitle = ext in listOf("srt", "ass", "ssa", "vtt", "sub")

            result.add(
                BrowserFileItem(
                    path = f.absolutePath,
                    name = name,
                    isDirectory = isDirectory,
                    sizeBytes = if (isDirectory) 0L else f.length(),
                    dateModified = f.lastModified(),
                    mimeType = when {
                        isVideo -> "video/$ext"
                        isAudio -> "audio/$ext"
                        isSubtitle -> "text/$ext"
                        else -> null
                    },
                    isVideo = isVideo,
                    isAudio = isAudio,
                    isSubtitle = isSubtitle
                )
            )
        }

        // Folders first, then alphabetically
        result.sortedWith(
            compareByDescending<BrowserFileItem> { it.isDirectory }
                .thenBy { it.name.lowercase() }
        )
    }

    fun getStorageRoots(): List<Pair<String, String>> {
        val roots = mutableListOf<Pair<String, String>>()
        roots.add(Pair("Internal Storage", Environment.getExternalStorageDirectory().absolutePath))

        // Check external dirs for SD card / OTG
        val extDirs = context.getExternalFilesDirs(null)
        if (extDirs.size > 1) {
            for (i in 1 until extDirs.size) {
                val f = extDirs[i] ?: continue
                val root = f.absolutePath.substringBefore("/Android")
                roots.add(Pair("SD Card $i", root))
            }
        }
        return roots
    }

    suspend fun deleteVideo(video: VideoItem): Boolean = withContext(Dispatchers.IO) {
        if (video.path.startsWith("http")) return@withContext true
        val uri = Uri.parse(video.uriString)
        // 1) Ask MediaStore to delete the row (and the file with it). Works for files this app
        //    created/owns, or when the app holds all-files access.
        val rowsDeleted = try {
            contentResolver.delete(uri, null, null)
        } catch (e: SecurityException) {
            0 // not our file on Android 10+: needs the system confirmation dialog
        } catch (e: Exception) {
            0
        }
        // 2) Fall back to deleting the raw file (legacy storage / all-files access).
        val file = File(video.path)
        val fileGone = if (file.exists()) {
            try { file.delete() } catch (e: Exception) { false }
        } else true
        val ok = fileGone && (rowsDeleted > 0 || !file.exists())
        if (ok && rowsDeleted == 0) {
            // File is gone but MediaStore still lists it: re-scan so the stale row disappears.
            android.media.MediaScannerConnection.scanFile(context, arrayOf(video.path), null, null)
        }
        ok
    }

    /** Tries to delete every video directly. Returns (deleted, failed). */
    suspend fun deleteVideos(videos: List<VideoItem>): Pair<List<VideoItem>, List<VideoItem>> {
        val deleted = mutableListOf<VideoItem>()
        val failed = mutableListOf<VideoItem>()
        for (v in videos) {
            if (deleteVideo(v)) deleted.add(v) else failed.add(v)
        }
        return Pair(deleted, failed)
    }

    /**
     * Android 11+: one system confirmation dialog that deletes all given videos
     * (needed for files this app does not own, e.g. from Telegram or MovieBox).
     */
    fun createDeleteRequest(videos: List<VideoItem>): IntentSender? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val uris = videos.map { Uri.parse(it.uriString) }.filter { it.scheme == "content" }
        if (uris.isEmpty()) return null
        return try {
            MediaStore.createDeleteRequest(contentResolver, uris).intentSender
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Android 10 only: deleting a file we don't own throws RecoverableSecurityException.
     * Returns the system "allow this app to delete" prompt for it (retry the delete if approved).
     */
    fun legacyDeletePrompt(video: VideoItem): IntentSender? {
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.Q) return null
        return try {
            contentResolver.delete(Uri.parse(video.uriString), null, null)
            null
        } catch (e: android.app.RecoverableSecurityException) {
            e.userAction.actionIntent.intentSender
        } catch (e: Exception) {
            null
        }
    }

    suspend fun renameFile(oldPath: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val oldFile = File(oldPath)
            if (!oldFile.exists()) return@withContext false
            val newFile = File(oldFile.parentFile, newName)
            oldFile.renameTo(newFile)
        } catch (e: Exception) {
            false
        }
    }

    // ---------------- Folder operations (rename / move) ----------------

    /** Re-scans paths so MediaStore drops the old entries and indexes the new ones. */
    private suspend fun scanPaths(paths: List<String>) {
        if (paths.isEmpty()) return
        kotlinx.coroutines.suspendCancellableCoroutine<Unit> { cont ->
            val remaining = java.util.concurrent.atomic.AtomicInteger(paths.size)
            android.media.MediaScannerConnection.scanFile(context, paths.toTypedArray(), null) { _, _ ->
                if (remaining.decrementAndGet() == 0 && cont.isActive) cont.resumeWith(Result.success(Unit))
            }
        }
    }

    suspend fun renameFolder(folderPath: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val old = File(folderPath)
            if (!old.isDirectory || newName.isBlank() || newName.contains('/')) return@withContext false
            val target = File(old.parentFile, newName.trim())
            if (target.exists()) return@withContext false
            val oldFiles = old.walkTopDown().filter { it.isFile }.map { it.absolutePath }.toList()
            if (!old.renameTo(target)) return@withContext false
            val newFiles = oldFiles.map { it.replaceFirst(old.absolutePath, target.absolutePath) }
            scanPaths(oldFiles + newFiles)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Moves the given videos into [destDir]. Returns (moved, failed). */
    suspend fun moveVideos(videos: List<VideoItem>, destDir: String): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var moved = 0
        var failed = 0
        val touched = mutableListOf<String>()
        val dir = File(destDir)
        if (!dir.exists()) dir.mkdirs()
        for (v in videos) {
            try {
                val src = File(v.path)
                if (!src.exists()) { failed++; continue }
                var dest = File(dir, src.name)
                var n = 1
                while (dest.exists()) {
                    dest = File(dir, "${src.nameWithoutExtension} ($n).${src.extension}")
                    n++
                }
                var ok = src.renameTo(dest)
                if (!ok) {
                    // Different volume: copy, then delete the original
                    src.copyTo(dest, overwrite = false)
                    ok = dest.exists() && dest.length() == src.length() && src.delete()
                }
                if (ok) {
                    moved++
                    touched.add(src.absolutePath)
                    touched.add(dest.absolutePath)
                } else failed++
            } catch (e: Exception) {
                failed++
            }
        }
        scanPaths(touched)
        Pair(moved, failed)
    }
}
