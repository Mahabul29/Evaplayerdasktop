package com.example.data.transfer

import android.webkit.MimeTypeMap
import com.example.data.model.AudioItem
import com.example.data.model.VideoItem

enum class ShareKind { VIDEO, AUDIO, FILE }

/** Anything that can be sent: a library video/audio or any file picked from storage. */
data class ShareItem(
    val key: String,
    /** Display name including extension, e.g. "movie.mkv". */
    val name: String,
    val sizeBytes: Long,
    /** content:// uri (MediaStore or document picker). */
    val uriString: String,
    /** Real file path when known, empty for picked documents. */
    val path: String,
    val mime: String,
    val kind: ShareKind
) {
    val extension: String get() = name.substringAfterLast('.', "")
    val baseName: String get() = if (extension.isEmpty()) name else name.removeSuffix(".$extension")

    val sizeFormatted: String
        get() {
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }
}

fun mimeFor(name: String, fallback: String = "application/octet-stream"): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: fallback
}

fun VideoItem.toShareItem(): ShareItem {
    val ext = path.substringAfterLast('.', format.lowercase())
    val fullName = if (ext.isEmpty()) title else "$title.$ext"
    return ShareItem("v:$id", fullName, sizeBytes, uriString, path, mimeFor(fullName, "video/*"), ShareKind.VIDEO)
}

fun AudioItem.toShareItem(): ShareItem {
    val ext = path.substringAfterLast('.', "mp3")
    val fullName = "$title.$ext"
    return ShareItem("a:$id", fullName, sizeBytes, uriString, path, mimeFor(fullName, "audio/*"), ShareKind.AUDIO)
}
