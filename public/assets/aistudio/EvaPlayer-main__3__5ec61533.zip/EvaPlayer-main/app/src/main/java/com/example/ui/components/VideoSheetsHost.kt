package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute

/**
 * Hosts the three-dot action sheet, info sheet and dialogs once for the whole app,
 * so the menu opens instantly from every screen (Folders, Videos, Favorites, Browser...).
 */
@Composable
fun VideoSheetsHost(viewModel: MainViewModel) {
    val context = LocalContext.current
    val actionSheetVideo by viewModel.actionSheetVideo.collectAsState()
    val infoSheetVideo by viewModel.infoSheetVideo.collectAsState()
    val deleteConfirmVideo by viewModel.showDeleteConfirmDialog.collectAsState()
    val renameVideo by viewModel.showRenameDialog.collectAsState()
    val addToPlaylistVideo by viewModel.showPlaylistAddDialog.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val showBulkDelete by viewModel.showBulkDeleteDialog.collectAsState()
    val selectedUris by viewModel.selectedUris.collectAsState()
    val deleteSender by viewModel.deleteRequestSender.collectAsState()

    // System confirmation for deleting many videos at once (Android 11+)
    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        viewModel.onDeleteRequestResult(result.resultCode == Activity.RESULT_OK)
    }
    LaunchedEffect(deleteSender) {
        deleteSender?.let { deleteLauncher.launch(IntentSenderRequest.Builder(it).build()) }
    }

    // ---- Folder 3-dot menu (Move / Delete / Share / Rename) ----
    val folderSheet by viewModel.folderSheet.collectAsState()
    val folderRename by viewModel.folderRenameTarget.collectAsState()
    val folderMove by viewModel.folderMoveTarget.collectAsState()
    val allFolders by viewModel.displayedFolders.collectAsState()

    folderSheet?.let { folder ->
        FolderActionBottomSheet(
            folder = folder,
            onDismiss = { viewModel.closeFolderSheet() },
            onMove = { viewModel.requestFolderMove(folder) },
            onDelete = { viewModel.requestFolderDelete(folder) },
            onShare = {
                viewModel.closeFolderSheet()
                shareVideos(context, viewModel.videosInFolder(folder))
            },
            onRename = { viewModel.requestFolderRename(folder) },
            onHide = { viewModel.hideFolderFromSheet(folder) }
        )
    }
    folderRename?.let { folder ->
        FolderRenameDialog(
            folder = folder,
            onConfirm = { viewModel.confirmFolderRename(folder, it) },
            onDismiss = { viewModel.dismissFolderRename() }
        )
    }
    folderMove?.let { folder ->
        FolderMoveDialog(
            folder = folder,
            destinations = allFolders.filter { it.path != folder.path && it.path.startsWith("/") },
            onSelect = { viewModel.confirmFolderMove(folder, it) },
            onDismiss = { viewModel.dismissFolderMove() }
        )
    }

    if (showBulkDelete) {
        BulkDeleteConfirmDialog(
            count = selectedUris.size,
            onConfirm = { viewModel.confirmBulkDelete() },
            onDismiss = { viewModel.dismissBulkDeleteDialog() }
        )
    }

    if (actionSheetVideo != null) {
        VideoActionBottomSheet(
            video = actionSheetVideo,
            onDismiss = { viewModel.closeActionSheet() },
            onInfoClick = { video -> viewModel.openInfoSheet(video) },
            onFavoriteToggle = { video -> viewModel.toggleFavorite(video) },
            onPlayInBackground = { video ->
                viewModel.navigateTo(ScreenRoute.Player(video = video))
            },
            onAddToPlaylist = { video -> viewModel.openAddToPlaylistDialog(video) },
            onRenameClick = { video -> viewModel.requestRenameVideo(video) },
            onShareClick = { video -> shareVideoFile(context, video) },
            onDeleteClick = { video -> viewModel.requestDeleteVideo(video) },
            onHideClick = { video -> viewModel.hideVideo(video) }
        )
    }

    if (infoSheetVideo != null) {
        VideoInfoBottomSheet(
            video = infoSheetVideo,
            onDismiss = { viewModel.closeInfoSheet() }
        )
    }

    if (deleteConfirmVideo != null) {
        DeleteConfirmDialog(
            video = deleteConfirmVideo,
            onConfirm = { video -> viewModel.confirmDeleteVideo(video) },
            onDismiss = { viewModel.dismissDeleteDialog() }
        )
    }

    if (renameVideo != null) {
        RenameDialog(
            video = renameVideo,
            onConfirm = { video, newName -> viewModel.confirmRenameVideo(video, newName) },
            onDismiss = { viewModel.dismissRenameDialog() }
        )
    }

    if (addToPlaylistVideo != null) {
        AddToPlaylistDialog(
            video = addToPlaylistVideo,
            playlists = playlists,
            onSelectPlaylist = { plId, vid -> viewModel.addVideoToPlaylist(plId, vid) },
            onCreateNewPlaylist = { viewModel.openCreatePlaylistDialog() },
            onDismiss = { viewModel.dismissAddToPlaylistDialog() }
        )
    }
}
