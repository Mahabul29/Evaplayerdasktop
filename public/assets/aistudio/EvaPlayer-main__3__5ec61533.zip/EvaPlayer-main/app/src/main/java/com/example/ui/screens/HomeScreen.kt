package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.EvaBottomNavBar
import com.example.ui.components.RenameDialog
import com.example.ui.components.UpdatePrompt
import com.example.ui.components.VideoActionBottomSheet
import com.example.ui.components.VideoInfoBottomSheet
import com.example.ui.components.shareVideoFile
import com.example.ui.theme.DarkBackground
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedTab by viewModel.selectedTab.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    // Dialog & Sheet states
    val actionSheetVideo by viewModel.actionSheetVideo.collectAsState()
    val infoSheetVideo by viewModel.infoSheetVideo.collectAsState()
    val deleteConfirmVideo by viewModel.showDeleteConfirmDialog.collectAsState()
    val renameVideo by viewModel.showRenameDialog.collectAsState()
    val addToPlaylistVideo by viewModel.showPlaylistAddDialog.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    val folderSheet by viewModel.folderSheet.collectAsState()
    val sheetOpen = actionSheetVideo != null || infoSheetVideo != null || folderSheet != null

    val snackbarHostState = remember { SnackbarHostState() }

    // Request permissions launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        viewModel.refreshMedia()
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionsLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    // Toast snackbar
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    androidx.compose.runtime.CompositionLocalProvider(
        com.example.ui.components.LocalSheetOpen provides sheetOpen
    ) {
    Scaffold(
        bottomBar = {
            androidx.compose.foundation.layout.Column {
                EvaBottomNavBar(
                    selectedTab = selectedTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            val historyForPopup by viewModel.displayedHistoryVideos.collectAsState()
            when (selectedTab) {
                MainTab.FOLDERS -> FoldersScreen(viewModel = viewModel)
                MainTab.VIDEOS -> VideosScreen(viewModel = viewModel)
                MainTab.FILE_SHARE -> FileTransferScreen(viewModel = viewModel)
                MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
            // Quick-resume pop-up on the right edge, shown once per app launch
            com.example.ui.components.RecentPlayedPopup(
                lastVideo = historyForPopup.firstOrNull(),
                onResume = { video ->
                    viewModel.navigateTo(ScreenRoute.Player(video = video, playlist = historyForPopup))
                },
                modifier = Modifier.align(Alignment.CenterEnd)
            )
        }
    }
    }

    // Pop-up when a newer GitHub release is available
    UpdatePrompt()

    // Video Action Bottom Sheet
    if (actionSheetVideo != null) {
        VideoActionBottomSheet(
            video = actionSheetVideo,
            onDismiss = { viewModel.closeActionSheet() },
            onInfoClick = { video -> viewModel.openInfoSheet(video) },
            onFavoriteToggle = { video -> viewModel.toggleFavorite(video) },
            onPlayInBackground = { video ->
                viewModel.navigateTo(ScreenRoute.Player(video = video))
            },
            onAddToPlaylist = { video -> viewModel.openAddToPlaylistDialog(video) },
            onRenameClick = { video -> viewModel.requestRenameVideo(video) },
            onShareClick = { video -> shareVideoFile(context, video) },
            onDeleteClick = { video -> viewModel.requestDeleteVideo(video) },
            onHideClick = { video -> viewModel.hideVideo(video) }
        )
    }

    // Video Info Sheet
    if (infoSheetVideo != null) {
        VideoInfoBottomSheet(
            video = infoSheetVideo,
            onDismiss = { viewModel.closeInfoSheet() }
        )
    }

    // Delete Confirmation Dialog
    if (deleteConfirmVideo != null) {
        DeleteConfirmDialog(
            video = deleteConfirmVideo,
            onConfirm = { video -> viewModel.confirmDeleteVideo(video) },
            onDismiss = { viewModel.dismissDeleteDialog() }
        )
    }

    // Rename Dialog
    if (renameVideo != null) {
        RenameDialog(
            video = renameVideo,
            onConfirm = { video, newName -> viewModel.confirmRenameVideo(video, newName) },
            onDismiss = { viewModel.dismissRenameDialog() }
        )
    }

    // Add to Playlist Dialog
    if (addToPlaylistVideo != null) {
        AddToPlaylistDialog(
            video = addToPlaylistVideo,
            playlists = playlists,
            onSelectPlaylist = { plId, vid -> viewModel.addVideoToPlaylist(plId, vid) },
            onCreateNewPlaylist = { viewModel.openCreatePlaylistDialog() },
            onDismiss = { viewModel.dismissAddToPlaylistDialog() }
        )
    }
}
