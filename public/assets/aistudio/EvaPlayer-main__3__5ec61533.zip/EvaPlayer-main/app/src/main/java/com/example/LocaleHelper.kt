package com.example

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Maps the Display Language setting to a locale and applies it to an Activity's base context. */
object LocaleHelper {
    private const val PREFS = "eva_locale"
    private const val KEY = "lang"

    fun codeFor(displayName: String): String = when (displayName) {
        "Bangla" -> "bn"
        "Hindi" -> "hi"
        else -> "en"
    }

    fun savedCode(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "en") ?: "en"

    fun save(context: Context, displayName: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, codeFor(displayName)).apply()
    }

    fun wrap(base: Context, code: String): Context {
        val locale = Locale(code)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
