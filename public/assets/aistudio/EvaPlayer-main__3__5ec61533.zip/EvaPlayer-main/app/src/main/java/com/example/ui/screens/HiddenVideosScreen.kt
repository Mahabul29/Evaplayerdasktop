package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.HiddenItemEntity
import com.example.data.model.VideoItem
import com.example.ui.components.EvaTopBar
import com.example.ui.components.PinLockScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenRoute
import java.io.File

@Composable
fun HiddenVideosScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val isAppUnlocked by viewModel.isAppUnlocked.collectAsState()
    val hiddenItems by viewModel.hiddenItems.collectAsState()
    val allVideos by viewModel.allVideosRaw.collectAsState()

    var isScreenUnlocked by remember { mutableStateOf(!settings.appLockEnabled || isAppUnlocked) }
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Hidden Videos, 1: Hidden Folders

    if (!isScreenUnlocked && settings.appLockEnabled && settings.appLockPin.isNotEmpty()) {
        PinLockScreen(
            title = "Hidden Storage Lock",
            subtitle = "Enter 4-digit PIN to access hidden media",
            correctPin = settings.appLockPin,
            onSuccess = {
                isScreenUnlocked = true
                viewModel.unlockApp(settings.appLockPin)
            },
            onCancel = { viewModel.navigateBack() }
        )
        return
    }

    val hiddenVideos = hiddenItems.filter { !it.isFolder }
    val hiddenFolders = hiddenItems.filter { it.isFolder }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        EvaTopBar(
            title = "Hidden Media",
            canNavigateBack = true,
            onNavigateBack = { viewModel.navigateBack() },
            showSearchAndSort = false
        )

        // Tabs: Hidden Videos | Hidden Folders
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = DarkSurface,
            contentColor = GreenAccent,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = GreenAccent,
                    height = 2.dp
                )
            }
        ) {
            listOf("Hidden Videos (${hiddenVideos.size})", "Hidden Folders (${hiddenFolders.size})").forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == index) GreenAccent else TextSecondary
                        )
                    }
                )
            }
        }

        // Action header: Unhide All button
        if (hiddenItems.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = { viewModel.unhideAll() },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceContainer),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Visibility, contentDescription = null, tint = GreenAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Unhide All", color = GreenAccent, fontSize = 12.sp)
                }
            }
        }

        when (selectedTabIndex) {
            0 -> {
                // Hidden Videos
                if (hiddenVideos.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 80.dp)
                    ) {
                        Text("No hidden videos", color = TextSecondary, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        items(hiddenVideos, key = { it.path }) { item ->
                            val matchedVideo = allVideos.firstOrNull { it.path == item.path }
                            val title = matchedVideo?.title ?: File(item.path).nameWithoutExtension
                            val path = item.path

                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(text = path, color = TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }

                                    // Play hidden video inside app
                                    IconButton(onClick = {
                                        val v = matchedVideo ?: VideoItem(
                                            id = path,
                                            title = title,
                                            path = path,
                                            uriString = path,
                                            durationMs = 0L,
                                            sizeBytes = File(path).length(),
                                            dateModified = 0L,
                                            folderName = "Hidden",
                                            folderPath = "hidden"
                                        )
                                        viewModel.navigateTo(ScreenRoute.Player(video = v))
                                    }) {
                                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = GreenAccent)
                                    }

                                    // Unhide button
                                    IconButton(onClick = { viewModel.unhideItem(item.path) }) {
                                        Icon(imageVector = Icons.Default.Visibility, contentDescription = "Unhide", tint = TextPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Hidden Folders
                if (hiddenFolders.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 80.dp)
                    ) {
                        Text("No hidden folders", color = TextSecondary, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        items(hiddenFolders, key = { it.path }) { item ->
                            val folderName = File(item.path).name
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Folder, contentDescription = null, tint = GreenAccent)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = folderName, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = item.path, color = TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    IconButton(onClick = { viewModel.unhideItem(item.path) }) {
                                        Icon(imageVector = Icons.Default.Visibility, contentDescription = "Unhide", tint = TextPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
