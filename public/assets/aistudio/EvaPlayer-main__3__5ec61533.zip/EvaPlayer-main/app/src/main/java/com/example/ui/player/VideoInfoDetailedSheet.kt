package com.example.ui.player

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.VideoItem
import com.example.ui.theme.DividerDark
import com.example.ui.theme.TextPrimary

private val InfoLabel = Color(0xFF8FA6D6)

/** Centered "Video Information" card (rounded navy panel with icon rows). */
@Composable
fun VideoInfoDetailedSheet(video: VideoItem, onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xF20E1630),
            shape = RoundedCornerShape(26.dp),
            border = BorderStroke(1.5.dp, Color(0xFF2A3F73)),
            modifier = Modifier
                .fillMaxWidth(0.6f)
                .heightIn(max = 330.dp)
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 18.dp)
            ) {
                Text("Video Information", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.size(8.dp))
                InfoRow(Icons.Default.Movie, "Title", video.title)
                InfoRow(Icons.Default.Folder, "File Path", video.path.ifBlank { video.uriString })
                InfoRow(Icons.Default.Storage, "Size", video.sizeFormatted)
                InfoRow(Icons.Default.Tv, "Resolution", video.resolution)
                InfoRow(Icons.Default.Schedule, "Duration", video.durationFormatted, last = true)
            }
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String, last: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, tint = Color(0xFFDCE6FF), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = InfoLabel, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(value.ifBlank { "—" }, color = TextPrimary, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
    if (!last) HorizontalDivider(color = DividerDark)
}
