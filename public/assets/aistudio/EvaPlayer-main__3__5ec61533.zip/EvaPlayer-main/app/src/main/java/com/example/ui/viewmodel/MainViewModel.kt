package com.example.ui.viewmodel

import android.app.Application
import android.content.IntentSender
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.EvaPlayerApplication
import com.example.data.db.FavoriteEntity
import com.example.data.db.PlaybackRecord
import com.example.data.db.PlaylistEntity
import com.example.data.db.PlaylistItemEntity
import com.example.data.model.AudioItem
import com.example.data.model.BrowserFileItem
import com.example.data.model.FolderItem
import com.example.data.model.PlayerSettings
import com.example.data.model.StreamItem
import com.example.data.model.VideoItem
import com.example.data.transfer.LocalTransferServer
import com.example.data.transfer.RemoteFileItem
import com.example.data.transfer.ShareItem
import com.example.data.transfer.ShareKind
import com.example.data.transfer.TransferClient
import com.example.data.transfer.WifiAuto
import com.example.data.transfer.mimeFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed class ScreenRoute {
    object Main : ScreenRoute()
    data class FolderDetail(val folderName: String, val folderPath: String) : ScreenRoute()
    object Music : ScreenRoute()
    object UrlStream : ScreenRoute()
    object FileTransfer : ScreenRoute()
    object Playlists : ScreenRoute()
    data class PlaylistDetail(val playlistId: Long, val playlistName: String) : ScreenRoute()
    object Favorites : ScreenRoute()
    object HiddenVideos : ScreenRoute()
    object SubtitleSettings : ScreenRoute()
    object PrivacySettings : ScreenRoute()
    object Storage : ScreenRoute()
    data class Player(val video: VideoItem, val playlist: List<VideoItem> = emptyList(), val startIndex: Int = 0) : ScreenRoute()
}

enum class MainTab {
    FOLDERS, VIDEOS, FILE_SHARE, SETTINGS
}

enum class SortMode {
    DATE_DESC, DATE_ASC, NAME_ASC, NAME_DESC, SIZE_DESC, SIZE_ASC, DURATION_DESC, DURATION_ASC
}

enum class BrowserFilter {
    ALL, VIDEO, AUDIO, SUBTITLES
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val musicPlayer: ExoPlayer = ExoPlayer.Builder(application).build().apply {
        addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isAudioPlaying.value = isPlaying
            }
            override fun onPlayerError(error: PlaybackException) {
                _isAudioPlaying.value = false
                showToast("Could not play this audio file")
            }
        })
    }

    private val app = application as EvaPlayerApplication
    val settingsRepo = app.settingsRepository
    val mediaRepo = app.mediaRepository
    val playbackRepo = app.playbackRepository

    val transferServer = LocalTransferServer(application)
    val transferClient = TransferClient(application)

    // Current navigation state
    private val _currentScreen = MutableStateFlow<ScreenRoute>(ScreenRoute.Main)
    val currentScreen: StateFlow<ScreenRoute> = _currentScreen.asStateFlow()

    private val _selectedTab = MutableStateFlow(MainTab.FOLDERS)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    // Navigation history stack for BackHandler
    private val backStack = mutableListOf<ScreenRoute>()

    // Settings StateFlow
    val settings: StateFlow<PlayerSettings> = settingsRepo.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        PlayerSettings()
    )

    // Media Data Flows
    private val _allVideosRaw = MutableStateFlow<List<VideoItem>>(emptyList())
    val allVideosRaw: StateFlow<List<VideoItem>> = _allVideosRaw.asStateFlow()

    private val _allAudiosRaw = MutableStateFlow<List<AudioItem>>(emptyList())
    val allAudiosRaw: StateFlow<List<AudioItem>> = _allAudiosRaw.asStateFlow()

    val historyRecords: StateFlow<List<PlaybackRecord>> = playbackRepo.historyFlow.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    val favoritesRecords: StateFlow<List<FavoriteEntity>> = playbackRepo.favoritesFlow.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    val playlists: StateFlow<List<PlaylistEntity>> = playbackRepo.playlistsFlow.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    val hiddenItems = playbackRepo.hiddenItemsFlow.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    val streamHistory = playbackRepo.streamHistoryFlow.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    // UI Controls
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchOpen = MutableStateFlow(false)
    val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

    private val _sortMode = MutableStateFlow(SortMode.NAME_ASC)
    val sortMode: StateFlow<SortMode> = _sortMode.asStateFlow()

    private val _isVideoGrid = MutableStateFlow(false)
    val isVideoGrid: StateFlow<Boolean> = _isVideoGrid.asStateFlow()

    private val _videoFilterChip = MutableStateFlow("All") // "All", "Recent", "Favorites"
    val videoFilterChip: StateFlow<String> = _videoFilterChip.asStateFlow()

    // Browser State
    private val _browserCurrentPath = MutableStateFlow(android.os.Environment.getExternalStorageDirectory().absolutePath)
    val browserCurrentPath: StateFlow<String> = _browserCurrentPath.asStateFlow()

    private val _browserFiles = MutableStateFlow<List<BrowserFileItem>>(emptyList())
    val browserFiles: StateFlow<List<BrowserFileItem>> = _browserFiles.asStateFlow()

    private val _browserFilter = MutableStateFlow(BrowserFilter.ALL)
    val browserFilter: StateFlow<BrowserFilter> = _browserFilter.asStateFlow()

    private val _isBrowserGrid = MutableStateFlow(false)
    val isBrowserGrid: StateFlow<Boolean> = _isBrowserGrid.asStateFlow()

    private val _selectedBrowserFiles = MutableStateFlow<Set<String>>(emptySet())
    val selectedBrowserFiles: StateFlow<Set<String>> = _selectedBrowserFiles.asStateFlow()

    // Video Action Bottom Sheet
    private val _actionSheetVideo = MutableStateFlow<VideoItem?>(null)
    val actionSheetVideo: StateFlow<VideoItem?> = _actionSheetVideo.asStateFlow()

    // Video Info Sheet
    private val _infoSheetVideo = MutableStateFlow<VideoItem?>(null)
    val infoSheetVideo: StateFlow<VideoItem?> = _infoSheetVideo.asStateFlow()

    // Dialogs
    private val _showPlaylistAddDialog = MutableStateFlow<VideoItem?>(null)
    val showPlaylistAddDialog: StateFlow<VideoItem?> = _showPlaylistAddDialog.asStateFlow()

    private val _showCreatePlaylistDialog = MutableStateFlow(false)
    val showCreatePlaylistDialog: StateFlow<Boolean> = _showCreatePlaylistDialog.asStateFlow()

    private val _showDeleteConfirmDialog = MutableStateFlow<VideoItem?>(null)
    val showDeleteConfirmDialog: StateFlow<VideoItem?> = _showDeleteConfirmDialog.asStateFlow()

    // ---- Multi-select (Videos tab, folder detail, favorites) ----
    private val _selectedUris = MutableStateFlow<Set<String>>(emptySet())
    val selectedUris: StateFlow<Set<String>> = _selectedUris.asStateFlow()

    private val _showBulkDeleteDialog = MutableStateFlow(false)
    val showBulkDeleteDialog: StateFlow<Boolean> = _showBulkDeleteDialog.asStateFlow()

    private val _deleteRequestSender = MutableStateFlow<IntentSender?>(null)
    val deleteRequestSender: StateFlow<IntentSender?> = _deleteRequestSender.asStateFlow()
    private var pendingSystemDelete: List<VideoItem> = emptyList()
    private var pendingDeletedCount = 0

    private val _showRenameDialog = MutableStateFlow<VideoItem?>(null)
    val showRenameDialog: StateFlow<VideoItem?> = _showRenameDialog.asStateFlow()

    private val _isAppUnlocked = MutableStateFlow(false)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // File Transfer State
    private val _serverUrl = MutableStateFlow<String?>(null)
    val serverUrl: StateFlow<String?> = _serverUrl.asStateFlow()

    // QR text when sharing through the auto hotspot (name + password + link), else null
    private val _qrPayload = MutableStateFlow<String?>(null)
    val qrPayload: StateFlow<String?> = _qrPayload.asStateFlow()

    private val _hotspotName = MutableStateFlow<String?>(null)
    val hotspotName: StateFlow<String?> = _hotspotName.asStateFlow()

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    // Files picked from storage with the document picker (any type), plus the current selection
    private val _pickedShareItems = MutableStateFlow<List<ShareItem>>(emptyList())
    val pickedShareItems: StateFlow<List<ShareItem>> = _pickedShareItems.asStateFlow()

    private val _selectedShareKeys = MutableStateFlow<Set<String>>(emptySet())
    val selectedShareKeys: StateFlow<Set<String>> = _selectedShareKeys.asStateFlow()

    // Items currently being served over Wi-Fi
    private val _servedItems = MutableStateFlow<List<ShareItem>>(emptyList())
    val servedItems: StateFlow<List<ShareItem>> = _servedItems.asStateFlow()

    private val _clientRemoteFiles = MutableStateFlow<List<RemoteFileItem>>(emptyList())
    val clientRemoteFiles: StateFlow<List<RemoteFileItem>> = _clientRemoteFiles.asStateFlow()

    private val _isClientConnecting = MutableStateFlow(false)
    val isClientConnecting: StateFlow<Boolean> = _isClientConnecting.asStateFlow()

    // Music Player State (Mini player / Full sheet)
    private val _currentAudio = MutableStateFlow<AudioItem?>(null)
    val currentAudio: StateFlow<AudioItem?> = _currentAudio.asStateFlow()

    private val _isAudioPlaying = MutableStateFlow(false)
    val isAudioPlaying: StateFlow<Boolean> = _isAudioPlaying.asStateFlow()

    private val _audioPositionMs = MutableStateFlow(0L)
    val audioPositionMs: StateFlow<Long> = _audioPositionMs.asStateFlow()

    private val _showFullMusicSheet = MutableStateFlow(false)
    val showFullMusicSheet: StateFlow<Boolean> = _showFullMusicSheet.asStateFlow()

    init {
        refreshMedia()
        loadBrowserFiles(_browserCurrentPath.value)
    }

    fun refreshMedia() {
        viewModelScope.launch {
            val videos = mediaRepo.queryAllVideos()
            _allVideosRaw.value = videos

            val audios = mediaRepo.queryAllAudios()
            _allAudiosRaw.value = audios
        }
    }

    fun navigateTo(screen: ScreenRoute) {
        clearSelection()
        if (_currentScreen.value != screen) {
            backStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        clearSelection()
        if (backStack.isNotEmpty()) {
            _currentScreen.value = backStack.removeAt(backStack.size - 1)
            return true
        }
        return false
    }

    fun selectTab(tab: MainTab) {
        clearSelection()
        _selectedTab.value = tab
        if (_currentScreen.value != ScreenRoute.Main) {
            backStack.clear()
            _currentScreen.value = ScreenRoute.Main
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSearchOpen(open: Boolean) {
        _isSearchOpen.value = open
        if (!open) {
            _searchQuery.value = ""
        }
    }

    fun setSortMode(mode: SortMode) {
        _sortMode.value = mode
    }

    fun toggleVideoGrid() {
        _isVideoGrid.value = !_isVideoGrid.value
    }

    fun setVideoFilterChip(chip: String) {
        _videoFilterChip.value = chip
    }

    fun toggleBrowserGrid() {
        _isBrowserGrid.value = !_isBrowserGrid.value
    }

    fun setBrowserFilter(filter: BrowserFilter) {
        _browserFilter.value = filter
    }

    data class FilterState(
        val query: String,
        val chip: String,
        val sort: SortMode
    )

    private val filterStateFlow = combine(
        _searchQuery,
        _videoFilterChip,
        _sortMode
    ) { query, chip, sort ->
        FilterState(query, chip, sort)
    }

    // Filtered Video List taking into account: Hidden items, Search query, Filter chip, Sort
    val displayedVideos: StateFlow<List<VideoItem>> = combine(
        _allVideosRaw,
        historyRecords,
        favoritesRecords,
        hiddenItems,
        filterStateFlow
    ) { rawVideos, history, favs, hidden, filterState ->
        val hiddenPaths = hidden.map { it.path }.toSet()
        val favUris = favs.map { it.uriString }.toSet()
        val historyMap = history.associate { it.uriString to it.lastPositionMs }

        var list = rawVideos.filter { video ->
            video.path !in hiddenPaths &&
            video.folderPath !in hiddenPaths
        }.map { video ->
            video.copy(
                isFavorite = video.uriString in favUris,
                lastPositionMs = historyMap[video.uriString] ?: 0L
            )
        }

        // Apply filter chip
        list = when (filterState.chip) {
            "Recent" -> list.filter { it.lastPositionMs > 0 }
            "Favorites" -> list.filter { it.isFavorite }
            else -> list
        }

        // Apply search query
        if (filterState.query.isNotBlank()) {
            list = list.filter {
                it.title.contains(filterState.query, ignoreCase = true) ||
                it.folderName.contains(filterState.query, ignoreCase = true)
            }
        }

        // Apply sort
        when (filterState.sort) {
            SortMode.DATE_DESC -> list.sortedByDescending { it.dateModified }
            SortMode.DATE_ASC -> list.sortedBy { it.dateModified }
            SortMode.NAME_ASC -> list.sortedBy { it.title.lowercase() }
            SortMode.NAME_DESC -> list.sortedByDescending { it.title.lowercase() }
            SortMode.SIZE_DESC -> list.sortedByDescending { it.sizeBytes }
            SortMode.SIZE_ASC -> list.sortedBy { it.sizeBytes }
            SortMode.DURATION_DESC -> list.sortedByDescending { it.durationMs }
            SortMode.DURATION_ASC -> list.sortedBy { it.durationMs }
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // History Row on top of Folders Screen
    val displayedHistoryVideos: StateFlow<List<VideoItem>> = combine(
        _allVideosRaw,
        historyRecords,
        hiddenItems
    ) { rawVideos, history, hidden ->
        val hiddenPaths = hidden.map { it.path }.toSet()
        val videoMap = rawVideos.associateBy { it.uriString }

        history.filter { record ->
            record.path !in hiddenPaths && record.folderPath !in hiddenPaths
        }.mapNotNull { record ->
            val v = videoMap[record.uriString]
            v?.copy(lastPositionMs = record.lastPositionMs) ?: VideoItem(
                id = record.uriString,
                title = record.title,
                path = record.path,
                uriString = record.uriString,
                durationMs = record.durationMs,
                sizeBytes = 0L,
                dateModified = record.timestamp / 1000,
                folderName = "History",
                folderPath = record.folderPath,
                lastPositionMs = record.lastPositionMs,
                isStream = record.isStream
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Folders on Folders Screen
    val displayedFolders: StateFlow<List<FolderItem>> = combine(
        displayedVideos,
        hiddenItems,
        _searchQuery,
        _sortMode
    ) { videos, hidden, query, sort ->
        val hiddenPaths = hidden.map { it.path }.toSet()
        val folderMap = mutableMapOf<String, MutableList<VideoItem>>()

        for (v in videos) {
            if (v.folderPath in hiddenPaths) continue
            val key = v.folderPath.ifEmpty { v.folderName }
            folderMap.getOrPut(key) { mutableListOf() }.add(v)
        }

        var folders = folderMap.map { (path, items) ->
            val name = items.firstOrNull()?.folderName ?: File(path).name
            val isReceived = name.equals("Received", ignoreCase = true) || path.contains("Received")
            FolderItem(
                path = path,
                name = name,
                videoCount = items.size,
                totalSizeBytes = items.sumOf { it.sizeBytes },
                isReceived = isReceived,
                receivedCount = if (isReceived) items.size else 0,
                latestModified = items.maxOfOrNull { it.dateModified } ?: 0L,
                totalDurationMs = items.sumOf { it.durationMs }
            )
        }

        if (query.isNotBlank()) {
            folders = folders.filter { it.name.contains(query, ignoreCase = true) }
        }

        val byName: Comparator<FolderItem> = compareBy<FolderItem> { it.name.lowercase() }
        val order: Comparator<FolderItem> = when (sort) {
            SortMode.NAME_DESC -> byName.reversed()
            SortMode.SIZE_DESC -> compareByDescending<FolderItem> { it.totalSizeBytes }
            SortMode.SIZE_ASC -> compareBy<FolderItem> { it.totalSizeBytes }
            SortMode.DATE_DESC -> compareByDescending<FolderItem> { it.latestModified }
            SortMode.DATE_ASC -> compareBy<FolderItem> { it.latestModified }
            SortMode.DURATION_DESC -> compareByDescending<FolderItem> { it.totalDurationMs }
            SortMode.DURATION_ASC -> compareBy<FolderItem> { it.totalDurationMs }
            else -> byName
        }
        folders.sortedWith(compareByDescending<FolderItem> { it.isReceived }.then(order))
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ---------------- Folder actions (3-dot menu on folder cards) ----------------
    private val _folderSheet = MutableStateFlow<FolderItem?>(null)
    val folderSheet: StateFlow<FolderItem?> = _folderSheet.asStateFlow()

    private val _folderRenameTarget = MutableStateFlow<FolderItem?>(null)
    val folderRenameTarget: StateFlow<FolderItem?> = _folderRenameTarget.asStateFlow()

    private val _folderMoveTarget = MutableStateFlow<FolderItem?>(null)
    val folderMoveTarget: StateFlow<FolderItem?> = _folderMoveTarget.asStateFlow()

    private var bulkFromFolder = false

    fun openFolderSheet(folder: FolderItem) { _folderSheet.value = folder }
    fun closeFolderSheet() { _folderSheet.value = null }

    fun videosInFolder(folder: FolderItem): List<VideoItem> =
        _allVideosRaw.value.filter { (it.folderPath.ifEmpty { it.folderName }) == folder.path }

    fun requestFolderRename(folder: FolderItem) { _folderSheet.value = null; _folderRenameTarget.value = folder }
    fun dismissFolderRename() { _folderRenameTarget.value = null }

    fun confirmFolderRename(folder: FolderItem, newName: String) {
        _folderRenameTarget.value = null
        viewModelScope.launch {
            val ok = mediaRepo.renameFolder(folder.path, newName)
            if (ok) {
                refreshMedia()
                showToast("Folder renamed to ${newName.trim()}")
            } else {
                showToast("Could not rename folder (name exists or storage access denied)")
            }
        }
    }

    fun requestFolderMove(folder: FolderItem) { _folderSheet.value = null; _folderMoveTarget.value = folder }
    fun dismissFolderMove() { _folderMoveTarget.value = null }

    fun confirmFolderMove(folder: FolderItem, destination: FolderItem) {
        _folderMoveTarget.value = null
        viewModelScope.launch {
            val (moved, failed) = mediaRepo.moveVideos(videosInFolder(folder), destination.path)
            refreshMedia()
            showToast(
                when {
                    moved > 0 && failed == 0 -> "Moved $moved video(s) to ${destination.name}"
                    moved > 0 -> "Moved $moved, $failed could not be moved"
                    else -> "Could not move videos (storage access denied)"
                }
            )
        }
    }

    /** Selects every video in the folder and opens the normal delete confirmation. */
    fun requestFolderDelete(folder: FolderItem) {
        _folderSheet.value = null
        val vids = videosInFolder(folder)
        if (vids.isEmpty()) { showToast("No videos in this folder"); return }
        _selectedUris.value = vids.map { it.uriString }.toSet()
        bulkFromFolder = true
        _showBulkDeleteDialog.value = true
    }

    fun hideFolderFromSheet(folder: FolderItem) {
        _folderSheet.value = null
        hideFolder(folder.path)
    }

    // Browser navigation
    fun loadBrowserFiles(dirPath: String) {
        viewModelScope.launch {
            _browserCurrentPath.value = dirPath
            _browserFiles.value = mediaRepo.listBrowserFiles(dirPath)
            _selectedBrowserFiles.value = emptySet()
        }
    }

    fun navigateBrowserUp(): Boolean {
        val current = File(_browserCurrentPath.value)
        val parent = current.parentFile
        if (parent != null && parent.canRead()) {
            loadBrowserFiles(parent.absolutePath)
            return true
        }
        return false
    }

    fun toggleBrowserFileSelection(path: String) {
        val current = _selectedBrowserFiles.value.toMutableSet()
        if (path in current) current.remove(path) else current.add(path)
        _selectedBrowserFiles.value = current
    }

    fun clearBrowserSelection() {
        _selectedBrowserFiles.value = emptySet()
    }

    // Bottom Sheet & Action Triggers
    fun openActionSheet(video: VideoItem) {
        _actionSheetVideo.value = video
    }

    fun closeActionSheet() {
        _actionSheetVideo.value = null
    }

    fun openInfoSheet(video: VideoItem) {
        _infoSheetVideo.value = video
    }

    fun closeInfoSheet() {
        _infoSheetVideo.value = null
    }

    fun toggleFavorite(video: VideoItem) {
        viewModelScope.launch {
            playbackRepo.toggleFavorite(video, !video.isFavorite)
            showToast(if (!video.isFavorite) "Added to Favorites" else "Removed from Favorites")
        }
    }

    fun hideVideo(video: VideoItem) {
        viewModelScope.launch {
            playbackRepo.hideItem(video.path, isFolder = false)
            showToast("Video hidden")
            closeActionSheet()
        }
    }

    fun hideFolder(folderPath: String) {
        viewModelScope.launch {
            playbackRepo.hideItem(folderPath, isFolder = true)
            showToast("Folder hidden")
        }
    }

    fun unhideItem(path: String) {
        viewModelScope.launch {
            playbackRepo.unhideItem(path)
            showToast("Unhidden")
        }
    }

    fun unhideAll() {
        viewModelScope.launch {
            playbackRepo.unhideAll()
            showToast("All items unhidden")
        }
    }

    fun toggleSelection(video: VideoItem) {
        val cur = _selectedUris.value
        _selectedUris.value = if (video.uriString in cur) cur - video.uriString else cur + video.uriString
    }

    fun selectAll(videos: List<VideoItem>) {
        val all = videos.map { it.uriString }.toSet()
        // Tap again when everything is already selected to deselect all
        _selectedUris.value = if (_selectedUris.value.containsAll(all)) emptySet() else all
    }

    fun clearSelection() {
        _selectedUris.value = emptySet()
    }

    fun selectedVideos(): List<VideoItem> {
        val sel = _selectedUris.value
        return _allVideosRaw.value.filter { it.uriString in sel }
    }

    fun requestBulkDelete() {
        if (_selectedUris.value.isNotEmpty()) _showBulkDeleteDialog.value = true
    }

    fun dismissBulkDeleteDialog() {
        _showBulkDeleteDialog.value = false
        if (bulkFromFolder) {
            bulkFromFolder = false
            clearSelection()
        }
    }

    fun confirmBulkDelete() {
        _showBulkDeleteDialog.value = false
        bulkFromFolder = false
        val targets = selectedVideos()
        if (targets.isEmpty()) {
            clearSelection()
            return
        }
        viewModelScope.launch {
            val (deleted, failed) = mediaRepo.deleteVideos(targets)
            removeDeletedVideos(deleted)
            if (failed.isNotEmpty()) {
                val sender = mediaRepo.createDeleteRequest(failed)
                if (sender != null) {
                    // Ask the system once to delete the rest; result comes back via onDeleteRequestResult
                    pendingSystemDelete = failed
                    pendingDeletedCount = deleted.size
                    _deleteRequestSender.value = sender
                    return@launch
                }
                showToast("Deleted ${deleted.size}, couldn't delete ${failed.size}")
            } else {
                showToast(if (deleted.size == 1) "Deleted 1 video" else "Deleted ${deleted.size} videos")
            }
            clearSelection()
        }
    }

    fun onDeleteRequestResult(approved: Boolean) {
        _deleteRequestSender.value = null
        val pending = pendingSystemDelete
        pendingSystemDelete = emptyList()
        viewModelScope.launch {
            if (approved) {
                // Android 10 only grants permission; the delete itself must be retried.
                // On Android 11+ the system already deleted the files, so this is a no-op re-check.
                val confirmed = pending.filter { mediaRepo.deleteVideo(it) || !java.io.File(it.path).exists() }
                removeDeletedVideos(confirmed)
                val total = pendingDeletedCount + confirmed.size
                showToast(if (total == 1) "Deleted 1 video" else "Deleted $total videos")
            } else if (pendingDeletedCount > 0) {
                showToast("Deleted $pendingDeletedCount, ${pending.size} not deleted")
            }
            pendingDeletedCount = 0
            clearSelection()
            refreshMedia()
        }
    }

    private suspend fun removeDeletedVideos(videos: List<VideoItem>) {
        if (videos.isEmpty()) return
        val gone = videos.map { it.uriString }.toSet()
        for (v in videos) {
            playbackRepo.removeFromHistory(v.uriString)
            playbackRepo.toggleFavorite(v, false)
        }
        _allVideosRaw.value = _allVideosRaw.value.filter { it.uriString !in gone }
    }

    fun requestDeleteVideo(video: VideoItem) {
        _showDeleteConfirmDialog.value = video
    }

    fun confirmDeleteVideo(video: VideoItem) {
        _showDeleteConfirmDialog.value = null
        closeActionSheet()
        viewModelScope.launch {
            if (mediaRepo.deleteVideo(video)) {
                removeDeletedVideos(listOf(video))
                showToast("Deleted")
                return@launch
            }
            // Not our file (Telegram, MovieBox, ...): ask the system for permission to delete it.
            val sender = mediaRepo.createDeleteRequest(listOf(video))
                ?: mediaRepo.legacyDeletePrompt(video)
            if (sender != null) {
                pendingSystemDelete = listOf(video)
                pendingDeletedCount = 0
                _deleteRequestSender.value = sender
            } else {
                showToast("Couldn't delete this video")
            }
        }
    }

    fun dismissDeleteDialog() {
        _showDeleteConfirmDialog.value = null
    }

    fun requestRenameVideo(video: VideoItem) {
        _showRenameDialog.value = video
    }

    fun confirmRenameVideo(video: VideoItem, newName: String) {
        viewModelScope.launch {
            val extension = video.path.substringAfterLast('.', "mp4")
            val targetName = if (newName.contains(".")) newName else "$newName.$extension"
            val ok = mediaRepo.renameFile(video.path, targetName)
            if (ok) {
                refreshMedia()
                showToast("Renamed to $targetName")
            } else {
                showToast("Could not rename file")
            }
            _showRenameDialog.value = null
            closeActionSheet()
        }
    }

    fun dismissRenameDialog() {
        _showRenameDialog.value = null
    }

    fun openAddToPlaylistDialog(video: VideoItem) {
        _showPlaylistAddDialog.value = video
        closeActionSheet()
    }

    fun dismissAddToPlaylistDialog() {
        _showPlaylistAddDialog.value = null
    }

    fun addVideoToPlaylist(playlistId: Long, video: VideoItem) {
        viewModelScope.launch {
            playbackRepo.addVideoToPlaylist(playlistId, video)
            showToast("Added to playlist")
            _showPlaylistAddDialog.value = null
        }
    }

    fun createNewPlaylist(name: String) {
        viewModelScope.launch {
            playbackRepo.createPlaylist(name)
            showToast("Playlist created")
            _showCreatePlaylistDialog.value = false
        }
    }

    fun openCreatePlaylistDialog() {
        _showCreatePlaylistDialog.value = true
    }

    fun dismissCreatePlaylistDialog() {
        _showCreatePlaylistDialog.value = false
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            playbackRepo.deletePlaylist(playlistId)
            showToast("Playlist deleted")
        }
    }

    fun clearPlaybackHistory() {
        viewModelScope.launch {
            playbackRepo.clearHistory()
            showToast("History cleared")
        }
    }

    fun removeFromHistory(uriString: String) {
        viewModelScope.launch {
            playbackRepo.removeFromHistory(uriString)
            showToast("Removed from history")
        }
    }

    // App PIN Lock
    fun unlockApp(pin: String): Boolean {
        val savedPin = settings.value.appLockPin
        if (savedPin.isEmpty() || pin == savedPin) {
            _isAppUnlocked.value = true
            return true
        }
        return false
    }

    fun lockApp() {
        _isAppUnlocked.value = false
    }

    // File Transfer Actions
    fun toggleShareItem(key: String) {
        val set = _selectedShareKeys.value.toMutableSet()
        if (key in set) set.remove(key) else set.add(key)
        _selectedShareKeys.value = set
    }

    fun setShareSelection(keys: Set<String>) {
        _selectedShareKeys.value = keys
    }

    fun clearShareSelection() {
        _selectedShareKeys.value = emptySet()
    }

    fun removePickedShareItem(key: String) {
        _pickedShareItems.value = _pickedShareItems.value.filter { it.key != key }
        _selectedShareKeys.value = _selectedShareKeys.value - key
    }

    /** Adds files chosen in the system document picker (any file type) and selects them. */
    fun addPickedDocuments(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val items = withContext(Dispatchers.IO) {
                uris.map { uri ->
                    var name = uri.lastPathSegment ?: "file"
                    var size = 0L
                    try {
                        resolver.query(uri, null, null, null, null)?.use { c ->
                            if (c.moveToFirst()) {
                                val ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                                val si = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                                if (ni >= 0) c.getString(ni)?.let { name = it }
                                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                            }
                        }
                    } catch (e: Exception) {
                        // keep fallback name
                    }
                    val mime = resolver.getType(uri) ?: mimeFor(name)
                    ShareItem("d:$uri", name, size, uri.toString(), "", mime, ShareKind.FILE)
                }
            }
            val existing = _pickedShareItems.value.associateBy { it.key }.toMutableMap()
            items.forEach { existing[it.key] = it }
            _pickedShareItems.value = existing.values.toList()
            _selectedShareKeys.value = _selectedShareKeys.value + items.map { it.key }
        }
    }

    fun startSharing(items: List<ShareItem>) {
        viewModelScope.launch {
            if (items.isEmpty()) {
                showToast("Please select at least one file")
                return@launch
            }
            try {
                val url = transferServer.startServer(port = 8080, items = items)
                _servedItems.value = items
                _serverUrl.value = url
                _isServerRunning.value = true
            } catch (e: Exception) {
                showToast("Could not start sharing. Check Wi-Fi / hotspot and try again.")
            }
        }
    }

    /** Starts a hotspot automatically, serves the files on it and builds the one-scan QR. */
    fun startHotspotSharing(items: List<ShareItem>) {
        if (items.isEmpty()) {
            showToast("Please select at least one file")
            return
        }
        val app = getApplication<Application>()
        WifiAuto.startHotspot(
            app,
            onReady = { ssid, pass ->
                viewModelScope.launch {
                    try {
                        val base = transferServer.startServer(port = 8080, items = items)
                        val port = base.substringAfterLast(':')
                        val ip = WifiAuto.hotspotIp()
                        val url = if (ip != null) "http://$ip:$port" else base
                        _servedItems.value = items
                        _serverUrl.value = url
                        _hotspotName.value = ssid
                        _qrPayload.value = WifiAuto.buildPayload(ssid, pass, url)
                        _isServerRunning.value = true
                    } catch (e: Exception) {
                        WifiAuto.stopHotspot()
                        showToast("Could not start sharing. Try again.")
                    }
                }
            },
            onFail = { msg -> showToast(msg) }
        )
    }

    /** Receiver: join the sender's hotspot from a scanned QR, then list its files. */
    fun joinFromQr(text: String) {
        val info = WifiAuto.parsePayload(text)
        if (info == null) {
            showToast("This QR code is not valid")
            return
        }
        _isClientConnecting.value = true
        showToast("Joining ${info.ssid}…")
        WifiAuto.connect(
            getApplication<Application>(), info.ssid, info.pass,
            onConnected = {
                _isClientConnecting.value = false
                connectToSender(info.url)
            },
            onFail = { msg ->
                _isClientConnecting.value = false
                showToast(msg)
            }
        )
    }

    fun stopSharing() {
        WifiAuto.stopHotspot()
        _qrPayload.value = null
        _hotspotName.value = null
        transferServer.stopServer()
        _servedItems.value = emptyList()
        _serverUrl.value = null
        _isServerRunning.value = false
    }

    fun connectToSender(url: String) {
        viewModelScope.launch {
            _isClientConnecting.value = true
            try {
                val list = transferClient.fetchRemoteFiles(url)
                _clientRemoteFiles.value = list
                showToast("Found ${list.size} files")
            } catch (e: Exception) {
                showToast("Connection failed. Ensure both devices are on same Wi-Fi.")
            } finally {
                _isClientConnecting.value = false
            }
        }
    }

    fun downloadRemoteFile(baseUrl: String, item: RemoteFileItem) {
        viewModelScope.launch {
            val updated = _clientRemoteFiles.value.toMutableList()
            val idx = updated.indexOfFirst { it.id == item.id }
            if (idx != -1) {
                updated[idx] = item.copy(progress = 0.05f, speed = "Starting...")
                _clientRemoteFiles.value = updated
            }

            val file = transferClient.downloadFile(baseUrl, item) { prog, speed ->
                val list = _clientRemoteFiles.value.toMutableList()
                val i = list.indexOfFirst { it.id == item.id }
                if (i != -1) {
                    list[i] = list[i].copy(progress = prog, speed = speed)
                    _clientRemoteFiles.value = list
                }
            }

            val finishList = _clientRemoteFiles.value.toMutableList()
            val i = finishList.indexOfFirst { it.id == item.id }
            if (i != -1) {
                if (file != null && file.exists()) {
                    finishList[i] = finishList[i].copy(progress = 1f, speed = "Saved", isCompleted = true)
                    showToast("Downloaded to Movies/EvaPlayer/Received")
                    refreshMedia()
                } else {
                    finishList[i] = finishList[i].copy(isFailed = true, speed = "Failed")
                }
                _clientRemoteFiles.value = finishList
            }
        }
    }

    // Music Player controls
    fun playAudio(audio: AudioItem) {
        _currentAudio.value = audio
        _audioPositionMs.value = 0L
        try {
            musicPlayer.setMediaItem(MediaItem.fromUri(audio.uriString.ifBlank { audio.path }))
            musicPlayer.prepare()
            musicPlayer.play()
            _isAudioPlaying.value = true
        } catch (e: Exception) {
            _isAudioPlaying.value = false
            showToast("Could not play this audio file")
        }
    }

    fun toggleAudioPlayPause() {
        if (musicPlayer.isPlaying) musicPlayer.pause() else musicPlayer.play()
        _isAudioPlaying.value = musicPlayer.isPlaying
    }

    fun seekAudio(positionMs: Long) {
        _audioPositionMs.value = positionMs
        musicPlayer.seekTo(positionMs)
    }

    fun showFullMusicPlayer(show: Boolean) {
        _showFullMusicSheet.value = show
    }

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        musicPlayer.release()
        super.onCleared()
        WifiAuto.stopHotspot()
        WifiAuto.disconnect(getApplication<Application>())
        transferServer.stopServer()
    }
}
