package com.example.ui.screens

import android.content.Context
import com.example.R
import androidx.compose.ui.res.stringResource
import androidx.compose.material.icons.filled.QrCodeScanner
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.transfer.RemoteFileItem
import com.example.data.transfer.ShareItem
import com.example.data.transfer.ShareKind
import com.example.data.transfer.toShareItem
import com.example.ui.components.EvaTopBar
import com.example.ui.components.QrCodeGenerator
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceContainer
import com.example.ui.theme.DividerDark
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import java.io.File

// ----------------------------------------------------------------------------------------
// Sharing helpers (system intents)
// ----------------------------------------------------------------------------------------

private fun formatTotal(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format("%.2f GB", mb / 1024.0) else String.format("%.1f MB", mb)
}

// ----------------------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------------------

@Composable
fun FileTransferScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentMode by remember { mutableIntStateOf(0) } // 0: home, 1: send, 2: receive

    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val serverUrl by viewModel.serverUrl.collectAsState()
    var showSendInfo by remember { mutableStateOf(false) }
    var showReceiveInfo by remember { mutableStateOf(false) }
    var receiveAutoScan by remember { mutableStateOf(false) }

    if (showSendInfo) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showSendInfo = false },
            containerColor = DarkSurface,
            title = { Text("Send files", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1.  Turn on Wi-Fi", color = TextPrimary, fontSize = 15.sp)
                    Text("2.  Select the files you want to send", color = TextPrimary, fontSize = 15.sp)
                    Text("3.  Tap Share (Wi-Fi Transfer) at the bottom", color = TextPrimary, fontSize = 15.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showSendInfo = false; currentMode = 1 }) {
                    Text("Select files", color = GreenAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    try {
                        val i = if (android.os.Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI)
                        else Intent(Settings.ACTION_WIFI_SETTINGS)
                        context.startActivity(i)
                    } catch (e: Exception) { }
                }) { Text("Turn on Wi-Fi", color = TextSecondary) }
            }
        )
    }

    if (showReceiveInfo) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showReceiveInfo = false },
            containerColor = DarkSurface,
            title = { Text("Receive files", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1.  Turn on Hotspot (or join the same Wi-Fi as the sender)", color = TextPrimary, fontSize = 15.sp)
                    Text("2.  Scan the sender's QR code, or enter the sender's link", color = TextPrimary, fontSize = 15.sp)
                    TextButton(onClick = {
                        try {
                            context.startActivity(
                                Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {
                            try { context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (_: Exception) { }
                        }
                    }) { Text("Turn on Hotspot", color = GreenAccent, fontWeight = FontWeight.Bold) }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReceiveInfo = false; receiveAutoScan = true; currentMode = 2 }) {
                    Text("Scan QR code", color = GreenAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReceiveInfo = false; receiveAutoScan = false; currentMode = 2 }) {
                    Text("Enter link", color = TextSecondary)
                }
            }
        )
    }

    BackHandler(enabled = currentMode != 0) { currentMode = 0 }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        EvaTopBar(
            title = when (currentMode) {
                1 -> "Send files"
                2 -> "Receive files"
                else -> "File Share"
            },
            canNavigateBack = true,
            onNavigateBack = {
                if (currentMode != 0) currentMode = 0 else viewModel.navigateBack()
            },
            showSearchAndSort = false
        )

        // Offline hint
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceContainer)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Wifi, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = "No internet needed. Put both phones on the same Wi-Fi or hotspot.",
                color = TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {
                try {
                    context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                } catch (e: Exception) { }
            }) {
                Text("Wi-Fi", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        when (currentMode) {
            0 -> ShareHome(
                onSend = { if (isServerRunning) currentMode = 1 else showSendInfo = true },
                onReceive = { showReceiveInfo = true },
                isSharingActive = isServerRunning
            )
            1 -> if (isServerRunning && serverUrl != null) {
                SharingActive(viewModel = viewModel, url = serverUrl!!)
            } else {
                SendPicker(viewModel = viewModel)
            }
            2 -> ReceiveMode(viewModel = viewModel, autoScan = receiveAutoScan)
        }
    }
}

// ----------------------------------------------------------------------------------------
// Home: Send / Receive tiles
// ----------------------------------------------------------------------------------------

@Composable
private fun ShareHome(onSend: () -> Unit, onReceive: () -> Unit, isSharingActive: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            ModeTile("Send", "Videos, music or any file", Icons.Default.CallMade, GreenAccent, Modifier.weight(1f), onSend)
            ModeTile("Receive", "From another phone", Icons.Default.CallReceived, Color(0xFF00C853), Modifier.weight(1f), onReceive)
        }
        if (isSharingActive) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Wi-Fi sharing is active. Tap Send to see the link.",
                color = GreenAccent,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "Pick files from your library or storage, then send them with Wi-Fi Transfer. Works without internet.",
            color = TextSecondary,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
        // Ad below the Send / Receive tiles and the text
        Spacer(Modifier.height(20.dp))
        com.example.ads.AdsterraBanner(
            format = com.example.ads.AdsterraFormat.RECT_300x250,
            scale = 0.8f,
            slotKey = "fixed_transfer"
        )
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ModeTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .height(170.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(DarkSurface)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.18f))
        ) {
            Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

// ----------------------------------------------------------------------------------------
// Send: multi-select picker
// ----------------------------------------------------------------------------------------

@Composable
private fun SendPicker(viewModel: MainViewModel) {
    val context = LocalContext.current
    val allVideos by viewModel.allVideosRaw.collectAsState()
    val allAudios by viewModel.allAudiosRaw.collectAsState()
    val picked by viewModel.pickedShareItems.collectAsState()
    val selectedKeys by viewModel.selectedShareKeys.collectAsState()

    var tab by remember { mutableIntStateOf(0) } // 0 videos, 1 audio, 2 storage files

    val videoItems = remember(allVideos) { allVideos.filter { !it.path.startsWith("http") }.map { it.toShareItem() } }
    val audioItems = remember(allAudios) { allAudios.map { it.toShareItem() } }
    val everything = remember(videoItems, audioItems, picked) { videoItems + audioItems + picked }
    val selectedItems = remember(everything, selectedKeys) { everything.filter { it.key in selectedKeys } }
    val totalBytes = selectedItems.sumOf { it.sizeBytes }

    val tabItems = when (tab) {
        0 -> videoItems
        1 -> audioItems
        else -> picked
    }

    // ---- Auto Wi-Fi: ask permission / ask to turn Wi-Fi on, then start hotspot sharing
    var askWifiOn by remember { mutableStateOf(false) }
    fun startAuto() {
        if (!com.example.data.transfer.WifiAuto.isWifiEnabled(context)) askWifiOn = true
        else viewModel.startHotspotSharing(selectedItems)
    }
    val wifiPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) startAuto()
        else viewModel.showToast("Allow Nearby devices / Location to create the hotspot")
    }
    fun beginSharing() {
        if (com.example.data.transfer.WifiAuto.isOnWifi(context)) {
            viewModel.startSharing(selectedItems)   // already on a shared network
            return
        }
        val needed = if (android.os.Build.VERSION.SDK_INT >= 33)
            arrayOf(android.Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter {
            androidx.core.content.ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startAuto() else wifiPerms.launch(missing.toTypedArray())
    }
    if (askWifiOn) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { askWifiOn = false },
            title = { Text("Turn on Wi-Fi") },
            text = { Text("Wi-Fi is off. Turn it on, come back, and tap Wi-Fi again. The hotspot starts automatically.") },
            confirmButton = {
                TextButton(onClick = {
                    askWifiOn = false
                    val i = if (android.os.Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI)
                    else Intent(Settings.ACTION_WIFI_SETTINGS)
                    try { context.startActivity(i) } catch (e: Exception) { /* ignore */ }
                }) { Text("Turn on") }
            },
            dismissButton = { TextButton(onClick = { askWifiOn = false }) { Text("Cancel") } }
        )
    }

    // System file picker: multi-select any files from storage
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        viewModel.addPickedDocuments(uris)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Videos", "Audio", "Files").forEachIndexed { i, label ->
                val sel = tab == i
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .height(34.dp)
                        .clip(RoundedCornerShape(17.dp))
                        .background(if (sel) GreenAccent else DarkSurfaceContainer)
                        .clickable { tab = i }
                        .padding(horizontal = 18.dp)
                ) {
                    Text(label, color = if (sel) Color.White else TextPrimary, fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        // Select all / browse row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${tabItems.size} items",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            if (tab == 2) {
                TextButton(onClick = { pickFiles.launch(arrayOf("*/*")) }) {
                    Icon(Icons.Default.FolderOpen, null, tint = GreenAccent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Browse storage", color = GreenAccent, fontSize = 13.sp)
                }
            }
            if (tabItems.isNotEmpty()) {
                val allSelected = tabItems.all { it.key in selectedKeys }
                TextButton(onClick = {
                    val keys = tabItems.map { it.key }.toSet()
                    viewModel.setShareSelection(if (allSelected) selectedKeys - keys else selectedKeys + keys)
                }) {
                    Text(if (allSelected) "Clear" else "Select all", color = GreenAccent, fontSize = 13.sp)
                }
            }
        }

        // List
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (tabItems.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (tab == 2) {
                        Text("Send any file from your phone", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Photos, documents, APKs, archives, anything.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { pickFiles.launch(arrayOf("*/*")) },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenAccent, contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Browse storage")
                        }
                    } else {
                        Text(if (tab == 0) "No videos found" else "No audio files found", color = TextSecondary, fontSize = 14.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    items(tabItems, key = { it.key }) { item ->
                        ShareItemRow(
                            item = item,
                            selected = item.key in selectedKeys,
                            onToggle = { viewModel.toggleShareItem(item.key) }
                        )
                    }
                }
            }
        }

        // Bottom action panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurface)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Text(
                text = if (selectedItems.isEmpty()) "Select files to send"
                else "${selectedItems.size} selected • ${formatTotal(totalBytes)}",
                color = if (selectedItems.isEmpty()) TextSecondary else GreenAccent,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { beginSharing() },
                enabled = selectedItems.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.Wifi, null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Wi-Fi Transfer", fontSize = 15.sp, maxLines = 1, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ShareItemRow(item: ShareItem, selected: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) GreenAccent.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onToggle)
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(width = 64.dp, height = 46.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(DarkSurfaceContainer)
        ) {
            when (item.kind) {
                ShareKind.VIDEO -> AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current).data(item.uriString).crossfade(true).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                ShareKind.AUDIO -> Icon(Icons.Default.MusicNote, null, tint = Color(0xFFE91E63), modifier = Modifier.size(24.dp))
                ShareKind.FILE -> {
                    val ext = item.extension.uppercase().take(4)
                    if (ext.isEmpty()) Icon(Icons.Default.Description, null, tint = TextSecondary)
                    else Text(ext, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = TextPrimary, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(item.sizeFormatted, color = TextSecondary, fontSize = 11.sp)
        }
        Icon(
            imageVector = if (selected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (selected) GreenAccent else TextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}

// ----------------------------------------------------------------------------------------
// Send: Wi-Fi link active
// ----------------------------------------------------------------------------------------

@Composable
private fun SharingActive(viewModel: MainViewModel, url: String) {
    val context = LocalContext.current
    val served by viewModel.servedItems.collectAsState()
    val qrPayload by viewModel.qrPayload.collectAsState()
    val hotspotName by viewModel.hotspotName.collectAsState()
    val qrBitmap = remember(url, qrPayload) { QrCodeGenerator.generateQrBitmap(qrPayload ?: url, size = 400) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text("Sharing active", color = GreenAccent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                if (hotspotName != null) "Hotspot \"$hotspotName\" is on. On the other phone open Receive → Scan QR Code. It joins automatically."
                else "Scan the QR or open this link in any browser on the same Wi-Fi / hotspot:",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
            if (qrBitmap != null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .padding(12.dp)
                ) {
                    Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR Code", modifier = Modifier.size(200.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(url, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { viewModel.stopSharing() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252), contentColor = Color.White)
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Stop sharing")
                }
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Download my files from EvaPlayer: $url")
                        }
                        context.startActivity(Intent.createChooser(intent, "Share link"))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceContainer)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = GreenAccent)
                    Spacer(Modifier.width(6.dp))
                    Text("Share link", color = GreenAccent)
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Shared files (${served.size})",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(served, key = { it.key }) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurface)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(item.name, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(8.dp))
                Text(item.sizeFormatted, color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

// ----------------------------------------------------------------------------------------
// Receive
// ----------------------------------------------------------------------------------------

@Composable
private fun ReceiveMode(viewModel: MainViewModel, autoScan: Boolean = false) {
    val clientFiles by viewModel.clientRemoteFiles.collectAsState()
    val isConnecting by viewModel.isClientConnecting.collectAsState()
    var receiverUrlInput by remember { mutableStateOf("") }
    var showScanner by remember { mutableStateOf(autoScan) }

    if (showScanner) {
        com.example.ui.components.QrScannerDialog(
            onResult = { text ->
                showScanner = false
                val link = text.trim()
                if (com.example.data.transfer.WifiAuto.isJoinPayload(link)) {
                    receiverUrlInput = com.example.data.transfer.WifiAuto.parsePayload(link)?.url ?: ""
                    viewModel.joinFromQr(link)   // join sender's hotspot + fetch files automatically
                } else if (link.startsWith("http://") || link.startsWith("https://")) {
                    receiverUrlInput = link
                    viewModel.connectToSender(link)   // auto-connect, no manual IP typing
                }
            },
            onDismiss = { showScanner = false }
        )
    }

    fun formattedUrl(): String =
        if (!receiverUrlInput.startsWith("http://") && !receiverUrlInput.startsWith("https://")) "http://${receiverUrlInput.trim()}"
        else receiverUrlInput.trim()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Enter sender link or IP", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(
            "e.g. http://192.168.1.15:8080",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
        )

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = receiverUrlInput,
                onValueChange = { receiverUrlInput = it },
                placeholder = { Text("http://192.168.x.x:8080", color = TextSecondary) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = GreenAccent,
                    unfocusedBorderColor = DividerDark,
                    cursorColor = GreenAccent
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = { if (receiverUrlInput.isNotBlank()) viewModel.connectToSender(formattedUrl()) },
                colors = ButtonDefaults.buttonColors(containerColor = GreenAccent, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Connect", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { showScanner = true },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = GreenAccent)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.scan_qr), color = GreenAccent, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(16.dp))

        if (isConnecting) {
            Text("Connecting to sender...", color = GreenAccent, fontSize = 13.sp)
        }

        if (clientFiles.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Files available (${clientFiles.size})",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    clientFiles.filter { !it.isCompleted && it.progress == 0f }
                        .forEach { viewModel.downloadRemoteFile(formattedUrl(), it) }
                }) {
                    Text("Download all", color = GreenAccent, fontSize = 13.sp)
                }
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(clientFiles, key = { it.id }) { item ->
                    RemoteFileCard(
                        item = item,
                        onDownloadClick = { viewModel.downloadRemoteFile(formattedUrl(), item) }
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun RemoteFileCard(
    item: RemoteFileItem,
    onDownloadClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurface)
            .padding(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${String.format("%.1f MB", item.sizeBytes / (1024.0 * 1024.0))} • ${item.format.uppercase()}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            if (item.isCompleted) {
                Text("Received", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            } else if (item.isFailed) {
                TextButton(onClick = onDownloadClick) { Text("Retry", color = Color(0xFFFF5252), fontSize = 12.sp) }
            } else {
                Button(
                    onClick = onDownloadClick,
                    colors = ButtonDefaults.buttonColors(containerColor = GreenAccent, contentColor = Color.White),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Download", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (item.progress > 0f && !item.isCompleted) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { item.progress },
                color = GreenAccent,
                trackColor = DarkSurfaceContainer,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${(item.progress * 100).toInt()}%", color = TextSecondary, fontSize = 11.sp)
                Text(item.speed, color = GreenAccent, fontSize = 11.sp)
            }
        }
    }
}
