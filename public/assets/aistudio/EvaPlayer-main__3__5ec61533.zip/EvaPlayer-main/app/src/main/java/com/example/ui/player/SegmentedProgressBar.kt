package com.example.ui.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GreenAccent
import kotlin.math.roundToInt

@Composable
fun SegmentedProgressBar(
    currentPositionMs: Long,
    bufferedPositionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    pointA: Long? = null,
    pointB: Long? = null,
    modifier: Modifier = Modifier
) {
    val durationSafe = durationMs.coerceAtLeast(1L)
    // One segment per minute, minimum 20, maximum 60
    val numSegments = ((durationSafe / 60000L).toInt()).coerceIn(20, 60)

    val playedFraction = (currentPositionMs.toFloat() / durationSafe.toFloat()).coerceIn(0f, 1f)
    val bufferedFraction = (bufferedPositionMs.toFloat() / durationSafe.toFloat()).coerceIn(0f, 1f)

    var isDragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(playedFraction) }

    val activeFraction = if (isDragging) dragFraction else playedFraction
    val activeTimeMs = (activeFraction * durationSafe).toLong()

    val density = LocalDensity.current
    val gapPx = with(density) { 2.dp.toPx() }
    val barHeightPx = with(density) { 3.dp.toPx() }
    val cornerRadius = with(density) { CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx()) }
    val thumbRadiusPx = with(density) { 4.dp.toPx() } // 8dp diameter

    val playedGradient = remember {
        Brush.horizontalGradient(
            listOf(
                Color(0xFFFFFFFF), // White
                Color(0xFFE0E0E0)  // Light gray
            )
        )
    }
    val bufferedColor = remember { Color(0xFF555555) }
    val unplayedColor = remember { Color(0xFF333333) }
    val highlightedSegmentColor = remember { Color(0xFFFFFFFF) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp) // Touch target height
    ) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)

        // Time Bubble Preview when dragging
        if (isDragging) {
            val thumbXOffsetDp = with(density) { (activeFraction * widthPx).toDp() }
            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = ((activeFraction * widthPx) - with(density) { 36.dp.toPx() })
                                .coerceIn(0f, widthPx - with(density) { 72.dp.toPx() })
                                .roundToInt(),
                            y = -with(density) { 28.dp.toPx() }.roundToInt()
                        )
                    }
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1A1A1A))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = formatMs(activeTimeMs),
                    color = GreenAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .pointerInput(numSegments, durationSafe) {
                    detectTapGestures { offset ->
                        val tapFraction = (offset.x / widthPx).coerceIn(0f, 1f)
                        val targetMs = (tapFraction * durationSafe).toLong()
                        onSeek(targetMs)
                    }
                }
                .pointerInput(numSegments, durationSafe) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            isDragging = true
                            dragFraction = (offset.x / widthPx).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            isDragging = false
                            val targetMs = (dragFraction * durationSafe).toLong()
                            onSeek(targetMs)
                        },
                        onDragCancel = {
                            isDragging = false
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            dragFraction = (change.position.x / widthPx).coerceIn(0f, 1f)
                        }
                    )
                }
        ) {
            val centerY = size.height / 2f
            val barTop = centerY - barHeightPx / 2f
            val playedWidth = (activeFraction * size.width).coerceIn(0f, size.width)

            // Continuous progress track (no dotted/segmented gaps).
            drawRoundRect(
                color = unplayedColor,
                topLeft = Offset(0f, barTop),
                size = Size(size.width, barHeightPx),
                cornerRadius = cornerRadius
            )

            if (bufferedFraction > 0f) {
                drawRoundRect(
                    color = bufferedColor,
                    topLeft = Offset(0f, barTop),
                    size = Size((bufferedFraction * size.width).coerceIn(0f, size.width), barHeightPx),
                    cornerRadius = cornerRadius
                )
            }

            if (playedWidth > 0f) {
                val playedBrush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF168BFF),
                        Color(0xFF00B9D6),
                        Color(0xFF00D58A)
                    ),
                    startX = 0f,
                    endX = size.width
                )
                drawRoundRect(
                    brush = playedBrush,
                    topLeft = Offset(0f, barTop),
                    size = Size(playedWidth, barHeightPx),
                    cornerRadius = cornerRadius
                )
            }

            // Draw A and B markers if set
            if (pointA != null) {
                val fracA = (pointA.toFloat() / durationSafe.toFloat()).coerceIn(0f, 1f)
                val xA = fracA * size.width
                drawCircle(
                    color = Color(0xFFFFB300), // Amber for A
                    radius = 3.dp.toPx(),
                    center = Offset(xA, centerY - 6.dp.toPx())
                )
            }

            if (pointB != null) {
                val fracB = (pointB.toFloat() / durationSafe.toFloat()).coerceIn(0f, 1f)
                val xB = fracB * size.width
                drawCircle(
                    color = Color(0xFFFF5252), // Red for B
                    radius = 3.dp.toPx(),
                    center = Offset(xB, centerY - 6.dp.toPx())
                )
            }

            // Small 8dp round thumb at activeFraction
            val thumbCenterX = (activeFraction * size.width).coerceIn(thumbRadiusPx, size.width - thumbRadiusPx)
            drawCircle(
                color = Color.White,
                radius = thumbRadiusPx,
                center = Offset(thumbCenterX, centerY)
            )
            drawCircle(
                color = Color(0xFFFFFFFF),
                radius = thumbRadiusPx - 1.dp.toPx(),
                center = Offset(thumbCenterX, centerY)
            )
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
