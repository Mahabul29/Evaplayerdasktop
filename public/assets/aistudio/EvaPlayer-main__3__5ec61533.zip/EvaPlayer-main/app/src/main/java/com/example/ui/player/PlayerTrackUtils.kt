package com.example.ui.player

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import java.util.Locale

/** Real audio / subtitle tracks of the current media, used by the language popups. */

fun Player.audioGroups(): List<Tracks.Group> =
    currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }

fun Player.textGroups(): List<Tracks.Group> =
    currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }

fun Player.isTextDisabled(): Boolean =
    trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)

private fun languageName(format: Format): String? {
    val lang = format.language
    if (lang.isNullOrBlank() || lang == "und") return null
    val name = Locale.forLanguageTag(lang).getDisplayLanguage(Locale.getDefault())
    return name.takeIf { it.isNotBlank() } ?: lang
}

private fun channelName(count: Int): String? = when {
    count <= 0 -> null
    count == 1 -> "Mono"
    count == 2 -> "Stereo"
    count == 6 -> "5.1"
    count == 8 -> "7.1"
    else -> "$count ch"
}

fun audioTrackLabel(group: Tracks.Group, index: Int): String {
    val f = group.getTrackFormat(0)
    val parts = listOfNotNull(
        languageName(f) ?: f.label,
        channelName(f.channelCount)
    )
    return if (parts.isEmpty()) "Track ${index + 1}" else "${index + 1}. ${parts.joinToString(" • ")}"
}

fun textTrackLabel(group: Tracks.Group, index: Int): String {
    val f = group.getTrackFormat(0)
    val name = languageName(f) ?: f.label ?: "Subtitle ${index + 1}"
    return "${index + 1}. $name"
}

fun Player.selectAudioGroup(group: Tracks.Group) {
    trackSelectionParameters = trackSelectionParameters.buildUpon()
        .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
        .build()
}

/** Pass null to switch subtitles off. */
fun Player.selectTextGroup(group: Tracks.Group?) {
    val builder = trackSelectionParameters.buildUpon()
    if (group == null) {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
    } else {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
    }
    trackSelectionParameters = builder.build()
}
