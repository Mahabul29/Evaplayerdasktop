package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.model.VideoItem
import com.example.ui.player.EvaVideoPlayer
import com.example.ui.theme.EvaPlayerTheme
import com.example.ui.viewmodel.MainViewModel
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import androidx.test.core.app.ApplicationProvider

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class EvaVideoPlayerTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testEvaVideoPlayerRendersWithoutCrash() {
        val app = ApplicationProvider.getApplicationContext<EvaPlayerApplication>()
        val viewModel = MainViewModel(app)
        val dummyVideo = VideoItem(
            id = "test1",
            title = "Test Video",
            path = "/storage/emulated/0/Movies/test.mp4",
            uriString = "content://media/external/video/media/1",
            durationMs = 120000L,
            sizeBytes = 10485760L,
            dateModified = 1700000000L,
            folderName = "Movies",
            folderPath = "/storage/emulated/0/Movies"
        )

        composeTestRule.setContent {
            EvaPlayerTheme {
                EvaVideoPlayer(
                    initialVideo = dummyVideo,
                    playlist = listOf(dummyVideo),
                    startIndex = 0,
                    viewModel = viewModel
                )
            }
        }
    }
}
