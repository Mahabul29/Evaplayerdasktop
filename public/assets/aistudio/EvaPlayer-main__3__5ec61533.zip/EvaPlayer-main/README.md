# 🎬 EvaPlayer

A native Android video and music player built with Kotlin, Jetpack Compose and Media3 ExoPlayer.

## 📥 Download

[

![Download APK](https://img.shields.io/badge/Download-APK-00E676?style=for-the-badge&logo=android&logoColor=black)

](https://github.com/Mahabul29/Gsgsh/releases/latest/download/EvaPlayer.apk)

**Direct link:** https://github.com/Mahabul29/Gsgsh/releases/latest/download/EvaPlayer.apk

All versions: [Releases](https://github.com/Mahabul29/Gsgsh/releases)

### How to install
1. Tap the **Download** button above (turn off your VPN if the download stalls).
2. Open the downloaded `EvaPlayer.apk`.
3. If Android blocks it, allow **Install from this source**.
4. If Play Protect warns you, tap **Install anyway**.
5. Open the app and allow the permissions it asks for.

Requires Android 7.0 or newer.

### Download not working?
- Open [Releases](https://github.com/Mahabul29/Gsgsh/releases), pick the latest version, and tap the `.apk` under **Assets**.
- If there is no release yet, open the [Actions](https://github.com/Mahabul29/Gsgsh/actions) tab and wait for the latest build to finish with a green check.
- A download stuck at 0 B means the file was not published yet or the connection dropped. Delete it and try again.
- "App not installed" usually means the file is incomplete. Download it again.

## ✨ Features

- Folders, Videos, File Share and Settings tabs
- Folder tools: move, create folder, multi-select, SD card, sort by name, date, length or size
- Music player with Songs, Albums and Artists
- Plays MP4, MKV, AVI, WebM, TS, FLV and HLS
- Gestures: swipe up/down for brightness (left) and volume (right), double-tap left to skip back, double-tap right to play/pause, pinch to zoom
- Resume prompt ("Resume from 07:08?") with a small Start Over button
- Recently played pop-up on the home screen
- Languages: English, Bangla and Hindi
- Accent color and theme settings
- Subtitles, audio tracks, speed control and Picture-in-Picture
- Equalizer, night mode, sleep timer, A-B repeat and mirror
- URL streaming, playlists and favorites
- Hidden videos with PIN or fingerprint lock
- Wi-Fi file transfer with QR code: the sender starts a hotspot automatically, the receiver scans the QR code and joins by itself

## 📡 Sharing files

1. **Sender:** open **File Share → Send**, select files and tap **Wi-Fi**. Allow the permission and turn on Wi-Fi if the app asks.
2. **Receiver:** open **File Share → Receive** and tap **Scan QR Code**.
3. The receiver joins the sender's hotspot and the file list appears. Tap download.

Android asks the receiver to confirm the Wi-Fi connection once (Android 10 and newer). Auto hotspot needs Android 8 or newer.

## 🛠 Built with

- Kotlin
- Jetpack Compose and Material 3
- Media3 ExoPlayer
- Room and DataStore
- CameraX and ZXing (QR scanning)

## 🔄 Auto build

Every push to `main` builds a new APK with GitHub Actions and publishes it in [Releases](https://github.com/Mahabul29/Gsgsh/releases).

---

Made by [Mahabul29](https://github.com/Mahabul29)
